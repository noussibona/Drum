﻿
<#
	.NOTES
	===========================================================================
	 This code provides a working example of how to create a Notification Icon
     with a Windows Presentation Framework (WPF) Window using PowerShell v3 and above.
	 Created on:   	16-Sep-18 14:27
	 Created by:   Bonaventure Noussi
	 Organization: NTM Center
	 Filename:
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#Powershell conseol Hide or Show
Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'
function Show-Console {
$consolePtr = [Console.Window]::GetConsoleWindow()
#5 show
[Console.Window]::ShowWindow($consolePtr, 5)
}

function Hide-Console {
$consolePtr = [Console.Window]::GetConsoleWindow()
#0 hide
[Console.Window]::ShowWindow($consolePtr, 0)
}
Hide-Console
function Show-BalloonTip
{
	[cmdletbinding()]
	param (
		[parameter(Mandatory = $true)]
		[string]$Title,
		[ValidateSet("Info", "Warning", "Error")]
		[string]$MessageType = "Info",
		[parameter(Mandatory = $true)]
		[string]$Message,
		[string]$Duration = 60000
	)
	
	[system.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
	$balloon = New-Object System.Windows.Forms.NotifyIcon
	$path = Get-Process -id $pid | Select-Object -ExpandProperty Path
	$icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)
	$balloon.Icon = $icon
	$balloon.BalloonTipIcon = $MessageType
	$balloon.BalloonTipText = $Message
	$balloon.BalloonTipTitle = $Title
	$balloon.Visible = $true
	$balloon.ShowBalloonTip(300000)
	myCustom_Timer -myCode $balloon.BalloonTipClosed -duration 300000
	myCustom_Timer -myCode $balloon.Dispose() -duration 600000
	
}


function myCustom_Timer
{
	
	param ($duration = 1000,
			$myCode)
	#End
	#--------------------------------------------------------------------------
	$timer2 = New-Object System.Windows.Forms.Timer
	$timer2.Interval = $duration
	$global:myTimerID = $timer2
	$timer2.add_Tick({
			$myCode
			$global:myTimerID.Dispose()
			$global:myTimerID.Stop()
		})
	$timer2.Start()
}


#region Count Message
function CountMessage
{
	if ($global:RestRequest_status -eq $true)
	{
		$global:AllMessages = $global:AllMessages | Sort-Object Service
		$global:itemsource = @()
		$ServicesName = @()
		$ServiceCount = 0
		[string]$PreviousName = " "
		[int]$IncidentsCount = 0
		[int]$AdvisoriesCount = 0
		[int]$DegradationCount = 0
		[int]$InterruptionCount = 0
		[int]$RestoringCount = 0
		[int]$RestoredCount = 0
		[int]$OtherCount = 0


		ForEach ($ServiceType in $global:AllMessages."Service")
		{
			if ($ServiceType -ne $PreviousName)
			{
				$PreviousName = $ServiceType
				$ServiceCount++
				$global:AllMessages | where-Object { $_."Service" -eq $ServiceType } | ForEach-Object {
					switch ($_.Category)
					{
						'Incident' {
							$IncidentsCount++
							break
						}
						'Advisory' {
							$AdvisoriesCount++
							break
						}
						default
						{
							break
						}
					}
					switch ($_.Status)
					{
						"Service degradation" {
							$DegradationCount++
							break
						}
						"Service interruption" {
							$InterruptionCount++
							break
						}
						"Restoring service" {
							$RestoringCount++
							break
						}
						"Service restored" {
							$RestoredCount++
							break
						}
						default
						{
							$OtherCount++
							break
						}
					}
				}
				if ($ServiceType-eq "Mobile Device Management for Office 365")
				{
					$CurrentService = "MDM for Office 365"
				}
				else
				{
					$CurrentService = $ServiceType
				}
				$global:itemsource += [PSCustomObject]@{
					"Service Name" = $CurrentService
					Incidents = $IncidentsCount
					Advisories = $AdvisoriesCount
					Degradation = $DegradationCount
					Interruption = $InterruptionCount
					Restoring = $RestoringCount
					Restored = $RestoredCount
					Other = $OtherCount
				}
				[int]$IncidentsCount = 0
				[int]$AdvisoriesCount = 0
				[int]$DegradationCount = 0
				[int]$InterruptionCount = 0
				[int]$RestoringCount = 0
				[int]$RestoredCount = 0
				[int]$OtherCount = 0

			}


		}
	$LastUpdateTime.Content="Last update at: " + (get-date ).ToLongTimeString()
	$NextUpdateTime.Content = "Next update at: " +(get-date).AddMinutes(15).ToLongTimeString()
	$message = "My o365 Sevice Health Monitoring has been updated at " + $((get-date ).ToLongTimeString())
	Show-BalloonTip -Title $message -MessageType Info -Message "My o365 Sevice Monitoring" -Duration 60000 

	}
}



function Get_Messages
{
	$global:AllMessages = @()
	###############################################
	$SecretKey = 'centricaplc'
	# Create app of type Web app / API in Azure AD, generate a Client Secret, and update the client id and client secret here
	#https://siemcentricalogrhythm-centricaplc.msappproxy.net/
	$ClientID = "0776b655-1ec4-497c-a5e1-cf6f3be61e08"
	$ClientSecret = "LV29eYcMYJFXRJL2ZuAetjV2A6pycIC9mo6ZtrM99LI="
	$loginURL = "https://login.microsoftonline.com/"
	$tenantdomain = ($SecretKey).Trim() + ".onmicrosoft.com"
	# Get the tenant GUID from Properties | Directory ID under the Azure Active Directory section
	$TenantGUID = "a603898f-7de2-45ba-b67d-d35fb519b2cf"
	$resource = "https://manage.office.com"
	# auth
	$body = @{ grant_type = "client_credentials"; resource = $resource; client_id = $ClientID; client_secret = $ClientSecret }
	$oauth = Invoke-RestMethod -Method Post -Uri $loginURL/$tenantdomain/oauth2/token?api-version=1.0 -Body $body
	$headerParams = @{ 'Authorization' = "$($oauth.token_type) $($oauth.access_token)" }
	$myURI = "https://manage.office.com/api/v1.0/$tenantGUID/ServiceComms/Messages" # REST endpoint

	$myOutput = $null
	$myOutput = Invoke-WebRequest -Headers $headerParams -Uri $myURI


	if ($myOutput.StatusCode -eq 200)
	{
		$global:RestRequest_status = $true
		$Events = ($myOutput.Content | ConvertFrom-Json).value
		foreach ($myEvent in $Events)
		{
			$EventDetails = $myEvent

			if ($EventDetails.MessageType -ne 'MessageCenter')
			{

				$EventDetails = $myEvent
				$objectProperties = [ordered]@{
					"Message ID" = $EventDetails.Id
					"Type" = $EventDetails.MessageType
					"Title" = $EventDetails.Title
					"Impact Description" = $EventDetails.ImpactDescription
					"Severity" = $EventDetails.Severity
					"Service" = "$($EventDetails.WorkloadDisplayName)"
					"Start Time" = ((($EventDetails.StartTime -replace 'T', ' ').split('Z'))[0]).Split('.')[0]
					"End Time" = ((($EventDetails.EndTime -replace 'T', ' ').split('Z'))[0]).Split('.')[0]
					"Last Updated" = ((($EventDetails.LastUpdatedTime -replace 'T', ' ').split('Z'))[0]).Split('.')[0]
					"Category" = $EventDetails.Classification
					"Status" = $EventDetails.Status
					"Action Required By" = " "
					"Messages" = $EventDetails.Messages #Foreach -> MessageText , PublishedTime
					"AffectedTenantCount" = $EventDetails.AffectedTenantCount

				}

				$messageObj = New-Object -TypeName PSObject -Property $objectProperties
				$global:AllMessages += $messageObj
			}
		}

	}
	else
	{
		$global:RestRequest_status = $false
	}
}



function Retrieve_Event{
	Get_Messages
	CountMessage
}


# Extract icon from PowerShell to use as the NotifyIcon
#region Binary Data
	$icon = [System.Convert]::FromBase64String('
	AAABAAYAAAAAAAEAIABvSwAAZgAAABAQAAABACAAaAQAANVLAAAwMAAAAQAgAKglAAA9UAAAICAA
	AAEAIACoEAAA5XUAAICAAAABACAAKAgBAI2GAABAQAAAAQAgAChCAAC1jgEAiVBORw0KGgoAAAAN
	SUhEUgAAAQAAAAEACAYAAABccqhmAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAA3XAAAN1wFC
	KJt4AABKiElEQVR42u29W6/lyJUm9q0gufe5n5OXk5lVKpUqU6VStUotjaa74fGT3fNiwAbmyXoa
	GIZhwIBh/4F5sSDYj2P42YCNsZ8FG34wYHePYc80DBvtVk/PGFarVSW1VFV5rcrLue4byVh+iAgy
	SAav+56HK3OfTQYjgsHY8a31rRVBkpgZvfTSy80Use4G9NJLL+uTXgH00ssNll4B9NLLDZZeAfTS
	yw2WXgH00ssNll4B9NLLDZZeAfTSyw2WXgH00ssNll4B9NLLDZZeAfTSyw2WXgH00ssNll4B9NLL
	DZZeAfTSyw2WXgH00ssNll4B9NLLDZZeAfTSyw2WXgH00ssNll4B9NLLDZZeAfTSyw2WXgH00ssN
	ll4B9NLLDZZeAfTSyw2WXgH00ssNll4B9NLLDRZ/nsJEIDBQ9WqRn/4UhJ+k+z9x5PnZz0D4cYsT
	/0x9/fjHaP1Wk592yPiTn7Q/TxuhhhmYl9uOXm6eUIs3A9FPAfoeQKcAff3XEAcD0O6HoKtnEAMB
	GtwHjV9DBASaCojbBJpeQ3iHoNkIwtsHBWMIsQ8KxxD7e6BwAhERhACICDQcljdgOgUGQ/B0Agx2
	wJOJ2scUmAAYMFjuaJBMAN4BYwyMofJjDMhd9T3cBY8BYATEu2CMALmnvoe74NEIGO6Br6+BHfO9
	D8YVEO+rc4Ra9+1pYF5cXGDv8IjPz4G9I5V2dgbsH6vtAwa/BnAo1f5LAHgFHN4Gf22lA8DY2r71
	DvjxY+DWezrtd+rP5QcfMH5tcv0aDz78kP/6r9XeO9/Tef9S7T/7A73/z9T+9/7NtP6f/Qz4pK0y
	dWjSZSvKZUit8l1zY5at9BspgMP/+ep0FPM/FwCEgBRE7APsEVgQ1LZHLAD2rX0PII/AvtDpgkh9
	Az7Avgd4DPiC4IPh+WAfBCJmwYAgYp9UI0k5K1IAYIAFwJp8sACY9D4RmMCsshETMQsALMEkIMFg
	JrBgAAQmQKqehpSABHHMEuo/kQQgWUopARZMsQSYISUDEiwkAAnEkiEkWEqQkLGEJJ0uASlIxAww
	GJKBGDKWLCAZkCIWUgaIEZsyqhyEFzOzBEgyOPYkdBmSAGLEsRTwJDxVp0+QAGIJSB8kCYgRQHog
	yXEoAZKgQewDkoji4ZCkEBQPQFJ4FO/vCYloJnfFnhwDCPTAC/V3tAvG9QgB7/EIQLAHxjUw2ANf
	X11hsH/Al1dXAIDh/kF2UF2qP4P9w8Jgu8SlPg4MD4rHcXGB4cFRIX16ZAHjLH/0DDvHJ+r4G1hf
	b7B7cist9zotsXuSBdqrV2brJfZu302PfQ3s3ymC8sUL4ODUAdanwNH9NP1LAMBjHL/3HitFnpXb
	UZr3syT117jz4YcMrdyfjsHv/gEY/0wp8p/97Gf45Mc/5p8oHNSR8ow0UgD0P10+IOAZSCmpzEcA
	xGRtA6TzCdL7Iv0WDBAxiLXZN/sAPACeADxS274AfNL7Os0jVa9HKoBh71OyTxDEEFDbHgAIVZ50
	OUGAgPJhiJB0Het6kn4h0mpYdyuRta2ysIQqm6SpMjLpQOtX0ZpAbTMYCrksOUmXWu0zEyTLpKzU
	52AAMtZ59F/JBJYAk9Rl1UdK1s3RdetGSchETTIzJBGYGbu//Re/HP3uVx9LZiaApW6AZFanZ5aq
	b1hKQDKzOqLOxGCWgGAws+pcSJiuIEgwSRCpM5OqE0qpqZ4kksxgIkg1OsAAS9LdxEw6v2ofBElm
	liChfgVO8wIkSdWhFDYxE0i1kYRksAQxM5Mk1e1StZslMySBpN5mMEtiSAbHCjYspYAkJgkCMziG
	ZCYglkySlHMcs8zUETNYQrKURJLAEgTJjBhSMjFJyRyDICUjJgJLxDGklCSFjAVLCjmWiONYcgyW
	LDmKohlLkhxHMoyjOJaRlFf8J//dv2yiABrHANLBm0tkqECAGlUlGsTetJBglyO2lASDQAqsWjkI
	XVYpFUqUhtAYJWblQ8AomBTsROocJDhVXLZiIoaAUhRCsFIg+lwCpL51uwQJEEmtZEgpNDCEMOfW
	Cgj6mqAVDaWKj3QjyGgPTV/sfiV1EB5R0k9MmttAIcQoKGYFXjAD5CUKwAa+6W7JRiF46hgDrEY2
	AGD36Gjg375DUsbEksHMHmvOw5Dqmzmpl2WcpElp8Jq0GIB1bbpcqhR1u8nksweYUo6mcKpcoXSM
	VlgcmzJRUipR1OZciQKnRGUm9TCSY+a6wAwmBqShmTJRlMwyuTJmU7dWpjI9f6KedR8naYmiT88J
	ZkjSx/SFMqy2mDo1z2Uy14W032ycgn8F4OOFKoAqYNdyCEt72APD/rETfRAnP08uwmiXkalSYbb0
	i1WP0kxJHrsxxNa5iXVWS6mQrtewBJOHoI1aUdEkx3U5q3sSpQNdRqVp9qHPR2TYkWIvJEjVBc2U
	kD+3+iP0NZNRQJw2SGgqRmz607TGdizVQBQCGHgCRIDkGNPxGFEYQkqpwa1AIM0AZk7S2eQxA5Y1
	uJAqn3Qwq4QEPImCkukARy6v1G22FEhy1JyLWTExss6JtD3IlLX+JprSHs+J9swM3zQTW3WQpeCs
	8+eHbV7x2eOSdBvTAWsNWaMQchVmRlg+qXlkYz4F0FTy5i3bq+48TmVh5ZF2lzgUCqAZSfU5MuaR
	s3nKFZD9Y+bVHxuDputMLY9LIdnuFGyFkk+XGszgzM+rlBYlgy85t5VOlG270gtKwUAo5nOw4+N0
	f4A9yZiNp/j66RNcn18gjiOwZMjECikryAbU9m/FnFxqERyGxWT7MAUb5dKsXyH3u5UPnVT5ZUBp
	2ATlx0kOKFSSnnZ2IYnt/OSsLJvElCmZOeg8bdovjepvGdZcsgKoARBQBFD2lyvmL5RpcI7W7eBs
	kQZKyC5QrpCKyqJYJ5KBSq52VbWdqq7V3tfzt1qheEJZmFs7AQBGFIW4OjvH2auXkHFc6IsUoFRi
	kNoOTkpxUSxUrNtlYqm8bvXFuXIWsDK7uXRz0KnsLTBnijnqsOJMxSbWtb2kTxr1bbUsSQFw8Uda
	Bkhr8wCrUhbt2uU4h8lDaTq3aofeb1QmDUIa8hOz1ONTgiUjjiPEUawUQFPLVAag0sFfBU5k6y8F
	J1oCyJFQBaBl1l1aP5VUt1jwA8tQAB3pfvP8XcpUAK5NnXO3vaNCWbLyNEwe2m/PpDW2zHBnXgiA
	Suquq3+ZdTe69oq6Kym/q8o29a8lBtBkEOb3c3S/Mk/DczSiwEtQKI2VRYtr7dKOjmVMdDsTBym1
	zPndZQ7+ZVrmsvqXCc62bV9U37plAQqggcUClmQ55zzHNrGPhboqjjyZgB4hF8vGQi3TSi1zWf3r
	UCxl9S+K8rcDPzC3Alil5Wxxji7tWETblxGjmLsPmyoUZGdN2I5B9JS/2bVX1L0Kyt8hFNBRATSh
	2ZlELERZVOZpeI6FKa0uZRalUOZtezF/YarN+P/sGqDrGPw95S+to3sMsIMCWAq9XcJAn7sd87Z9
	DoWyEuVZLMM6LbsoBUuwTFtE+euuf+Mo/9LWAXQA0AbN6Wf2W5VpqyxauBSd21FWpqPyBJAuk+Vs
	np7yV1x7Rd1rofztqUAzBbBSejuHv7wpyqJLW1cyM+HOw/bNTmY9O5Cbf89JT/m7X/9KFUu1tGMA
	ydeGDfQu7Zi77R0VyqYoT7sMWUXNTSnpmmIUpFMwatVTfDeU8i9nFqANvW1BgTuDwd5fheUsK7Nk
	ur+ItjduBydpnLH8uX64MZS/rP4Npfx1dZdIQxcg+aP3lzEI5zzHNrGPhboqC2AfGufMDJaS8phP
	pBU4dbpjs6f8C6y7Sf0V0pwBAFtAs9dhOVtc69x92FF5NuoPtS8BTlYFGlnYAO0pvzvrEllPjXRj
	AOu2WItsx0JAOo9Cmbfti2Fa5t55kozsAO4pf/P25fJvIOXPSzsGsK6B3iTPMuh+l7auQmm5rm8B
	fVh4SId+HFpResq/0ZR/KbMA/Zx+9Tk6t6OsTEfl2aUPLeDrB/+hp/ybQvnL6m97/W5puQ5ghf7y
	piiLLm1d45x+pzLJM9IoXRNQ6L+e8m805a9se7m0DAJa28ByBnqTPItgH2/rnH7H/lCQZ4DVA+s4
	D/66wZ/ZXTXlb1v/iil/XfuW6q5USwsXIPmj95dhsVZhOcvKLJnuL6Lty5yZ4CSvvi/IHO8pf+e6
	69q+Bsqfl/ZLgfs5/eprXXo7ltCHlKazZOgHE6oP5ft5hZb5JlP+uuuva3tDaXc3YD+nP187MmU6
	Ks+F94cpY55DLyk5TPnm95S/Ud117Vu5YimXxdwMVJmnpMwyLOdCQDqPQpm37QtmWq3akewbfyDX
	LxtC+ecF0FtL+duDH+h8M1B+f9k0ewF0v0tbV6G0XNe3imculFwrQxKbF1dUzjH3lN+ddUmzHJ3a
	Xi8tbwbS28nXogZhlzJtlcUqaHZZmY7Ks0sfVrodFW3n9F2BaYacD9BT/m7tW3csoUIWcDMQ2oN0
	XcqiS1u3bU6/S38Q9LsGpV4IZIKAWlZimcvq7yl/ad3OYu2owALXASwIcF3K9HP67a61rIx5ybot
	PeUvb+M6KX+T9jWQBd8MZO+vwnKWlVky3V9E2zdmZkLnYSB5Wy5DzQgkHkBP+Vu1b92Uf+GzAEuh
	t03A0KLMQuj+Atreqh1L7MPadhTLsP2K7CoA9ZS//PrXTfmXNgvQW07kkAt3kG/J7KPuWrv2od5m
	1s8Bz1drpKf8LepfIeWv69sS2ZyHgta5FKtqh+vcK1FaXcosSrGZfAxAgtmB/htD+dvWv0mUv30c
	YL7HggPrs1jzKpRNoftz9+EimJZF/dlRdpMpf5J00yn/MoOAzuBazUBPvpahLFZBs8vKdGQJrdpR
	cq1z92EV+wAAAuvHghtPYK4B2lP+7nXXtW9O4BtpPwuwUMvZpcya2UdnJrGsPpyDfeTOwSzVSgBF
	CuB+ItBbQPnnqn8LKH+LOwTfsoeCNm3XMtoxb9vXrDyl1PS/KgjYU/6Np/zLfSJQkrAEy1lWZsl0
	fxFt35iZiQ7sI39LMDvammboKX9t+zrWXdc+QgTga/Whr/R2+k1k9s2nkbR8Oeg8YGhRZiF0P7e/
	ITR7Oe3o0D+5PAb3zJIYjjcD9ZR/0XXHAL0C8DUoAa0GMeXAja8BvOH/5b9x8rJ5pKkL8AqMvw/g
	GOBj9Y0TcLJ/AuAYbG2Dj8EY6vLW1yZaTrtMQ4WyyXP6jfvQym9mAcDWTUGkNraO8lv5V0/5xwD+
	AgbARDlwJyB/zX/y30qsWRopAP6H3wwB/B9tK6f//m93ABwrRYFjgE/UN/5zMH9snWHJfnuLMgsB
	XJcyi1JsHduuj00uzr+VyddT/pr2FdI/5T/9J/8GtkRaugDthP/9RxMAEwAv7HT6J7/+TwF8PB8o
	8/sbQPcbt33FMYqG7TAvB0lnAewsN4jyOw+1qHuLZKkKoFrYMQjz+4ui2WVlFmA5a9tRcq2N274o
	9tEgjwkEWIxASU/5m117Vfs2U9ajAJyDcg3+cmfLmdmP8Fd/OoU/2EMwJAQDINgBBrvAYAfY2QMG
	e4AQzdtRmafjtTbIwyyVDiCA4XgqUE/5O17/5sqaGMACB/rSA2W1ZWL88s/3EU2AMASiKRDNgDAC
	whkg9XYQAMM9YGdff2vFsLOn9oe76thgV++bPHp/sIP2yqK98mSW+snAOR+gy+CPIyCOgTjUn8j6
	xADHwO13rrBzcLDVlL+y7Zst63MBlhYoa1lmEcpiuAcID6Ap4HlqW4SA5wOxALwIiCLg+gy4etOt
	v0ikiqKgLHaB4T4w3NHfu+rYzh4Q7AI7et/zS/tDQiKMY8wmM0RhBJZWgNqMbSk1eDWYowiQGuDm
	O47VMY6z8QOzsjDZJ1On6Cn/+mTNLgDQDJS5/XUF+cra4fkK9L4HhD5APuDNADEDIgFQqBRC7Ct2
	EEcd+kwCkyv1AXIBuobiDzSz2FXsQ2/zcB/R/iEu797H5OvfYvTqa8Rnb4DpGJAG5JHVBzagKQWZ
	+fY8gL0UHPl85osIEII3Z1Xf20/587LGICDmBGkZKO0ybQNlVWVq2kHQikArgEgzAcMIYk9ZSCGA
	SFtK2UERuMRWBhmQkbUtAEhgOgJmI4Beq+NMAHmIfIFLPwB5HuI4hoxi69o8wBfIWO4M8HNKgPPA
	N+sJHAqjDORbS/m3SymsLwbQmYq3KLPUqLqVngBQb/g+4AmlDIRQAIo0SyCjEKJUKcgu60HMSXMW
	FRbISKTpCfiE/uh9oRQAExBC6JcCeUBgAZ6RAtXUaU6at/7J+bmYbgOe9b4QWe29tZSfKottqqzJ
	BUj+LCfItwi636ReF/sA9CAQgB8AHilF4GkWIDzNDkKtEIRiAnGsaH4byYDPBrtIv0FaCRmwCytd
	03ThwWmhbeDa53O5ALZrkLACcrSVrLymjSbPtlL+7QQ/sO5ZgE4WvKxMR5bQqh32fn6e3GYD9r4H
	BBqEkQa8ECo24BkF4AEiSgNojZ17C2gJ6PW2tuwQBMBT5xQiVQDC5PFTtgCkdD1RAIDb+lvpGTcD
	WSBRro4kPTnOW0/5txD4RtbPAABs0Jx+wzIl7ciD31YMQtPqBHyeigVAqJkC0kpAUMoGuEIRkFB1
	J2DX9UKkYBeWwqHcvtDshDyLrtv03AavdYG2Jc8eLAb9zLbJwq7y4Erwr53ylx1roFi2QDaLAax/
	Tr9jO5AG1Gzwk12PPuZ5gBhqwGvwxgSEMSCN360j71Kqb5fYCsCA24A+sf4mzU+/PZ3fBCcTMNr+
	vmm/1faCQsjHBgDAtClv9SnXZpNGQDzLd6RzczsoP0GM3/zw+N39mAQkiGIihAAmIBoR8RUznQH8
	EkTPRMxfxEJ84cXRr2Qw/OzNb9+coZ2QY9sMwkb+5BrXAWzonH6XeELhyTkl4Ld9Zc+36LoHIFQK
	gEh9y1jPFBAQy2J8QHj621IAXh7sxuL76YyE51nHzFSdaZvDvwesoUXIjDMXQ8iXtx8xnokJaHdB
	xjkKVdzcfMpvJTAQzWJNxeADGAI4UD8VgQSBPILwAPYIvgfQMIAvGA++dwvwwMQUk0BIoCmAMUBX
	YL4QJM4Y9ArML30RvNoZ7nx9cHj41Tun7z7/ox/+wfP/7B/9F2/0eWMAr9BACWzJOoAVzul3aoct
	efCnyZmZAkABwvM1GHRcAKRdgkilEQHQLoG0FIFZWmxPNQovtfJeoC29n37IKAGzb9pjB/ty7oA9
	o2D6IBMsBIrKIO/v59mFlW82thNWSPnb1t+Q8ud3BWmvi0BC6IkgAeEJCE8pA88T6bcg8nzhi0D4
	QRDsBkFwEgw8eJ4P3/MhhIDv+SASSd1jOsef/ep/xx//w78HKWUczsLz/+t/+Kt7aCBtFIAVrgWX
	bJfKH//0j/3TafyR2PW/c3D60/euxK3NndPvEqMA4Lb8cIM/c5w0YEnRdyFSJRBr8EgJpQgASO1K
	MKVW3/NTcAtP+/hWmucB3kAri0CVM83PUH7LJbCamO4YQNvXQzngiFSZFNyAXF7hcTINuoWUv2xX
	+J7WyQroQoOePMD3fAQDD37gw/cDBANfbQc+gsCH7/vwAg/CV9eUTJSYbVLAlywRxTGkjBHHMWKK
	IUXkjWaTAyzYBfCgHvShzRHiN29+g3/8s//yG68unn8YifAD4fG3/KH4RrDjPwh2vTvDveBk53Bw
	uHcw2N073gn+g//kjwQJNWD+1T+f4W+ShxZt2Jx+F/aR/DpVtD83UFxqUwgAgQVAPahjAihW+0wA
	ydR/ty28+QhPKRTfV1ORIlDA9wepC2Aof8GaI6cQRM5yu6w7UARDlatg1W8WKG0r5c/sKiu/f7AL
	fxDADzwMhgE838dgEMAfBAgCD57vwQsEhE8QgZeyApF6ZQwgZg1uGSOOpf6OEcsIsYwh1SOc1KnN
	S17BmM0ilIywgjRSAP/ov/qP3//gX3vv58MDf9cLpO8Nyd/Z9+kP/92HgPiWPhdb/6S+syyXBtVg
	skG2CrrfpN5O7TB/Gvj8ZdOELkVBeg0Bkdbj1sIdqXWw8FMXwjfWPtCfXJrvK+vv622bzOXBbgOd
	rTZm5vUN6PLugjlm0ixXxz5uuwOCZGqrtpnyE4gIe8MhvvHNdzHYHcAbCIgBwfMJ5CuLLrT/L5kR
	ywhSzjCTMeIohoxjRDIFPVv9b7bNo9rsl7dkyFjuWJ00UgAv31yc/J37t28TEYgJBIK8VhecxHsg
	ASEhiAEhtZWSapCQBIRKZ4ox9ISFFxfoGk7Tbcp9+hmLXgf+xr+NnrZDbvpM12OA7FvA94MU5P5A
	KQnfAH+g0o2JsSP1Sf2Wf29fnGtBjymb1AErzaDbDghaabDy2vw2L1tD+dN0SYxbHx6AiBDHEWKO
	Ecbaik9ilSZjSDCIs2DmZIbEpDkUWT5kWnYJDaWRAji/Po/DeJrsc6YVpC26UQikG0Yg9kG6kymx
	YiaONYd1XsWcfif24QK/fYiKeZuIEAAFVn2Uo/pGAdhgtxRB8gmQWP/8wMms29dtzSznRfa4XZ5t
	JWHlLygDRjaUBIBKbgbaEspvCzMjjCN89fqFNfuRA7j+LiUu7Ki7wyU0lcZBQLvxVqJ6pbS1rxKz
	6oozBYBZLHXWtha8S5l5o/tNA4MVlh+O/UwXufN6HuPkxMPRkY+DfWB3x8fAjyFEDEKkZgiZEIIw
	iwiTSGAUexiFwGUYYIZdINDg94Z6fYCp3wVmyrY/YR0uOp/38TlbR5LXfKS1bR0nr6gFt+LV22Ws
	AojjqFS/U61+oYpj9d3TVlorgDQhn8IWRhgF8HO67wT/wul+g3N0aYcjjzCBLP0LMFkLYkiAYwkb
	ICQYx/uMkxPg5MTDyTHh6Ejg8Iiwtycw3CUEAYHBCKcRwmmMKIwRTZWvGEesps+1P0iIQZ6E74cQ
	/lhFlQcCXqAChVIKRFIgDAUmkY/xzMdoFuB6NsDlbIiryQ6uoh1czvYwlfpBzsb66zMkVN4wA0bO
	NXD4/rZCscvCKitK3IuCtAH/6ih/oW6iUv1S1/xVWX1bmj0VuBX4HSXYrQwWFuRbCd13l/GIcOf4
	EICEjCV2BxMc7oU4PohxeAAcnwgcnng4uRPg5HSAk9NdHN/dS9bx5M8aTiPMJiHCaYRoFiOcxohD
	iXAWIY4k4lBCxgxpWJQFNiFUkMnz1ZSTP/DgB0IrBA/BjodgGCDY8eB5+VndMYAxwmmEqzczXJ7N
	cHkR4eqScXXFuBp5uBx5uJwGuJoOcTnbwVV8gKvoABPeKYKDBNI1A3kPQST9xyQ49Za2i/Knx9P0
	SPovAdytPUVVu1cEfqDtQiB2KIMG4M+4AMm3IwC30CBfU+o+H/sgAv7Df6AAFQyBINiBPyQEux52
	DnzsHQ2wd2sAz6PirIh5Dr81S+Lt+BgOB4V+ZgbiKNLgZ8SxKq8e35VaVUF6cYkvIIT6JtF8hARD
	H7ce+Lj1YK8mZwTgDMAZommMy7MZrs5muLqMcXUpcXkJXI8FrkY+rmc7GIdDjOIDjPgAEz5AhD0I
	Irz2BMKtpvy5dOFfwyiABQDfdYq6/EuJARTBXwR+dtfh/5vk1A+wDrUFfpcyi3IJ0g0pgW/+4BYI
	QoFPB8RIB0WjMeF8DExHM0wupwinIaKZig4TWD1IaCAw2BPY2R9g72SAg+MhREAZxQAwpJDIKwz1
	Jl+JomJ29b57r5mQ9Te7NRh6uPtgB/ceCBD0hwgCngoJs8DLx+d49pvHePX4Am+eX+H81QgXZyP8
	6nIYvxDfckxdbQnlr6h7LVa/JRto/G7AOvBXUn4b/Mk+I5eIRnS/ssw8wO92DgnGLJ7pWTTdD8ng
	MHkJ5BOC20CAAYiGEHrOnZjUsk4ARITZSOD1iDC9nmJ6PdPP6FNzw9AKIxh4GOx62DkIEoXhDURB
	YVStxTD/cj+0tW0Ab5SZAraAKOxPRiGeffYaL353htdPL3D+8hqj8ykm4xnimEEewMRqCiyOIaVE
	pKfDotmRx8PieecDZ0m6Objk6cO6xxoUEjoQl8bpNdLhXoAulN/gaVkW3N5vGQhcBPsAq1VZmTry
	QVEkL94F2Lli2D4l+YB3IrBHKihn2AXpeXMz5Tq5FphcSYTjGSbXU8wmIaIwBMeqDcInBAPCYNfH
	zn6A/VtD7B8P4Q8FUKIc4LTeX+Pll+d48/wKl29GmFzPMJupxSrkEcAK1AbcUsaIzKq1OLtqja1V
	a1FsuxpbSPlr68fKrX4bXdBCAdRQfhPUQfY44AC/zQAa0OzVBPk6BBtzCzky/ZTLn/5V9crcedhR
	v5piVQfJrsMahMxqTpk8gjgW2Dn2QOQrhgEAIAjyQKSe8z+6FBhdRZiNQ0y1wojDGDKWGHgBXj0+
	x+d/8xQX5xeIYqlieWC9/FQWrLhkCSljHYtI22QAXuifHDnKHNhyyu+8rhWCvwsJaDENiAwg2lP+
	9PjleTQFMNzMOf2ObofdLy2VZIEpJMdlsiNzbbFBlfAN9UYPAADZv5GemrPfBE4CoCOB4bEHYh+C
	CHv+AT7988e4vLrEy/OXKdgNM0AKZtYVEVD030vmwMtH6Jy0fM2Uf16r3+QUdemZS1h0EHARlD8Z
	NgycjXYew+NvZ8pUghKLAWljJtG0XWXg786OMiU5U7NVJh/Sy8dTOHsrmJSFlrJONychAII8XI+u
	cHV9hdH4Wllx17pyvQS8oF9NRU3SYAZ9DUC3jvLTSq1+k0uoklYuQPpXb7Ud1Oyocy10v0GZFu1g
	R5m2Vt/VT/maVLPLwJ/Za3humewbFsEsIc2sgtOKU4PodnV65aDfNspf2QELBn+Vr7/cIGA3ym8d
	yVkzttIWRfe7lGnLPsryF642057mlD/fT3YTiteajzUUVIPD/WnEUkoQvoj56PJBv0DKXzi8Aqtf
	tr+BVt+W9rMAHSh/Zt98cR5A84B0hXS/NE+VklwW5S+kOH4j63jNuV0GH8BSrb4geWfrKb+9Se5D
	tc1vmN7I6i9lIdAclL9IZRdl9cvo/pzn6NCO7aD8VYyjeG4Ay6f8BK9Ydg2Uv7T+jnV38Crq0mut
	/tJiADZjTxLaUH6rKvsJJnapPF0tgBLtgTzXisLmCmWbKb+rJgDlwAc6BPrK89vPHCmtaNMpfw34
	V0L5lxkDMF57G6uv9tqCfx6r30ShtDhHq3akx9ZC+R3gT7PWUX4Hp1u+1S/Z3zLK72wfU+Xhmn7r
	FOhrFJB0S+tZAKA95S8uBMrm7wS4pSiLJnU6yiwiLpKUWQ/lZ93g0mnkZYG/qvJtovxaRDx+v2nz
	69K7WX1qxQYazwIAc1J+uwTnAZStM3cyNAJpIyDn9+ex+lxM2lLKX/kMuaUCvyrvFlH+zCHq1g9z
	g5+q85dI85WA81B+5/FFWfAGZTopizbsYzspv/vcliwb/KUGeJsof/Yg6Zd/OFdHNuiDRVj9Njqg
	mwtg/pZRWXYOWSsz1wAuW//i/HZ7v0w5AO0Vil1ssZS/UOOCKb+9n33WI9yyiOh22bEtpPyq8yS8
	8AqD6BKHdIbgMEAYhelvuyLwd4kDtl4H0IXyZ3FRB/55LHhFmaWsLUDq/9eCf3Mpf2fgt8zvSqem
	FTWi/GUNXYxioTiEN7uANz2HN7uAmF3Am51DzK4gBLAz3MG733yAg6PbePnma8QcL3Fun1xf1XU4
	pN3NQF0pf4HKmvQmdD+/v2y636FMBe2er5+s/aVRfuvcZaGAZS5o2UDKL8JrBe7pBbzwHN5Ugz2e
	2B2dvEaBPYIn1PP/fc+DMI9zbxPlX5TVX0YMYH7KXzy+qXP6ndrRtJ+wAsqfaUI55W/0G3XEVF16
	7aBfBeWHVFZ8qoFurPn0CsQhGCqgB1IzI2z72aSez8Cefh8y6Vd/Cco+5HTefmhj9Sv7s1yazwKU
	+ZIOi5un/FnjlQOZ0+qXgbKkzNLofvN2LYPyd/f3W1B+h/IGsFzKn6msZFFA1ehuQfkpnmmQnydg
	F7NzeOEIyVMZyIrcM5VabtLv5FNFSAOeQVAv9xS+aGf1y/qtbaCv4yIgoM1KQCyAyrLlAqz0GX4L
	pPuO/HWWdGMpv+PM9gstbKlj6k4ppfyugnPOv8+uISYK3GJ6AW+i6Duiqbbk6pKVxdbl64CjLT2E
	UhBCEGApAeEJxRCIIISA8NVzITs0v6Y/F0f589LtvQAdKX8Rv/P47fn9RVn9DsriLaH87AD/cqx+
	SYG60c0xxOQSYnIBmhign8ObXYJZ6hcPsZmJ108zaikENZUHSt6gpt7IK9TLmwWBCRAgFQMQOt0T
	8DxyvOfAcSUrDvRVSftZgA6Uv+gp26iZMzYwlwXvUsadZ72Uv3AE1YHJOsahZGGBvqrKyFEumkJM
	LhXIJxcQU/VN0+ts/wsCgZF9cWlH0RQ/sfCkF/V4OhYg9HMZhVEM6vHr6n0o+p0MhgEYz4Zzl7ao
	uf0u064l0koBNJniqwe/vTmPBbf3y5QD6oG8ALdjGZQ/27QqpjA/5XdZycUH+twZfDlC8NUvIaYX
	oMmFAno0xdIl0RnKaqfAJQhPvb1PUXudjwTIg3rWomYZatEPVHn9Upa1Uf6O+q/FSsB5BlZuQCcv
	B9AJTlDm95dM97uUcZjNduDfAMqfKwEsGvxUmX8YvcLgyedYhaRv79JWXGhTrX18CP2CW7KsvLb8
	LACh6T5IQAgAQkAIBoSAJ9RMgH21naL8K7D6tnR4NVg3q58f1CZvJt/C6X6XMs2sfj7PdlP+9DlN
	pbIIyr8gv7WLEBGYdHxAvyTV0PfE709cAE4Df16qDIRAavVJKOUgTCzAuAMbYPWXsRBISUfwFwDI
	9fS9FKQt3IjOTCLX1tw1ZspI6W0k5U+KORQTl5Rw+gJwyxxW3xYRCAwPfEgJyFAijmSNJmooGtzq
	YegG8BZIk+CezQj0fsa3hw7sKZ9fWMqDvCTc6D5/o/7sOLdfsfShjZ5tPwvQCPzlVt9lBTNHlkb3
	u5Spz0McZ/pwuY/rWjzlz547d3zRgT5HehxKTC7CTJrwBISvfGoz9QYALBlSMuKQ9RuXHeehFJJq
	Wp90MqUzBAJJlN8E/UgH+NT7FRWtVyBH4hZAmDwAVcFsmXP7FeldCFardwOajS6UPzt0HQxA15Wp
	Z0PpfpnJXPW9+46aWlH+fP8kaa71Ofax/GZNoK9RHVZ7ZCQhI1QKCYInAPI8RdNFCmiAwTFDMkDg
	LNihlYId7ReULOxhUlN7adTfmh3oOtOwAsrf1btqtRCoK+UvDOrGdN9KXyjd71KmPM92U/5ciSVT
	/tJB31JYMqIZAyStaTpoei4smq6i98Z3T1bwQesKYTMAqACfx0hW+8wri5rbL2EV1DRvibR/NViy
	24byl1izhjS7GfC7lFmgQtlAyl96bquuIjNDURZB+an6cBMxgIX50oE4UymZgF5u2/jjyRqWmAHS
	1p4ZLBWllwQAEhIEkFRBP08oVyRwo82wA0FCMQf7Iiui/Euz+i07t/EsQPXA6UBlN3ROv6BQGscG
	tpjym7bmwd9xbr8gbQc9LOtsBroBu/G/9bbQmVNFQDlFAFModQPsb+SUBdJjpixDuSVgSmawiVW5
	IAgQDAcYDobYH+4oJbCCQF+b/FXSbhagI+XPp378i3/86HcvPUR7dxHt3kO0fw/y4B7ig1PIvVtQ
	i7XnsM5dynR1OxoCMFvdBlH+gqLSsmzKT+m3CrAVKbzTqgNZRVBm9YEC2M1cvz6kRJggYZpIOg5A
	Ig0gCuEhCHwMggF8P8BgMEAQ+FopSKWMBgRvhxHHcfZClx3om8OfahEEXADl11vD+IIOzp9DvpGQ
	MUPGDI70tggg908RH95XCuHgPuKDe4gP7kEenEIGB5kzrYbuV5ffXsqfV956Z5mBvnxxQfAGwg12
	22qb6H3CCLIUn1I6kFpvC9CwFYitFAyFt9b/C9/DIBgg8AMEgwF830fgBao/mdX8/0Ag2PNBPiOK
	JcIoxDQOcTUNEY/U69E3kfLnpeUDQdKtTlTW5CfAGwgISQr0ksE+QUYMGceQl8/gXTy1LtowAgIH
	O4gP7iHavw+5fzdRDvH+KeT+KdgfAgWTVud2APMpi/TYplD+2nMDBeYGIPNQ66VZfTuJAC8QS6Xw
	6by/OokwUX8S8HwPfhBgGAzgBwGCIIAgDya4KzyCNxQIdj2wkAijGaI4wjQKcXkVIpKx+jWsYLDq
	1xLwtw30oYTyV/X9coKAQFfKr8pk94VPYKlWXQlmyJggBENKCekDHCtGYL93HgAoHMN/8zm811/A
	BoUZ53J4qBiEVgqKRSj2EO/fBYSHciC3iA1kyqzocV1Lofxp28y5M2NoieAHoBbXBGIlFN73PQwG
	msIHisILCEjJao2AT/B3PAS7AmEcIY4jhFGISRwhvJghljIZG6wNGbsCJ+uy+suLAehBbjZbUv4i
	lTU/CiAFVBSWABYEkgDFAMcAxQyO4VQEZSL0DSXey9+oH8cuRgS5d1spg4NT5VLs69jDwV3I3VtI
	2YbV2hpl4QTgVlD+4rlXFugz+QXBC1KK35bCqzpEgcIHQYCBP0gpvO+rfte3PIuBQDD0IIZAFEUI
	4wizOMT1LEQ00g/01HlZU/9C+12Bky0CP9DWBehK+TP1WANN+24kFPVkAUAKkGCwECBPLeigiCCl
	UgpNFYH7Ihji+hXE9Sv4L/6meFz4iPfvKmVwcKrdCrUfH5yCB4d2b9gXmb36baL8uXNnfpy8LBj8
	gHYBfK8ThScQPN9DMBhkKLwn1ICSkiGMv74rAB8JhZ9EM1yNI4TXkVKk1u+YeZovV7c/SVhXoG8V
	MYD05r0qyp87UsEUkvFld64gECuGxwCYCJCsbuAghpACsWBACsUIYixeZATv8jm8y+fufvCHWiEo
	d0Lun4L3b6Ed+JdP+Zv8Rk7gJ7nmDPSVlXHpFEEQPs1B4QnSsBeP4A0VhY85VpY9ChHJCOHVLInO
	cwmFp6q2l6ZvltU3/dVUWr8XwE0x21HZqgux/TwBowyUmwAixQBIfVjOyQhaCkVTeOdP4J0/QWA6
	MPDA/9G/l+mTQr80jIusg/IX2lq4aFSmzzvoSQBe4JVSeGPVFYVPp9zIE/B3PXgDII5jhHGIMA4x
	ikJEb0JI7a+z+VdD4duDn1xf3fuhTX6qyNpyuXK3WYC2lJ9z+/lWu+IorAaHTNQiQYCTKDURIONU
	OaxSEbjbv52U362orGsru2YsZtAHwQCDAz3tpv113/MBVrNDJkbg7/qAl065RVGIq1GI+CpSFj1R
	gOx8tFlZW+a1+oUsa7L6XZ+I1H4WoAPlNymumIlz39bMxl/Qiz8sfQABqOWbBAhSboFDBy1EEorK
	Ki7BrCjnVlH+9IcqHrHLlE0lLXjQCxIYDnaxM9xPbrwRmsJLsPLXowiTOER0FSKKY8tfL1L4tu15
	Wyj/PI9Da7UQCFhQ9NoEAjIR+nQ/2STArApMA0QqCCStYgRAstEIJYOioaQdqhYoAdDverOu0zxB
	JntFKIJpmZTfVaKZv19kHE717OiYxQ56BoODGME+EHOMmQZ86KDwdv85Y0gt2tNNeXWw+mXHFhTo
	S4xj03oc0u7twNZfoBvld9KzMmvDZVdu5owVRQTrb302go4VVIxpY9FZShVfMLMR6YXpOtv1jgv8
	XZRkVlksm/JXdVTFz9TCP3UNembGNJzg1flMXy/VUvh1v3J7461+SzLQ+M1AdeCvpfwlD58sWH6j
	1ez6y+IERCBisFECZl93snnAA1gvN5aqHr3QS/+hBdz5uc2Uv6hoMr8NljvomVm9Qy8/EFxVrxz8
	Wxbo6+AJdJsFWNCTZwvWxWX1K1wFI55PGASBWhCip5DMM9rVvQZqVWEcyWRbxhJxyWrD1vIWUH7O
	K56VDnqqrKcU/G2B36qeTQz0VR3sJi0fCw50ovzFEm6f3zU3Y+16gbkjy0cw9DHc8THcH8DzRQHU
	UoM9thRAcjwyabnjkVVeH28STlg85bdyrIDyZ85tBQCXP+g7Ar9Fek/5q6XFY8GB+Sh/ui9IQGje
	nSzIsB7xNgh8DPeH2N8fYPdwBwfHO9i/tYtg6GmQpgCVMVeA2rb8juORVd4+HjnqdygV5Hoj2VrF
	vfvuM7Sm/K7pxcIkwBaCv3Ogr/hVXUfFsdY38ZTW0cLqE1ophYaPBEujAMAcVJZVgG5vdx98LCEC
	gd39AXaPhji4FeD49AC33zmAN/QU+EJlkeM4S93ddN4F6moAd6krryDsp8BsG+VHmeLJD6im6W2B
	X1JPH+jraPWXGwNQ0pnyJxqA8K//W38IhIxgCAz3fRzeHWL3OICUavlmFEf6O0QYRYjDGFEcg2P1
	sAUZKVDGUVwEbY2/LzVbKIA6wyJyxwuugWEdUj1vXl2466o3n/Ln22avg3fJBlv9zO4NBn8bPdBy
	JWA3ym8PasmMuw+P4QkPAgJEHgQJjF9HuHw9wmQUQsYR/ICwe7yH26dDDHY9pRRCpRSiKEYUhZhF
	YQJEGcdKCSRWO67292NZ4Ro4lEbG8qfHdSi72E/WdS+D8qfZ56P8mXN3BP9SA31l6W0Dfc70zQr0
	AR0pf4NsZdJ4GrBqqqv6KTj5EoxQzhCZVXtmyo4Ig7sednCQxAiIBGQkcPZshus3IWaTGUCMwQ5h
	/9YBbp/uAAKI4whRFCIMLfYQhYgSCx4nwI7iuAj6yOEuaMVSF29gq8tXee/+Qim/fe455/aL+Xur
	3yR9EZS/th8c0vq9AHNTWT0OOb/PABAnbWe9Go+gbufcezDAPg0hSDEHQR4ml8D12RijiyniMILw
	GcP9AIe3D3DwYIhYRootxCHiSCmGWRQijmKL4svEXYg7xAg43y9bSvlLJzveOvCvYG6/bR1lFS0R
	+EYW9Fjw3PG20etcfrUrk/wxGEBkXSipZ7OBIA4EDg6HINqFR8atEDh/KXH9OsR0NIWMYwQDgd2j
	Hdw6PcFwT7kUsX4QRMIYolin60eTWfECE3vIKwjVzC2l/C7GYctcg74G/Gu2+oUsN8jq29J4KXAj
	8OcsVjPwN6GylnKwnvLDgF5FBpCpJtHsBP+Wh8HtXeVOQMUawpnA1VmI67MpwvEMRIzBrsD+yT5u
	39sDeZwqBsulCKOZZfnTeEMsbQCuhvJnSs5L+V1tLZtK2lqrn23820D55wW+kfazAB0pP/JHuJAT
	qBvUFSAw5e0ssVTcIe1sdVB4HoZ3Cbu0l8QaBAlcXRBGZ1OMLyaIwwier2cp7hzh9MEOYhkrVyJW
	bkQYhgjjCKMJgZF7V90q7t1fCOXPn7tENgD8Kwv0lR3btEDfnOAHOj8WHFgU5c8c4UJO6/RVFrDa
	krK9z+rdL4UeZcUaaFdgZ8+HR0OtHDzELPDmeYzrszEmoxk4jhAMPOwdD3F05xDj6UUGvNtG+V2K
	x+6beYEPrJ/yvw1Wv3s/lEvjhUCLo/zl+a2arVOXMA6rrjqfu/bc0krV9yKQObd5uywE6Fhg7ySA
	RztJrOFqJCvPvRWUP9cjiWyA1c/sblKgryx/20Bfw3oWDXwjLaYB0708+PPxgfTw8ih/2bnL29rU
	knIaa7DqZMRATJopZDtcslwZ5W/VTy3Ozcj+zv1NPHhrrb4t3WYBNpzyt2McjraVAlDBRGaKdHsn
	wCZR/vwZ66P8m2j1dWJP+VtJh8eCpxtbS/k7WdJi/reB8rsUdEG2IdBX/Kquo+LY2m7ice126csW
	SqH1QqCNovxlAGxF+bsBcHMpf7N+qj03UI2kDZzbv/FWn6oPu6T7Y8GrqOxbQ/nd517tE3rn7CfH
	uesUFYAtoPyLDfStBfxdpvdq6mnrEXR4JqDe6im/s63N+2kzKP/Kwf8WBvqANVN+tAe+kZbPBMRm
	Un6rXa5zt7ekN5DyM8wjErVsotXXidts9RfWD2jfDw5p5wKskPIXauwpv7OfulD++nNvIvhXMLff
	to6yilYE/EKWRj5EVloFAesAmDnSU350B2Czcy9HUdWAf81Wv5Clt/oNK3RLw5WAPeVvAsAm/v5G
	Uf5cP7Fds2vA9pR/bvB3DvRZ6fNafVvaPRDE7G8i5c80oZx2F8+dh9NNpPzufjKytrn9tnWUHXtb
	A31lFS4+BrBayt/d3+8pfzclyYAb+2un/G+D1e/eD1gq+IHWKwF7yp/pkUVR/gIA5wF/S6tfAv63
	NtBXlr9toK9hPSsL9HWcB2wcA3AOrLeC8lewlBtG+c3ZSsHfFvit6ukDffn0ZVl9Wzo8Flz/3QjK
	XziCeaf4biLlt8+0MPDfYMo/r/KqroPq62gh7R8LnvlaPOVP/hYGdU/53f3UknFUgL80FLDMQF/x
	q7qOsmNvSaCvvB8aWn2qcH0c0n4WoBP4e8pf209WXXXnXjTlT8vk+qW3+ivoBzTohxbgRztpPgvQ
	U/5W594Wyu8+N97OQF9J+tIDfQ3qmdvqF/pFpXDJ1K6Rdm8HXinl11udLKlrSC/n3v3tp/yOAdJm
	0DfMnyRuUKAPWD/lX7bVJ/0I/TJpEQOYE/wLeVxXT/kX0k9JmRxDQclA6Sn/AvsB7cBfge4a9kPQ
	w6BKCbSeBQDyg7qn/Iui/NlTrJLy55/zaMkyA32t6tHJc8xQZJK34Sae+RWgSeEyJSBQIUSU+BKA
	Aj5zdqAlA6cCgG3Bz0lNnDk3cufOgqA9+Bn14Oeqc3N67jwAu/j7bvBzdt86N5ecu47yO/spz3gI
	7gGbS0dlOmXSqTZ/dfq84Cdo33iN4C9c3hLAr39BkT8dOa67lAHYmaVk2ibK3+TcPeV3xSa09JS/
	kN450Gelr8jqG/EASP0R+rsgTgWQ0xRUDcCe8jc9d2PKbx1oRvmBdkoyT/mtY4ug/G3rKDvWB/q6
	9YMSYeXS77Evqvu6GAABAEv9tgzHwKkDYPK3FoBtLKnD6ncBYKmiasc4lvu4rhrG0YDyt+snJb3V
	n6cfsDDwt57mTCUAEAGIYbkCRMQ2tgoKwLL+ZH9vJeW36loE5Xede7spf76fcv26SYG+svx9oK8s
	V6C32fpuzQAA6DffJFVtNuVvcu6e8tecuypA50rcoLn9t8Hqzwl+80MO9JbU37ZBT37qjAIosf7E
	kmmRAHTW1FP+hiylmvI3OXe+rdkzlMgNoPzzKq/qOuaY228K/Kz4UPQ/smooBAOrGECiBKRk6im/
	qb5aUbUD/7opf/4MJWqgDeW/oYG+8n5YkdUvig8ghJoNMEqgtQuQnL6ORm8s5Uc38LvsYusFUI5z
	byTlL7RVyw2w+pndbaX8AGQocfVi+nL8cvZn51+O/+um5VwKIH9akpHUUwqbTfld5+4pf4N+QhPw
	rzHQV5LeGvxtgd+gnnVa/XAc89WzyVdXz6f/99nfXv+P0UQ+B3AB4Aqp71/p3TVhAIJZuwA1dBLI
	Da9GlrSn/KVWvwb87ZRkE8ah0xYxt79Eqw+sn/Kvy+pPz8P48unkq4snk5+ffz76P8E4gwL9BYAJ
	gJn+mCnAGBXKoEkMACyZWq1Rfyspf15RdaP8Tc69espfZSR6yp9PbwT+toG+sjIMjF5Ow8snkxfn
	X4z/8vqr6S+hLPy1/r7U31cARgDGAKYoB3/mxy5TAJlZAGktBEr+bhPlVw1wH3GCfzX37m8G5bft
	vz1OFhjoQ8vo9g2f25cx4/r5dHrxePz0/Hejv5peRk+gAD/SH6MArq30ayjwGwVgWIBRAIBD05cp
	AIZ1o1DiAqQJmYyrpfyuEuw8d0/56yh/2bk3i/JvjdWfox/iqcTl08no4vH4i7Pfjf5VPJWvocBs
	QD9GCnI7bQRF/c3HuAAh5nQBGGYdADPVWbNuVLan/LX9lJRZDuUv9tPbRfk7B/qs9GVZ/dlVxJeP
	JxcXj8e/O/9i/P+y5GsoEI+tzyi3P7G+J0it/RQK9CGU5betvzU0suOsyUrAPAp7yt9RUbnBvz7K
	X8U41m31gbcz0Dd+PZOXTyZvzr8Y/+rq+eQzpEDOA7wM7MbKT6DAblv7vNWPkf7Cje8GNJY/kTiU
	k3ASItjxN5DypxV3ovw5EMwH/m2l/GlNhPWD/22g/Kb5LIHrr6bh5ZPxy7Pfjf56chY+RgrsKbIA
	t7cN4M3HAD7U+xFSa29W/BnQV/r9mXbaYM0tBSaoOIAPwL/1ztHB9//+h//g+P7Bv31y//Dv3Pnm
	yTu3v3E8IOuRIvWUv54pZOltT/mLfVJ+7nn76WBwhE//12d4c/Uaby5eLXdu/y0O9HHEuHw6mV48
	Hj87/3z0i3AUv4Qb8FMrfZL7tmm9Abw9vWesvQG++TBKIv+uJwIVHvRBKe8yCsAogYH+7ADYA7B/
	+q1b7z/6g/f+ndNv3frDO++ffHDv0e2jg1u7lJwxA4Ke8ic1t6X82Qt1Xve8lB8M7A8O8dmfPMOb
	6zdKAeSlt/ql9USTmC+fTEYXj8ePz78Y/X8y5EtkQW4D3LbuhtIb0Nsf26e3AW/T/Dz47Q+QGSrN
	FQCQzgJ4+mOUwFB/9gDs6s++3t//5if3P3nvk/t/7/Th7Q/vfXDr9P637wz9oZc96w2k/K5zbwLl
	t899MDgqVwAbDP55XZbqOsrn9qcXEV8+Hp+ffzn+3dXT8afMGCFr1W3A26CvA7zx7Q3QTVDPBn0+
	ut8a/ECzWQBG+lCB0OoGk24aPAZw/eUvXlx++YsX/xJKMez4Q//g4Y/e/bvvfPf0+/ce3n7v/qNb
	R7ffO/ZIpNWsnfJbdTWzpO3OvamU331uh5RQ+JsY6Bu9nMWXT8Zvzj8ffTp6Ofscbqtuz8XbFt6O
	1JdZ+RAK2BGy0Xwb9C6qnwd9LfgBBwNQP0qBBRhXwDABH+qBA7ZrYNhB/nsHWeawc3h3/+4HP3rn
	jx58eOfDe49u37v/7Tt7+7d2LNdBbzmsfrLVU/7s8QUoqgID2GCrn9ldIvhZMq5eTMPLx+Ovzz4f
	/XJ2GX2For8+hdt/z1t382378/a0nW3xY7ipfhOL3wj8QIkCUL9NQQkQlAIwisBWBmY/gAK7rRx8
	KOCbY0YR2DGFwTsf3f3ove/f/8H9R7e/de/Rrdv3Ht4eeInr0FP+UsUzB+XPS0YBXDpiAFhyoK9h
	PZ3n9hsG+uKZxOXTyeTyyfjZ2eejX8ZTeYYi4O3puDLAuz426CWyU3euaH4d+IHswGsMfqDZOgDz
	VFFD+Q31MDTFgN9mCIRUOdhsIbA+NnMInn368vmzT1/+ud7f8Qfe3gc/eudHDz66+/G9R7e+cfro
	9uGdbxx55sfqKX9P+duct87qhyPJF4/H1xePx48vHo9/xXGyKKeJhTeR+rx1N9sSxSm7vJUvC+zZ
	wM9P73UGfnL5tRShODVotkVu23xspmCzBTObYJSB+diMwTAF24Uw2zuHd/dPv/WjB3/3/rdvf/v0
	4a179z+8vbt3vEM95e+mqPKSMIBRLgj4llL+yVkoL56Mzy++nPz26vnkt2hv4e0774yFN3Gx/Py8
	ySORpfkSxYU7bax+J+AnXdOkkOOFAvYLRQhZ5WC/kCCvFPKKwVYEtgthFEXedbBjDTsABg8+uvOd
	9z659/unj269f+/hrdt3H50EfmDPOrxllB/oNMVXa/XhVgALuYlnzVbfbDIDo6+n0cWTyevzL0a/
	nrwJn6Jo4e2AnQ18O3iXX3Jrf4wCyAO9ytqX+fmu+fyC1e8CfCPNXg9eXCyUX1ZoK4AYWXZgf+pY
	Ql4puNwG230YPv/01Yvnn776f6AVQjD0D9//4f0fPPjoznfvPjp5596j24e33j0U7cCEVuBvT/nr
	YhNtGEdFW0vO3UjeEqvPEePq+WR28Xjy9fkXo1+Fo/g1slTeBfq8H29ur7WBbwPdWH4b9BLuYF7+
	u4mf77T68wA/6aZ5KyGqHSZlroOw9l0KIVmFiCxLMAzB/jaswOU+DA9P9+69/8MHPzp9dOvh6aOT
	u/e/fWt393hIdeDvAkCVZgcmN5fy5yVhAOM3OGu5EMiZtI6beAiIphKXT8ajy8eTZ+dfjj7Ti3Js
	wNtWP0/nDaW3/fg6/70K7K7ttdB9l3R6OagtJdOIeZpi/1SGIdgvLLAVgSueUDb7kJ+OzE9LBgCG
	l1+PXvzif/vbT2G5Eg8+uvOdd3/v7vdPH5188/TRycmdD04CPxCZRr/tlN8pLsu/BZR/dhnxxdPJ
	1cWX4y+vnk1+w5LHyFJ4l6XPT83lqb0doc+vwLOj9WUWvs7q52l+mQIAEluzGOAbmVsBuMTRSM4x
	hbwLYRSCzQ7Md14p2AzBKAP727gLRjnk3QbjOnz1/NNXfwHtOvhDb/+bP7z/gwffuf3R3YcnD04f
	nRycvHMgkp7fJMpv1bUwyl8mG0z5x69m8uLJ5Oziy9HvRi9nX6Lou7tovWuKzuXH52l8lUWvA3vZ
	lF6rqb1Fgx9YgAvQ6aT5dw/mDiPrMrhYgstlsNmCrRTyLME1DZmfcRgCGBye7t1/7wf3fnDv0cnD
	uw9P7px++2Rn52hY867EPAA3l/Ln5WBwhM/+9BnORhULgdZ4Ew9LVnfWPZ68Pv9y9OvpRfQ1isG6
	MsC7Vt25aH1+Hj5v8V3H6ix9nu63CvIBywE/sCYFkGkA1RLO/CyDrQyArLuQZwi22xAgVQpl6xLy
	Mw55pTB88NHtDx98fOf3Th+dvHfn4fHx3Q+OAy8wMcb13Lu/KKufKIBx85uBlm3141Di6tlkevFk
	8tXFl6NPo4m8QD3gbdDnV9vlLX1+Sq6MxsuKPK6pvLZ0H1iR1bdlKS5AG3HcjGQnmHsR2No3UjbT
	4Ion5GMItlIQqFYImanI55++fvH809d/odMHwY5/9I3vn35y7zsnH959eHL/9NHx/vE7B6Kn/PX1
	lPHAcBzz5ZPJ+OLx+Onlk/FvZMzmJhsD7qZWvmzVnYva28B2WfAmSqDsUwZ+YA1WP9Pt62YAlY1r
	xg6MiFxa1XoEV0zBMAQXS2jtOnzj9+/+/umjk/fvPDy6c/roZDg8HKh2LXBVH2d9i7nlYHCEz/6p
	5QK4ejz5bUoOdrT60/NQXjyZXF08Hn959WLyW3AG3FVWvmyZbQw3rXcBPILbatcBvyyvi+6bNKDG
	6qvfdjW43GgFkGlovTKw08piCC7XwfXJxxCMgnDFEwZwK4WMcrj/0a3vPPju7Y/vPjx+987D46M7
	Hxz5ws/oBKya8ueloACWSfkZGL2axiaIN1aLcsycex78+UU4VdQ+v6betba+atltE4B3tfgbA3wj
	a3cBmkqNqwCk7gKQTj3mXYeqVYv52QbDBgxryCuF/KxD2YxDAGDnxadvvnrx6Zufm3R/6B1+4/fv
	fv/0w1sP735weO/uo+O9owf7YuWU3yV2D+WS57mJBzHj6vkkvHg6eXX+5eg34XX8Gu7FNwb0ecDb
	oLctfd7Km/S8Va8Dbh3w6yL6nek+sHrwA1ukAPLiWJ3oih0k2eFWCBLlSqGMHZgbneyFSvkZh1ql
	EE3j4ec/f/H485+/yLgO73xy+5O7j46/effh8a07j453hgfpT7Royt9UKPvHcRCl6daddS8uvhz/
	Og7lFcr99zpa71qEk6f3dWDNR+bbMAHX4p028/kbYfUzP9O2uACtLqqbu2C2yz6uwCKhuEDJDjDm
	b3py3ePgch2S/XvfOfnw/ndvfXTn4dE7dx4eHd5+/9AXvsAyJHEBrFmALpR/Nor48snk+vLJ+Mnl
	0/FvWcIsynGBPQ/6KsC7aL39ZBz7GKMI2joG0JQpVPn5jYEPrBf8wBYzgCrp6C7kt/PfAm6W4Aos
	5u9tyE9F5m96soOMmSXNX3129tVXn539pc4zDHb8g3e+f/t7p98++eDOw6O7dx8e7R3e31uKRmgT
	6Bu/mcnLp5Pzi8fjL0ZfT79AddDOtdy27Ll3VctrDfiaArsL8O36m1D9POg3zupnfspNacjKLrgd
	O7C3qwKLZUuZmyxSct0a7VIKpUzh8N7u/Qffu/N7dx8dvXfn4dHJ3UfHw+F+0LpvDAM4H7/Bm8vX
	JR2ovpiB0VfT6PLp+PX5l+PfTC/CF3CD3gDdtfIufzNNGeDrfHkXLXcdy7OBPDMoA3sZ+IEtovvO
	n3PTGrTyDpjfXbC3qxRC3R2QZXdC5u9xKJt5SG6IIqLh6YfH377/3Vsf3nl49ODOw6OD29868oVX
	dWeNUgC//qfPcDY5cy4EkjHj6tlkevls/NX5F+NfRZP4DNlIvcuPz98rX0br69bMlwGzTVoZa3Ap
	BZel32q675K30gVoI0tyF+qej+C62ckEF40iqHqAius+h2SxEjMHX3129vVXn539C50+DHb9g3c+
	uf3x6YcnH9z54OjO3UfHe4f3dosaIacQo0nMl88mo8un48cXj8e/lBGPUB+8y0fp8wtw6lbOMdyg
	b2KVF6kk2k7pbYXVz/zcm9y4dcsC3QV72zX1aAcTy9yG/E1PAxTjCa5nMLqmJQcAgsP7e/fe+d7t
	j+9++/i9Ox8cnbz/3XeHf/tnL/Dq1Sv55NPnby6eTn5z+Wz8N+CMv56fonPdUFP1YMsy6m2DPr9W
	XubSygDaRklU7deBH9hiq29LrwBaSMuViXXugr2dv8kJKCoBVxyhzm0IUFQQQcnHJyKxd2d47/rl
	5DWyIM3Pv7ui9XX+uwvAVUBnuMHfVDlU7VcF9PL5gXoFAGwZ8I30CmAO6agQmrCEfOzA5S647m9w
	PTzF3OuQX8mYdy18ZKc2bYts++tlkfp8NB3IAgwoggwogsv1aaIYXPXXsYQqBdOJ7gPbA36gVwAL
	kyW5C2W3QhsFkFcEVcHFsm+bTdhKB8hayaoFNy6Laso3AVJVni7KoeyYrEmva4fd7vz2VgHfSK8A
	liRLdBfySgAon3YsUwyuOyPzbANw+9VlfroLINKRVqYA7O26Y00++fa3URx1wM/sbzOGegWwIlmy
	u5APJlatR3CxB7sMkLoAhKIfnAc84AZ9XqosaBXg6pRDk/22SuOtpPsu6RXAGmQF7kKdYihzK8hx
	rrLBX2YZXVJXh6u+OoXRZNtOawL2GwN8I70C2ABZkbvgWptgtuHYN2k2GFxKoa1wxX5b5WAfr2MO
	VWlN6lcbbxleegWwgbJEd8G1XVbGiD1AqpcStlMQ3OLYvEqijl3UAh94+8AP9Apg42VB7oL5bsos
	ys5Tld5F2igBV1pdnjqX5cYC30ivALZM5nQX6rar0tYt3CKdK443PfZWA99IrwC2XFoqBNd+WVqX
	PIuWpoOzqztRmnZTcNErgLdIGrymrUn6vHlXIW0GbSs346bhoVcAb7EQleJ2kYBetXKYd8A6y99U
	HPQK4IZJhVJoVHzd7W8hjQb2TR//vQLopZHMqTg2RvrxnpVeAfSy0dJU8fTjuJv0CqCXXm6wLOf5
	0r300stWSK8AeunlBkuvAHrp5QZLrwB66eUGS68AeunlBkuvAHrp5QZLrwB66eUGS68AeunlBkuv
	AHrp5QZLrwB66eUGS68AeunlBkuvAHrp5QZLrwB66eUGS68AeunlBkuvAHrp5QZLrwB66eUGS68A
	eunlBkuvAHrp5QZLrwB66eUGS68AeunlBkuvAHrp5QZLrwB66eUGS68AeunlBsv/D9bnAvhISsak
	AAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE1LTA1LTEzVDEwOjU5OjMxLTA1OjAweCYjggAAACV0RVh0
	ZGF0ZTptb2RpZnkAMjAxMi0xMS0yMFQwOTowMzozOS0wNjowMMdKSjAAAAAZdEVYdFNvZnR3YXJl
	AHd3dy5pbmtzY2FwZS5vcmeb7jwaAAAAAElFTkSuQmCCKAAAABAAAAAgAAAAAQAgAAAAAAAABAAA
	1w0AANcNAAAAAAAAAAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wAAAAABGDgj
	XyFNLcIUNBzYCBcLhQAAADEAAAAaAAAAAf///wD///8A////AP///wAkSDAqKlI1nzNnQOI/g1L6
	TaZl/1Gza/9NsGf/H1As/x5bLv8YTCb+EDQa7gkeEKQAAAAaAAAAAf///wBBdU+Ua8KB/2fBf/9i
	vnv/Xrt3/1q5dP9WtnD/UrRs/x5PK/8dVyz/HVot/x5cLv8eXy//HFcr/xM+H+0NLhdNSHxVnHDH
	h/9sxIT/aMGA/2S/fP9gvHn/XLp1/1e3cf8eTCv/HFMr/x1WLP8dWS3/Hlsu/x5eL/8eYTD/FD0d
	nEt+WJx1yoz/bsCE/2CpdP9VnWv/ZL17/2G9ev9du3b/Hkor/xxPKv8cUiv/HVUr/x1YLP8dWi3/
	Hl0u/xI7HZxPgFycZ6t5/xU3H/8bLRH/LjYO/2a5ef9mwX//Yr57/x9IKv8bTCj/Gj4j/xxGJ/8e
	Uyz/HVYs/x1ZLf8SORycUoFfnHqpafm7hwD6uYUA/7SCAP9uuXj/bMSD/2jBgP8fRSn/G0gn/yQs
	Df8XKBH/Ei8Z/xtFJ/8dVSz/EjYcnFWFYZyDsGv5x48A/8GMAP+8iAD/crt8/nLHiP9swIL/I0Ys
	/xtFJv9dRAD/Y0cA/2NHAf4uQhf3HFIq/xI0GpxVimVngrRr6c+VAP/KkgD/xY4A/1dWH/xEWi7/
	Vmku/2lvJf9sYhb/W0MA+F9FAP9iRwD/MDwV+Bs/JPIWMRx+3qUAH9yfAH3XnAD/0pgA/82UAP+U
	awD0lGsA/pdtAP5dRQb5UDoA8Vk/AP1cQgD/XkQA/2FFAIxlRwBEa1EAE+qqAGDlpQD/4KIA/9ue
	AP/VmgD/0JYA/8uTAP/GjwD/Z00L0VI7AP9VPQD/WD8A/1tBAP9dQwD/YEUA/2JIAGDyrwBg7awA
	/+ioAP/jpAD/3qAA/9mcAP/UmQD/zpUA/2ZNDdBPOAD/UToA/1Q9AP9XPwD/WkEA/1xDAP9gRQBg
	9rAAHfO1CVH0thtU7rgkVOy3KlXptS1V5rQrVOCvKFKWdihNcFkcSG5ZF0NtVhRAaVARPGROCTdf
	RgUzVUcAEv///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD//wAA//8AAPgHAACAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
	AAAAAAAAAAAAAAAAAAAAAAD//wAAKAAAADAAAABgAAAAAQAgAAAAAAAAJAAA1w0AANcNAAAAAAAA
	AAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AAAAAAEAAAACAAAABAAAAAQAAAAEAAAABQAAAAUAAAAFAAAA
	BAAAAAQAAAAEAAAABAAAAAMAAAACAAAAAf///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8AAAAAAQAAAAIAAAAEAAAABgAAAAsAAAAUAAAAHwAA
	ACgAAAAqAAAAIwAAAB8AAAAdAAAAGwAAABkAAAAWAAAAFAAAABAAAAAMAAAACAAAAAQAAAAB////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8AAAAAAgAAAAMAAAAFAAAACgAAABQA
	AAAkAAAAMwAAAEUHEQpmGj4ksiZTM94MJRLPAggEhwAAAGcAAABbAAAATQAAAEEAAAA5AAAAMQAA
	ACoAAAAhAAAAGAAAAA8AAAAIAAAAAwAAAAH///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wAAAAABAAAAAgAAAAUAAAAK
	AAAAFwAAACYAAAA2AwMDShYzH5UkUzHSMXBB8T6RVf1Lrmb/TLBn/0WSWf8eWy//HVkt/xVCIfsN
	KRTkBQ4GpwAAAHkAAABoAAAAVwAAAEUAAAA6AAAALwAAACMAAAAYAAAADgAAAAcAAAAC////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAEAAAACAAAA
	BgAAAA4AAAAaAAAAKQAAADkSJxlvJEwvvTBpQOg/h1P6Tqpm/1Cza/9Psmr/TbFo/0ywZ/9MsGf/
	TLBn/0WSWf8eWi7/HVot/x5bLv8eXC7/Hl0u/xdKJP0PMBjsBxUKtQAAAHgAAABjAAAATwAAAD4A
	AAAwAAAAIwAAABYAAAAMAAAABQAAAAH///8A////AP///wD///8A////AP///wD///8A////AAAA
	AAIAAAAIAAAAEgAAAB4AAAAsDRcQTiNGLKExYj7aP4FR9U+jZv5ZuHP/WLdx/1a2cP9Vtm//U7Vu
	/1K0bP9Rs2v/T7Jq/06xaf9NsGf/TLBn/0WSWf8eWS7/HVkt/x1aLf8eWy7/Hlwu/x5cLv8eXS//
	Hl4v/xlQKP4RNhzxCR0OwgAAAHcAAABdAAAASAAAADMAAAAiAAAAEwAAAAkAAAADAAAAAf///wD/
	//8A////AP///wAAAAACAAAADAAHByYiPyl+MVw8yD95T+5Rm2T9YLt4/2C9ef9fvHj/Xbt3/1y6
	df9buXT/Wbhz/1i3cv9Xt3D/VbZv/1S1bv9StG3/UbNs/1Cyav9OsWn/TbFo/0WRWf8eWC3/HVgs
	/x1YLf8dWS3/HVot/x5bLv8eXC7/Hl0u/x5eL/8eXy//HmAv/xtYLP8UPR71CyQRzgIGAnoAAABU
	AAAAPAAAACIAAAAQAAAABgAAAAL///8A////AP///wAxXTs0VZpn8WS4e/9pwoH/Z8GA/2bAfv9l
	v33/Y798/2K+e/9hvXn/X7x4/167d/9cunb/W7l0/1q5c/9YuHL/V7dx/1a2cP9UtW7/U7Rt/1Gz
	bP9Qs2v/T7Jp/0aRWv8eVi3/HVYs/x1XLP8dWC3/HVkt/x1aLf8eWy7/Hlwu/x5dLv8eXi//Hl4v
	/x5fL/8eYDD/H2Ew/x5dLv8VRSL5DSsV1wQOBoIAAABHAAAAKgAAABMAAAAE////AP///wA3ZERP
	bcWF/2zEhP9rw4L/acKB/2jCgP9nwX//ZcB9/2S/fP9ivnv/Yb16/2C8ef9eu3f/Xbt2/1y6df9a
	uXT/Wbhy/1e3cf9WtnD/VbVv/1O1bv9StGz/UbNr/0aSXP8dVSz/HVUs/x1WLP8dVyz/HVgt/x1Z
	Lf8dWi3/HVou/x5bLv8eXC7/Hl0v/x5eL/8eXy//HmAv/x5hMP8fYjD/H2Mw/x9hMP8XTCb6DzMZ
	1godDmsAAAAN////AP///wA8aEZMb8aG/27Fhf9sxIT/a8OD/2rDgv9owoD/Z8F//2bAfv9kv33/
	Y757/2G9ev9gvXn/X7x4/127d/9cunX/W7l0/1m4c/9Yt3L/V7dw/1W2b/9UtW7/UrRt/0iTXf8d
	VCz/HFQr/x1VK/8dViz/HVcs/x1XLP8dWC3/HVkt/x1aLf8eWy7/Hlwu/x5dLv8eXi//Hl8v/x5f
	L/8eYDD/H2Ew/x9iMP8fYzH/H2Qx/x9kMf8OKhM3AAAAAf///wA+a0lKcceI/3DGh/9uxYb/bcWE
	/2zEg/9qw4L/acKB/2fBf/9mwH7/Zb99/2O/fP9ivnv/Yb15/1+8eP9eu3f/XLp2/1u5dP9auXP/
	WLhy/1e3cf9WtnD/VLVu/0mTXv8dUyv/HFMr/xxUK/8dVCv/HVUs/x1WLP8dVyz/HVgt/x1ZLf8d
	Wi3/Hlsu/x5cLv8eXC7/Hl0v/x5eL/8eXy//HmAw/x9hMP8fYjD/H2Mx/x9kMf8QLxow////AP//
	/wA+b0xKc8iK/3HHiP9wx4f/b8aG/23Fhf9sxIT/a8OC/2nCgf9owYD/ZsF//2XAff9kv3z/Yr57
	/2G9ev9gvHn/Xrt3/127dv9cunX/Wrl0/1m4cv9Xt3H/VrZw/0uUX/8dUiv/HFEq/xxSK/8cUyv/
	HFQr/x1VLP8dViz/HVcs/x1YLf8dWS3/HVkt/x1aLf8eWy7/Hlwu/x5dLv8eXi//Hl8v/x5gL/8e
	YTD/H2Iw/x9iMP8RMhwu////AP///wBCb0xKdcmL/3PJiv9yyIn/cceI/2/Ghv9uxYX/bMSE/2vD
	g/9qw4L/aMKA/2fBf/9mwH7/ZL99/2O+e/9hvXr/YL15/1+8eP9du3b/XLp1/1u5dP9ZuHP/WLdy
	/0yVX/8dUCr/HFAq/xxRKv8cUir/HFMr/xxUK/8dVSv/HVYs/x1WLP8dVyz/HVgt/x1ZLf8dWi3/
	Hlsu/x5cLv8eXS7/Hl4v/x5eL/8eXy//HmAw/x9hMP8RMhwu////AP///wBCb0xKdsuN/3XKjP90
	yYr/csiJ/3HHiP9wxof/bsWG/23FhP9rxIP/asOC/2nCgf9nwX//ZsB+/2W/ff9jv3z/Yr57/2G9
	ef9fvHj/Xrt3/1y6dv9buXT/Wrlz/02WYf8dTyr/HE8p/xxQKv8cUSr/HFIq/xxSK/8cUyv/HFQr
	/x1VLP8dViz/HVcs/x1YLf8dWS3/HVot/x1bLv8eWy7/Hlwu/x5dL/8eXi//Hl8v/x5gMP8RMhwu
	////AP///wBCb1BKeMyO/3fLjf91yoz/dMmL/3PIiv9xx4j/cMeH/2/Ghv9txYX/bMSD/23EhP9p
	u3//YKh0/2S6fP9lwH3/ZL98/2K+e/9hvXr/YLx4/167d/9du3b/W7p1/06WYf8cTir/G04p/xxP
	Kf8cTyr/HFAq/xxRKv8cUiv/HFMr/xxUK/8dVSv/HVYs/x1XLP8dWCz/HVgt/x1ZLf8dWi3/Hlsu
	/x5cLv8eXS7/Hl4v/x5fL/8RMhYu////AP///wBCb1BKes2Q/3nMj/93y47/d8qN/3fIjf9ttID/
	Zad3/16idP9do3T/Xad2/1uteP9TqHL/SJVj/2G2eP9nwX//ZsB+/2S/ff9jvnv/Yb16/2C9ef9f
	vHj/Xbt2/0+XYf8cTSn/G0wo/xtNKf8cTin/HE8p/xxQKv8cUSr/HFIq/xxTK/8cVCv/HVQr/x1V
	LP8dViz/HVcs/x1YLf8dWS3/HVot/x5bLv8eXC7/Hl0u/x5dL/8RMhYu////AP///wBFb1BKfM6S
	/3rNkf95zI//S39Y/y1ePP8uYD//LmRB/y5kQf8uZED/J1Y2/x5FKv8WNB7/DSMS/1ilbf9pwoH/
	Z8F//2bAfv9lv33/Y798/2K+e/9gvXn/X7x4/1GYZP8cSyn/G0so/xtMKP8bTSn/G04p/xxPKf8c
	UCr/HFEq/xxRKv8cUiv/HFMr/xxUK/8dVSz/HVYs/x1XLP8dWC3/HVkt/x1aLf8dWi7/Hlsu/x5c
	Lv8RMhYu////AP///wBFclBKfs+T/3zOkv97zZH/QHRP/xlDJf8XQCP/FDcd/xArF/8NIxL/DSMS
	/w0kE/8NJBL/DSIS/1qmbv9qw4L/acKB/2jBgP9mwX//ZcB9/2S/fP9ivnv/Yb16/1GXZP8cSij/
	G0oo/xtLKP8bTCj/G00p/yFHK/8kSy7/I1Ev/x5RLP8cUSr/HFIq/xxTK/8cVCv/HVUr/x1WLP8d
	Viz/HVcs/x1YLf8dWS3/HVot/x5bLv8RMhYu////AP///wBFclNKf9CV/37PlP99z5P/QXRP/xc+
	I/8SMRr/EysV/yczEv85PQ3/T0gL/2NTCP93Xwb/i2kE/2igXf9sxIT/a8OD/2rDgf9owoD/Z8F/
	/2XAfv9kv3z/Y757/1KYZf8cSSj/G0kn/xtKJ/8bSij/G0so/xEvGf8TLxv/GTch/yA/Kf8iQyr/
	I0Yr/yRLLv8kVTD/IFYu/x1UK/8dVSz/HVYs/x1XLP8dWC3/HVkt/x1aLf8RMhYu////AP///wBJ
	clNKgdGX/4DRlf9/0JT/dH807ZdzBfepfQL9uYUA/7iFAP+2gwD/tYIA/7OBAP+xgAD/r34A/2yg
	XP9uxYX/bcSE/2vEg/9qw4L/acKB/2fBf/9mwH7/ZL99/1SZZ/8bSCf/Gkcn/xtIJ/8bSSf/G0oo
	/wkaDv8IFQv/ChoO/wwfEf8OJRT/ECkX/xErF/8WMBz/HDgk/yZGL/8fVi3/HVUs/x1WLP8dVyz/
	HVgs/x1YLf8RLRYu////AP///wBJclNKg9OY/4LSl/+A0Zb/l4sm3sCKAP++iQD/vIgA/7uHAP+5
	hQD/t4QA/7aDAP+0ggD/soAA/26hXf5wx4f/b8aG/23Fhf9sxIP/asOC/2nCgf9owYD/ZsB//1aZ
	Z/8bRif/GkYm/xpHJ/8bSCf/G0kn/w8nFv8MIBH/Cx0P/wobDf8LHA7/DSER/w8oFv8SMBr/Fjge
	/yJFK/8fVS3/HFQr/x1VK/8dVSz/HVYs/x1XLP8RLRYu////AP///wBJclNKhdSa/4TTmf+C0pf/
	mowm3sONAP/BiwD/v4oA/76JAP+8iAD/uoYA/7iFAP+3hAD/tYIA/3GhXvhyyIn/cMeH/2/Ghv9u
	xYX/bMSE/2vDg/9pwoH/aMKA/1aZaf8bRSb/GkUm/xpGJv8aRyb/Gkgn/1VAAv9VPwL/RjkD/zoy
	Bv8tLAn/HycM/xEjEP8NIxL/DykW/x07Jf8fVC3/HFIr/xxTK/8cVCv/HVUs/x1WLP8RLRYu////
	AP///wBJdlZKh9Wb/4XUmv+E05n/m44n3sWOAP/EjQD/wowA/8CLAP+/iQD/vYgA/7uHAP+6hgD/
	uIQA/3KkX/h0yYr/csiJ/3HHiP9vxof/bsWF/23EhP9rxIP/asOC/1iZav8bRCb/GkQl/xpFJv8a
	Rib/GkYm/1VAAv9hRgD/YkcA/2NHAP9kSAD/ZUkA/2ZKAP9fRgL/UUAE/0M/Dv8dUSv/HFEq/xxS
	Kv8cUyv/HFQr/x1VK/8RLRYu////AP///wBMdlZKidad/4fVnP+G1Jv/nY8n3siRAP/HjwD/xY4A
	/8ONAP/BjAD/wIoA/76JAP+8iAD/u4cA/3WkYPh1yoz/dMmL/3PIif9xx4j/cMaH/27Ghv9txYX/
	bMSD/1maa/8bQyb/GkMl/xpDJf8aRCX/GkUm/1RBAv9gRQD/YUYA/2JHAP9jRwD/ZEgA/2VJAP9m
	SQD/ZkoA/2NJAfUcTyn/HFAq/xxRKv8cUir/HFMr/xxUK/8RLRYu////AP///wBMdlZKitef/4nW
	nf+I1Zz/nqA39cuTAP/JkQD/yJAA/8aPAP/EjgD/w4wA/8GLAP+/igD/vYkA/3akYvh3y47/dsqM
	/3TJi/90yIr/dMmL/3LGiP9suH//Z616/1mTaf8nSDH/IUYr/x9GKv8cRCf/GkQl/1ZBAvpfRAD/
	YEUA/2FGAP9iRgD/Y0cA/2NIAP9kSAD/ZUkA/2VJAOwbTin/HE8p/xxQKv8cUCr/HFEq/xxSK/8R
	LRYu////AP///wBMdlZKjNig/4vXn/+J157/qrlL/86VAP/MkwD/ypIA/8mRAP/HkAD/xY4A/8SN
	AP/CjAD/wIsA/2t6PvJah1r/W5Nm/2Kndf9qxIr/bM6R/2vTkf9r1JH/aMyJ/2O8ff9gsHD/YqVm
	/2KSVf9edDz/WF0m/1xDAOdeQwD/X0QA/19FAP9gRQD/YUYA/2JHAP9jRwD/ZEgA/2BHAvgbTSj/
	G00p/xxOKf8cTyn/HFAq/xxRKv8RLRYu////AP///wBQfVsyfcKS8H3Omfd81Zr7p7lM/9GXAP/P
	lQD/zZQA/8yTAP/KkgD/yJAA/8aPAP/FjgD/w40A/2VIAPhUPQD/TDcA/0MwAP85KQD/QDQG/0Ix
	Af9dQgD/clIA/3VUAP93VgD/elgA/3tZAP9+WwD/gFwA/1tCAOhcQwD/XUMA/15EAP9fRQD/YEUA
	/2FGAP9iRwD/Y0cA/11GA/8kSC7/J08x/yZQMv8lUjD/IVMu/x5RLP8RLRYu////AP///wD///8A
	////AP///wD///8A1poAiNSZAP/SlwD/0JYA/86VAP/NlAD/y5IA/8mRAP/IkAD/xo8A/2VJAPhT
	PQD/SzcA/zIkAP8fFgD/OCkA/ykeAP84KAD/RzMA/1A5AP9SOwD/VD0A/1Y/AP9aQAD/XEIA/1lA
	AOlbQgD/XEIA/11DAP9eRAD/X0QA/2BFAP9hRgD/YkYA/1tEAf4MHhHpCx4Q3gwiEscUKhmrHDcj
	kydCL4AvRy8L////AP///wD///8A////AP///wD///8A2JwAiNabAP/VmQD/05gA/9GXAP/PlgD/
	zpQA/8yTAP/KkgD/yZEA/2NIAPhALgD/JBsA/x0VAP8iGAD/QC4A/zUmAP9ALQD/SjUA/1dBCP83
	JwD/NiYA/zYoAP81JgD/NygA/1g/AOpaQQD/W0EA/1xCAP9dQwD/XkMA/19EAP9fRQD/YEUA/2FG
	AOj///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A/6oAA+GlABHgogAh258A
	nNmdAP/XnAD/1poA/9SZAP/SmAD/0ZcA/8+VAP/NlAD/y5MA/7uHAO20ggD8uYUA/8CLAP/DjQD/
	wYsA/7+KAP++iQD/vIgA/556GP9UPQH/VDwA/1U9AP9WPgD/Vz4A+lg/AP1ZQAD/WkEA/1tBAP9c
	QgD/XEMA/11DAP9eRAD/X0UA/2BFAOpmTQAK////AP///wD///8A////AP///wD///8A////AP//
	/wDkqAAm46QA/uGjAP/foQD/3qAA/9yfAP/angD/2JwA/9ebAP/VmgD/05kA/9KXAP/QlgD/zpUA
	/8yUAP/LkgD/yZEA/8eQAP/GjwD/xI0A/8KMAP/AiwD/v4kA/7aMHd1UPQL/UzwA/1Q8AP9VPQD/
	Vj4A/1c+AP9YPwD/WEAA/1lAAP9aQQD/W0IA/1xCAP9dQwD/XkQA/19EAP9gRQD/YUYA9GJGAN5j
	RwDJYkkAs2VHAJ1iTgAN////AP///wDmpgAo5qYA/+SlAP/iowD/4KIA/9+hAP/doAD/254A/9md
	AP/YnAD/1psA/9SZAP/TmAD/0ZcA/8+WAP/NlAD/zJMA/8qSAP/IkQD/x48A/8WOAP/DjQD/wYwA
	/7mPH99VPgP/UjsA/1M7AP9UPAD/VD0A/1U9AP9WPgD/Vz8A/1g/AP9ZQAD/WkEA/1tBAP9cQgD/
	XUMA/15DAP9fRAD/YEUA/2BGAP9hRgD/YkcA/2NIAP9gSgAY////AP///wDsrAAo6KgA/+enAP/l
	pQD/46QA/+GjAP/gogD/3qAA/9yfAP/bngD/2Z0A/9ebAP/VmgD/1JkA/9KYAP/QlgD/z5UA/82U
	AP/LkwD/yZEA/8iQAP/GjwD/xI4A/7yRH99VPgT/UToA/1E6AP9SOwD/UzwA/1Q8AP9VPQD/Vj4A
	/1c/AP9YPwD/WUAA/1pBAP9bQQD/XEIA/1xDAP9dQwD/XkQA/19FAP9gRQD/YUYA/2JHAP9gSgAY
	////AP///wDsrAAo66oA/+mpAP/opwD/5qYA/+SlAP/ipAD/4aIA/9+hAP/doAD/3J8A/9qdAP/Y
	nAD/1psA/9WaAP/TmAD/0ZcA/9CWAP/OlQD/zJMA/8qSAP/JkQD/x5AA/76TIOFVPwX/TzkA/1A6
	AP9ROgD/UjsA/1M8AP9UPAD/VT0A/1Y+AP9XPgD/WD8A/1hAAP9ZQAD/WkEA/1tCAP9cQgD/XUMA
	/15EAP9fRAD/YEUA/2FGAP9gSgAY////AP///wDyrAAo7qwA/+yrAP/qqQD/6agA/+enAP/lpgD/
	5KQA/+KjAP/gogD/3qEA/92fAP/bngD/2Z0A/9icAP/WmgD/1JkA/9KYAP/RlwD/z5UA/82UAP/M
	kwD/ypIA/8CWIeJVPwb/TjgA/085AP9QOQD/UToA/1I7AP9TOwD/VDwA/1U9AP9VPQD/Vj4A/1c/
	AP9YPwD/WUAA/1pBAP9bQQD/XEIA/11DAP9eQwD/X0QA/2BFAP9gSgAY////AP///wDyrAAo8a4A
	/++tAP/trAD/66oA/+qpAP/oqAD/5qcA/+WlAP/jpAD/4aMA/+CiAP/eoAD/3J8A/9qeAP/ZnAD/
	15sA/9WaAP/UmQD/0pcA/9CWAP/OlQD/zZQA/8SZIuNWQAj/TTcA/044AP9POAD/UDkA/1E6AP9R
	OgD/UjsA/1M8AP9UPQD/VT0A/1Y+AP9XPwD/WD8A/1lAAP9aQQD/W0EA/1xCAP9cQwD/XUMA/15E
	AP9gQAAY////AP///wDyrAAo8q8A//KvAP/wrgD/7qwA/+2rAP/rqgD/6akA/+enAP/mpgD/5KUA
	/+KkAP/hogD/36EA/92gAP/bngD/2p0A/9icAP/WmwD/1ZkA/9OYAP/RlwD/z5YA/8eaI+RWQQn/
	TDYA/003AP9NOAD/TjgA/085AP9QOgD/UToA/1I7AP9TPAD/VDwA/1U9AP9WPgD/Vz4A/1g/AP9Z
	QAD/WUAA/1pBAP9bQgD/XEIA/11DAP9gQAAY////AP///wDxsQAk8rAC5vOxB+bzswzl8rYT5PG1
	GePxuCHj8Lkl4u64KuHuuizg7bow4Oy5Mt/quTTe6rk13em6NdznuDfb6Lg32ue3NtrmtzbY5bY1
	1+S1NdbitDLV4bMx09asOseFbi3Qfmcny3lhIch3YB/GdV0ew3JdHMFyXBu/cloavHJZF7pwVxa3
	b1YUtG1UE7NrUhGwaFAPrWZPDapmTQynZEwJpGJKCKFhSAWfX0YDnF1EAplbSQAO////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///////wAA////////
	AAD///////8AAP///////wAA////////AAD///gAD/8AAP//gAAD/wAA//wAAAD/AAD/wAAAAH8A
	APwAAAAAHwAA4AAAAAAHAACAAAAAAAMAAIAAAAAAAQAAgAAAAAABAACAAAAAAAAAAIAAAAAAAQAA
	gAAAAAABAACAAAAAAAEAAIAAAAAAAQAAgAAAAAABAACAAAAAAAEAAIAAAAAAAQAAgAAAAAABAACA
	AAAAAAEAAIAAAAAAAQAAgAAAAAABAACAAAAAAAEAAIAAAAAAAQAAgAAAAAABAACAAAAAAAEAAIAA
	AAAAAQAAgAAAAAABAAD4AAAAAAEAAPgAAAAA/wAAwAAAAAB/AACAAAAAAAEAAIAAAAAAAQAAgAAA
	AAABAACAAAAAAAEAAIAAAAAAAQAAgAAAAAABAACAAAAAAAEAAIAAAAAAAQAA////////AAD/////
	//8AAP///////wAA////////AAD///////8AACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAANcNAADX
	DQAAAAAAAAAAAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wAA
	AAACAAAABAAAAAUAAAAFAAAABQAAAAQAAAADAAAAAgAAAAH///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AAAAA
	AgAAAAgAAAAPAAAAFwAAACIAAAArAAAALAAAACkAAAAmAAAAHwAAABoAAAATAAAACwAAAAUAAAAB
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAEA
	AAAHAAAADgAAABYABwAjGDchfSNRL8wubT/yPY5U/SxkO/8WRCL9DiwW5QcSCpsAAABcAAAATQAA
	ADwAAAArAAAAGwAAAAsAAAAE////AP///wD///8A////AP///wD///8A////AP///wAAAAACAAAA
	BwAAAA4AAAAWFjEeRCVOMK4wZz7lPoVR+02oZv9Qs2v/TrFp/0ywZ/9MsGf/LWU8/x1aLf8eWy7/
	Hlwu/xhMJv4QMhnuBxkNrgAAAFcAAABDAAAALgAAABcAAAAIAAAAAv///wD///8A////AP///wAA
	AAAFEyUcHChLMoQzYkDRQX5R9FGiZ/5du3b/W7p1/1m4c/9Xt3H/VbZv/1O0bf9Rs2v/T7Jq/02x
	aP8tZDv/HVgt/x1ZLf8dWi3/Hlwu/x5dLv8eXi//GlQp/xI5HPMLIRC7AAMDUAAAAC8AAAAVAAAA
	BwAAAAH///8AAAAAAkuJXNxnvX7/aMKA/2bAfv9kv33/Yr57/2C9ef9eu3f/XLp1/1q5c/9Yt3L/
	VrZw/1S1bv9StGz/ULJq/y5jO/8dViz/HVcs/x1ZLf8dWi3/Hlsu/x5dLv8eXi//Hl8v/x5hMP8d
	Wyz/FEAg9w0oE8UEDwhEAAAACv///wD///8AWZ5r8G3Fhf9rw4P/acKB/2fBf/9lwH3/Y757/2G9
	ef9fvHj/Xbp2/1u5dP9YuHL/Vrdw/1S1bv9StG3/LWM8/xxUK/8dVSz/HVcs/x1YLf8dWS3/Hlsu
	/x5cLv8eXS//Hl8v/x5gMP8fYTD/H2Mx/x5gL/8TQB/VAAAAAf///wBcoW7vcMaH/27Fhf9sxIP/
	asOB/2fBgP9lwH7/Y798/2G9ev9fvHj/Xbt2/1u6df9ZuHP/V7dx/1W2b/8uYzz/HFIq/xxTK/8d
	VSv/HVYs/x1XLP8dWS3/HVot/x5bLv8eXS7/Hl4v/x5gL/8fYTD/H2Iw/xhOJuz///8A////AF6h
	cO9yyIn/cMeI/27Ghv9sxIT/asOC/2jCgP9mwH7/ZL98/2K+e/9gvHn/Xrt3/1y6df9auXP/WLdx
	/y9jPP8cUCr/HFIq/xxTK/8cVCv/HVYs/x1XLP8dWC3/HVot/x5bLv8eXC7/Hl4v/x5fL/8eYDD/
	GE0m6////wD///8AYKNy73XKjP9zyYr/cceI/2/Ghv9txYT/a8OD/2nCgf9nwX//Zb99/2O+e/9h
	vXn/X7x4/1y6dv9auXT/MGI9/xxOKf8cUCr/HFEq/xxSK/8cVCv/HVUs/x1WLP8dWC3/HVkt/x1a
	Lv8eXC7/Hl0u/x5eL/8YSyXr////AP///wBipHPveMyO/3fKjP9zw4n/Z696/16hcf9an2//Vp9t
	/1OebP9junz/ZcB+/2O/fP9hvXr/X7x4/127dv8xYT7/G00o/xtOKf8cTyn/HFEq/xxSKv8cUyv/
	HVUr/x1WLP8dVyz/HVkt/x1aLf8eWy7/Hl0u/xhKJev///8A////AGSmde97zZH/VpNm/yJMLv8f
	SSv/HUEn/xc0H/8OIRL/DSMS/1+vdP9owoD/ZsB+/2S/fP9ivnv/YLx5/zJjPv8bSyj/G0wo/xtN
	Kf8dUCr/HFAq/xxRKv8cUyv/HFQr/x1VLP8dVyz/HVgt/x1ZLf8eWy7/GEgk6////wD///8AZqd3
	733Pk/9UkGT/GEEj/xMuGf8iMhL/NjoN/0tGC/9eUQn/Z65u/2vDg/9pwoH/Z8F//2W/ff9jvnv/
	MmE+/xtJJ/8bSij/G0so/xo6I/8dPCX/HT8m/x1EKP8hTS3/H1Ut/x1VK/8dViz/HVgs/x1ZLf8X
	RiPr////AP///wBoqHnvgNGW/3aSTfKrfwL2uIUA/riFAP+2gwD/s4EA/7F/AP9trGr/bsWF/2vE
	g/9pwoH/Z8F//2XAfv8yYj//Gkcm/xtIJ/8bSif/Cx4Q/wocD/8NIRP/DycV/xEqF/8ZNSD/H0Ip
	/x1UK/8dViz/HVcs/xdEI+v///8A////AGuqfO+D0pj/hpdG68KMAP+/igD/vIgA/7qGAP+3hAD/
	tYIA/2+savxwx4f/bsWG/2zEhP9qw4L/aMKA/zNhP/8aRSb/GkYm/xtIJ/8+NQb/NS8G/ygqCf8b
	JQ3/ECMR/xErF/8bPyX/HFIr/xxUK/8dVSz/F0Qj6////wD///8Abap974XUmv+HmEfrxo8A/8ON
	AP/BiwD/vokA/7uHAP+5hQD/c61t/HPIiv9xx4j/b8aG/23FhP9rw4L/M2FA/xpDJf8aRSb/GkYm
	/1hBAf9iRgD/Y0cA/2RIAP9lSAD/W0UC/ztAE/wcUSr/HFIq/xxTK/8XQiLr////AP///wBvrYDv
	iNad/4+nUvbKkgD/x5AA/8WOAP/CjAD/wIoA/72IAP91r2/8dsqM/3TJiv9zyIr/cMOG/2i1ff88
	aUr/H0Mp/x1FKP8aRCX/V0EC/mBFAP9hRgD/Y0cA/2RIAP9lSQD/TEII2xxPKf8cUCr/HFEq/xZB
	Iuv///8A////AHe5ifON2KH/nshr/86VAP/MkwD/yZEA/8aPAP/EjQD/wYsA/19qMfZTdUj/VYVW
	/02JW/9NiVj/WpVZ/2KTUf9nikb/a3w2/2pkHf9dQwDsXkQA/19FAP9hRgD/YkcA/2NIAP9GRAz5
	HE4q/xxOKf8cUCr/Fj8h6////wD///8AW5VyK0qIX1KUkiui0pgA/9CWAP/NlAD/y5IA/8iQAP/F
	jgD/XkQA/E04AP80JQD/NScA/zIkAP9MOAD/WUEA/11DAP9hRgD/ZEgA/1tBAO1cQgD/XkMA/19E
	AP9gRQD/YkYA/0E4CP0XLBz0HTgk6B4+KNAeOiaY////AP///wD///8A////ANmcAFjXmwD/1JkA
	/9GXAP/PlQD/zJMA/8qSAP9sTgD5SzcA/1M8AP9oTAD/ZEgA/2tNAP9aQwr/OysA/z4sAP9FMgD9
	WUAA8VpBAP9cQgD/XUMA/15EAP9gRQD/YEUAl////wD///8A////AP///wD///8A////AOGkAIHh
	ogC43aEA2NueAP/YnAD/1poA/9OYAP/QlgD/zpUA/8uTAP/JkQD/xo8A/8SNAP/BiwD/vokA/4Zn
	FehTPAD/VD0A/1Y+AP9XPwD/WUAA/1pBAP9bQgD/XUMA/15EAP9eRQDgYEYApGJHAI9kRwB6ZEgA
	Sv///wD///8A56cAwOSlAP/howD/36EA/9yfAP/anQD/15sA/9WaAP/SmAD/z5YA/82UAP/KkgD/
	yJAA/8WOAP/DjAD/k3MZyVE6AP9TOwD/VDwA/1U9AP9XPgD/WD8A/1lAAP9bQQD/XEIA/15DAP9f
	RAD/YEUA/2JGAP9iRwC4////AP///wDrqgDA6KgA/+amAP/jpAD/4aIA/96gAP/bngD/2Z0A/9ab
	AP/UmQD/0ZcA/86VAP/MkwD/yZEA/8ePAP+WdRvKTzkA/1E6AP9SOwD/UzwA/1U9AP9WPgD/WD8A
	/1lAAP9aQQD/XEIA/11DAP9fRAD/YEUA/2FHALj///8A////AO+tAMDsqwD/6qkA/+enAP/lpQD/
	4qMA/+CiAP/doAD/2p4A/9icAP/VmgD/05gA/9CWAP/OlAD/y5MA/5l4HcpOOAD/TzkA/1A6AP9S
	OwD/UzwA/1Q9AP9WPgD/Vz8A/1lAAP9aQQD/W0IA/11DAP9eRAD/YEUAuP///wD///8A8q8AwPGu
	AP/urAD/66oA/+moAP/mpgD/5KUA/+GjAP/foQD/3J8A/9mdAP/XmwD/1JkA/9KXAP/PlgD/m3ke
	y0w2AP9NNwD/TjgA/1A5AP9ROgD/UzsA/1Q8AP9VPQD/Vz4A/1g/AP9ZQAD/W0EA/1xCAP9eQwC4
	////AP///wDxsQJy8rMImfK2EZrxthyb8Lckne64KJ3uuS2f7bkwn+u4Mp/ouDSe6bk0nua2NJ7k
	tTOc47Ixm+KxL5m3ljSNfWYmk3ReH411XR2Lc1waiHBZGYRwWBiBbFQUf2xTE3toUg94ZE0NdmZM
	CXJhSAduXkYFbFxBAEv///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A//////////////////4A///gAD/+AAAf4AAAB4AAAAEAAAABgAAAAIAAAAGAAAABgAAAAYAA
	AAGAAAABgAAAAYAAAAGAAAABgAAAAYAAAAGAAAABgAAAAeAAAB+AAAABgAAAAYAAAAGAAAABgAAA
	AYAAAAH///////////////8oAAAAgAAAAAABAAABACAAAAAAAAAAAQDXDQAA1w0AAAAAAAAAAAAA
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
	AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
	AAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AAAAAAAAAAAAA
	AAAAAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAA
	AAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAA
	AQAAAAEAAAABAAAAAQAAAAEAAAAAAAAAAAAAAAAAAAAA////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAQAA
	AAIAAAACAAAAAgAAAAMAAAADAAAAAwAAAAMAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAA
	BAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAAAwAAAAMAAAAD
	AAAAAwAAAAIAAAACAAAAAgAAAAEAAAABAAAAAQAAAAAAAAAAAAAAAP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAABAAAAAgAAAAMAAAADAAAA
	BAAAAAUAAAAGAAAABwAAAAcAAAAHAAAACAAAAAgAAAAIAAAACQAAAAkAAAAJAAAACQAAAAkAAAAJ
	AAAACQAAAAkAAAAJAAAACQAAAAkAAAAJAAAACQAAAAgAAAAIAAAACAAAAAcAAAAHAAAABwAAAAYA
	AAAGAAAABQAAAAUAAAAEAAAAAwAAAAMAAAACAAAAAQAAAAEAAAAAAAAAAP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAQAAAAIAAAACAAAAAwAAAAQAAAAFAAAABwAAAAgAAAAK
	AAAADAAAAA4AAAAPAAAAEQAAABEAAAASAAAAEwAAABMAAAASAAAAEwAAABIAAAASAAAAEgAAABMA
	AAASAAAAEgAAABIAAAASAAAAEQAAABEAAAAQAAAAEAAAAA8AAAAOAAAADgAAAA0AAAANAAAADAAA
	AAsAAAAKAAAACQAAAAcAAAAHAAAABQAAAAQAAAADAAAAAgAAAAEAAAABAAAAAAAAAAD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wAAAAAAAAAAAAAAAAAAAAAB
	AAAAAQAAAAEAAAACAAAAAgAAAAMAAAAEAAAABQAAAAYAAAAHAAAACQAAAAwAAAAPAAAAEgAAABUA
	AAAYAAAAHQAAACAAAAAjAAAAJQAAACcAAAAnAAAAJgAAACUAAAAjAAAAIwAAACIAAAAhAAAAIQAA
	AB8AAAAfAAAAHgAAAB4AAAAdAAAAHAAAABsAAAAaAAAAGQAAABgAAAAXAAAAFgAAABUAAAATAAAA
	EgAAABAAAAAOAAAADQAAAAsAAAAJAAAABwAAAAYAAAAEAAAAAwAAAAIAAAABAAAAAQAAAAAAAAAA
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8AAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAQAAAAIA
	AAADAAAABAAAAAUAAAAGAAAABwAAAAoAAAAMAAAADgAAABEAAAAVAAAAGQAAAB4AAAAjAAAAKgAA
	ADAAAAA2AAAAPQAAAEMAAABHAAAATAAAAEwAAABIAAAAQwAAAD8AAAA7AAAANwAAADUAAAAzAAAA
	MgAAADAAAAAvAAAALQAAACwAAAAqAAAAKQAAACcAAAAmAAAAJAAAACMAAAAhAAAAHgAAABwAAAAb
	AAAAGAAAABYAAAAUAAAAEQAAAA8AAAAMAAAACgAAAAcAAAAGAAAABAAAAAMAAAACAAAAAQAAAAAA
	AAAA////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wAAAAAAAAAAAAAAAAAAAAABAAAAAQAAAAEAAAACAAAAAgAAAAMAAAAEAAAABQAA
	AAgAAAAJAAAACwAAAA4AAAARAAAAFQAAABkAAAAeAAAAJAAAACoAAAAyAAAAOwAAAEMAAABMAAAA
	VgAAAGAAAABqAAAAcwAAAHoCBwWFAAAAfQAAAHcAAABwAAAAZwAAAF4AAABYAAAAUgAAAE0AAABJ
	AAAARQAAAEIAAABAAAAAPQAAADsAAAA4AAAANgAAADQAAAAxAAAALwAAACwAAAAqAAAAJwAAACQA
	AAAiAAAAHwAAABwAAAAZAAAAFQAAABIAAAAPAAAADAAAAAkAAAAHAAAABQAAAAQAAAACAAAAAQAA
	AAEAAAAAAAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8AAAAAAAAA
	AAAAAAAAAAAAAQAAAAEAAAABAAAAAgAAAAIAAAADAAAABAAAAAUAAAAHAAAACAAAAAsAAAANAAAA
	EQAAABUAAAAZAAAAHgAAACUAAAArAAAAMwAAADwAAABGAAAAUAAAAFoAAABmAAAAcQAAAH4JFg2a
	HEEmyiphOec4gkz4Tadm/zJfPv8WQiH5DikU4QQLBrIAAACXAAAAiwAAAIAAAAB3AAAAbgAAAGcA
	AABgAAAAWgAAAFUAAABQAAAATAAAAEcAAABFAAAAQgAAAD8AAAA7AAAAOAAAADUAAAAyAAAALwAA
	ACsAAAAoAAAAJAAAACEAAAAdAAAAGgAAABYAAAASAAAADwAAAAwAAAAJAAAABwAAAAUAAAADAAAA
	AgAAAAEAAAABAAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAAAAAAAAAAAAAAAAAAAAAABAAAA
	AQAAAAEAAAACAAAAAwAAAAQAAAAGAAAABwAAAAgAAAALAAAADgAAABEAAAAVAAAAGQAAAB8AAAAm
	AAAALAAAADUAAAA+AAAASAAAAFMAAABdAAAAagAAAHcECQWJFzQfuSZXM98zd0b0QplZ/UywZ/9M
	sGf/TLBn/0ywZ/9Ts23/NWNB/x5bLv8eWy7/Hlou/xdIJPwPLxfrBRIJxAAAAKIAAACWAAAAiwAA
	AIIAAAB4AAAAbwAAAGcAAABhAAAAWwAAAFYAAABQAAAATAAAAEgAAABEAAAAQQAAADwAAAA4AAAA
	NQAAADEAAAAtAAAAKgAAACUAAAAiAAAAHQAAABoAAAAVAAAAEgAAAA4AAAALAAAACAAAAAYAAAAE
	AAAAAwAAAAIAAAABAAAAAAAAAAD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8AAAAAAAAAAAAAAAAAAAAAAQAAAAEAAAABAAAAAgAAAAIAAAAE
	AAAABQAAAAYAAAAJAAAACwAAAA4AAAARAAAAFQAAABoAAAAgAAAAJwAAAC4AAAA3AAAAQAAAAEsA
	AABWAAAAYgAAAG8AAAB7ESYWpyFMLdMvbD/tPY1S+0qsZf9MsGf/TLBn/0ywZ/9MsGf/TLBn/0yw
	Z/9MsGf/TLBn/1Ozbf81Y0D/HVot/x5bLv8eWy7/Hlsu/x5cLv8eXC7/GU0n/hE0GfEHGAzRAAAA
	qAAAAJ0AAACRAAAAhwAAAHwAAABzAAAAagAAAGMAAABcAAAAVgAAAFAAAABMAAAARwAAAEMAAAA/
	AAAAOgAAADYAAAAyAAAALgAAACoAAAAmAAAAIgAAAB0AAAAZAAAAFQAAABEAAAAOAAAACwAAAAgA
	AAAGAAAABAAAAAIAAAABAAAAAQAAAAAAAAAA////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAQAAAAIAAAACAAAABAAAAAUAAAAHAAAACAAAAAoA
	AAAOAAAAEgAAABcAAAAbAAAAIQAAACgAAAAwAAAAOQAAAEQAAABPAAAAWgAAAGYAAAB0ChYNkR1B
	J8QsYzvlOYJN+EikYf9NsWj/TbFo/0ywZ/9MsGf/TLBn/0ywZ/9MsGf/TLBn/0ywZ/9MsGf/TLBn
	/0ywZ/9MsGf/U7Nt/zVjQP8dWi3/HVot/x1bLv8eWy7/Hlsu/x5cLv8eXC7/Hlwu/x5dLv8bVCn/
	Ezkd9QkgD9oBAwGvAAAAoAAAAJQAAACIAAAAfgAAAHQAAABrAAAAYwAAAFwAAABVAAAATwAAAEkA
	AABEAAAAQAAAADwAAAA3AAAAMwAAAC8AAAAqAAAAJgAAACIAAAAdAAAAGQAAABUAAAAQAAAADQAA
	AAoAAAAHAAAABQAAAAMAAAACAAAAAQAAAAEAAAAA////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wAAAAAAAAAAAAAAAAAA
	AAAAAAAAAQAAAAEAAAABAAAAAwAAAAQAAAAFAAAABwAAAAkAAAALAAAADwAAABMAAAAXAAAAHAAA
	ACMAAAAqAAAAMwAAADwAAABHAAAAUgAAAF8AAABrBAkFfxk2IbMpWTbcN3pJ80abXf1Rs2v/ULNr
	/1Cyav9Psmr/T7Jp/06xaf9OsWj/TbFo/02wZ/9MsGf/TLBn/0ywZ/9MsGf/TLBn/0ywZ/9MsGf/
	TLBn/0ywZ/9Ts23/NWJA/x1ZLf8dWi3/HVot/x1aLv8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8e
	XS7/Hl0u/xxYLf8VQCD4DCUT4gMIBLcAAAChAAAAlQAAAIkAAAB+AAAAcwAAAGoAAABhAAAAWgAA
	AFIAAABMAAAARwAAAEEAAAA9AAAAOQAAADMAAAAvAAAAKgAAACYAAAAhAAAAHAAAABgAAAAUAAAA
	EAAAAAwAAAAJAAAABgAAAAQAAAADAAAAAgAAAAEAAAAAAAAAAP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AAAAAAAAAAAAAAAAAAAAAAEAAAABAAAAAgAA
	AAMAAAADAAAABQAAAAcAAAAJAAAADAAAAA8AAAAUAAAAGAAAAB4AAAAlAAAALQAAADcAAABAAAAA
	SwAAAFcAAABkAAAAcRMoGZ8lTzDONHBE7EOQWPtSsGv/U7Vu/1O0bf9StG3/UrRs/1GzbP9Rs2v/
	ULNr/1Cyav9Psmr/T7Jp/06xaf9OsWn/TbFo/02waP9MsGf/TLBn/0ywZ/9MsGf/TLBn/0ywZ/9M
	sGf/TLBn/1Ozbf81YkD/HVkt/x1ZLf8dWi3/HVot/x1aLf8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5c
	Lv8eXS7/Hl0u/x5dL/8eXi//HVwu/xZGI/sOLBboBA0HwAAAAKMAAACVAAAAiQAAAH0AAAByAAAA
	ZwAAAF8AAABXAAAAUAAAAEoAAABDAAAAPgAAADoAAAA0AAAALwAAACoAAAAlAAAAIQAAABwAAAAX
	AAAAEwAAAA4AAAALAAAACAAAAAYAAAAEAAAAAgAAAAEAAAABAAAAAP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wAAAAAAAAAAAAAAAAAAAAABAAAAAQAAAAIAAAADAAAABAAAAAUAAAAHAAAA
	CgAAAA0AAAAQAAAAFQAAABkAAAAhAAAAJwAAADAAAAA6AAAARAAAAE8AAABcAAAAagsXDoghRCq/
	MWY/40GGU/dRqmn/V7dw/1a2cP9WtnD/VbZv/1W1b/9UtW7/U7Vu/1O0bf9StG3/UrRs/1GzbP9R
	s2v/ULNr/1Cyav9Psmr/T7Jq/06xaf9OsWn/TbFo/02xaP9MsGf/TLBn/0ywZ/9MsGf/TLBn/0yw
	Z/9MsGf/U7Nt/zVhQP8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi7/Hlsu/x5bLv8eWy7/Hlwu
	/x5cLv8eXC7/Hl0u/x5dL/8eXi//Hl4v/x5eL/8eXi//GE0m/RAxGe4GFgrJAAAAowAAAJYAAACJ
	AAAAfQAAAHEAAABmAAAAXQAAAFQAAABNAAAARgAAAEAAAAA6AAAANQAAADAAAAArAAAAJQAAACAA
	AAAbAAAAFgAAABEAAAAOAAAACgAAAAcAAAAFAAAAAwAAAAIAAAABAAAAAAAAAAD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AAAAAAAAAAAAAAAAAAAAAAIAAAACAAAAAgAAAAQAAAAGAAAACAAAAAsAAAAOAAAAEgAAABcAAAAc
	AAAAIwAAACoAAAAzAAAAPQAAAEkAAABUAAAAYQUKBnUcOSStLV062D19TvFOn2T9Wrlz/1m4c/9Z
	uHL/WLhy/1i3cv9Xt3H/V7dx/1a2cP9WtnD/VbZv/1W1b/9UtW7/VLVu/1O0bf9TtG3/UrRs/1Kz
	bP9Rs2z/UbNr/1Cza/9Qsmr/T7Jq/06yaf9OsWn/TbFo/02xaP9MsGf/TLBn/0ywZ/9MsGf/TLBn
	/0ywZ/9Ts23/NWFA/x1YLf8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi3/Hlsu/x5bLv8eWy7/
	Hlwu/x5cLv8eXC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8aUin+Ejgb8ggcD9IA
	AgKmAAAAlgAAAIkAAAB8AAAAcQAAAGQAAABaAAAAUQAAAEoAAABDAAAAPAAAADUAAAAxAAAAKwAA
	ACUAAAAfAAAAGgAAABUAAAAQAAAADAAAAAkAAAAGAAAABAAAAAIAAAABAAAAAQAAAAAAAAAA////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAAAAAAB
	AAAAAgAAAAMAAAAFAAAABgAAAAgAAAALAAAADwAAABQAAAAYAAAAHgAAACYAAAAuAAAANwAAAEIA
	AABOAAAAWgAAAGcVKhuXKlM1yjpzSepLlV/6WrZz/126dv9cunX/XLp1/1u5dP9buXT/Wrl0/1m4
	c/9ZuHP/WLhy/1i3cv9Xt3H/V7dx/1a3cP9WtnD/VbZv/1W2b/9UtW7/VLVu/1O1bv9TtG3/UrRt
	/1K0bP9Rs2z/UbNr/1Cza/9Qsmr/T7Jq/0+yaf9OsWn/TrFp/02xaP9NsGj/TLBn/0ywZ/9MsGf/
	TLBn/1Ozbf81YUD/HVgs/x1YLf8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi3/HVsu/x5bLv8e
	Wy7/Hlwu/x5cLv8eXC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8eXy//HmAv/xxY
	LP8UPh/2CyMS2gEEA6sAAACXAAAAiQAAAHsAAABvAAAAZAAAAFkAAABPAAAARwAAAD8AAAA4AAAA
	MQAAACsAAAAkAAAAHwAAABgAAAAUAAAADwAAAAsAAAAHAAAABQAAAAMAAAACAAAAAQAAAAAAAAAA
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAAAAAAAAAAAAgAAAAUA
	AAAHAAAACgAAABAAAAAUAAAAGQAAACEAAAApAAAAMgAAADwAAABHAAAAUwAAAGANGRCAJUguuTZp
	ROBHiln2Wa9w/mC8ef9fvHj/X7x4/167d/9eu3f/Xbt2/126dv9cunX/XLp1/1u6df9buXT/Wrl0
	/1q5c/9ZuHP/Wbhy/1i4cv9Yt3H/V7dx/1e3cP9WtnD/VrZw/1W2b/9VtW//VLVu/1O1bv9TtG3/
	UrRt/1K0bP9Rs2z/UbNr/1Cza/9Qsmr/T7Jq/0+yav9OsWn/TrFp/02xaP9NsWj/TLBn/0ywZ/9M
	sGf/U7Nt/zVhQP8dVyz/HVcs/x1YLf8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVou/x5b
	Lv8eWy7/Hlsu/x5cLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8eXi//Hl4v/x5fL/8eXy//Hl8v
	/x5gL/8eYDD/HVwu/xZFIvkOKhTiAwsGswAAAJcAAACJAAAAegAAAG0AAABiAAAAVgAAAEwAAABD
	AAAAOgAAADIAAAArAAAAJAAAAB0AAAAYAAAAEgAAAA4AAAAKAAAABwAAAAQAAAADAAAAAgAAAAEA
	AAAAAAAAAP///wD///8A////AP///wD///8A////AP///wD///8AAAAAAAAAAAIAAAAGAAAADAAA
	ABUAAAAdAAAAKAAAADIAAAA+AAAATAAAAFgFCQZsIDwnpzNgP9VDgVTwVqRq/WO9fP9jvnv/Yr57
	/2G9ev9hvXr/YL15/2C8ef9fvHj/X7x4/168d/9eu3f/Xbt3/127dv9cunb/XLp1/1u6df9buXT/
	Wrl0/1q5c/9ZuHP/Wbhy/1i4cv9Yt3H/V7dx/1e3cf9WtnD/VrZw/1W2b/9VtW//VLVu/1S1bv9T
	tG3/U7Rt/1K0bP9Ss2z/UbNs/1Gza/9Qs2v/ULJq/0+yav9Osmn/TrFp/02xaP9NsWj/TLBn/0yw
	Z/9Ts23/NWBA/x1XLP8dVyz/HVcs/x1YLP8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVot
	/x5bLv8eWy7/Hlsu/x5cLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8eXi//Hl4v/x5fL/8eXy//
	Hl8v/x5gL/8eYDD/HmAw/x5hMP8fYC//F0ol+w8vF+gFEgi9AAAAmAAAAIkAAAB7AAAAbAAAAGAA
	AABUAAAASQAAAD4AAAA0AAAALQAAACQAAAAeAAAAFwAAABEAAAAMAAAACAAAAAYAAAAEAAAAAgAA
	AAEAAAAAAAAAAP///wD///8A////AP///wD///8A////AAAAAAAAAAACAAAABQAAAA0AAAAZAAAA
	KQAAADsAAABNGjAghS9YOsFAeE/nUpll+WO6e/9mwH7/ZcB+/2XAff9kv33/ZL98/2O/fP9jvnv/
	Yr57/2K+ev9hvXr/Yb15/2C9ef9gvHn/X7x4/1+8eP9eu3f/Xrt3/127dv9dunb/XLp1/1y6df9b
	uXT/W7l0/1q5dP9ZuHP/Wbhz/1i4cv9Yt3L/V7dx/1e3cf9WtnD/VrZw/1W2b/9Vtm//VLVu/1S1
	bv9TtW3/U7Rt/1K0bf9StGz/UbNs/1Gza/9Qs2v/ULJq/0+yav9Psmn/TrFp/06xaP9NsWj/TbBo
	/1Ozbf81YED/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWC3/HVgt/x1YLf8dWS3/HVkt/x1aLf8dWi3/
	HVot/x1aLv8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8eXi//Hl4v/x5fL/8e
	Xy//Hl8v/x5gL/8eYC//HmAw/x5hMP8fYTD/H2Ew/x9iMP8aUij9ETYb7ggaDccAAACYAAAAiQAA
	AHoAAABrAAAAXgAAAFAAAABEAAAAOQAAAC4AAAAlAAAAHgAAABYAAAAQAAAACwAAAAgAAAAEAAAA
	AwAAAAEAAAAAAAAAAP///wD///8A////AP///wAAAAAAAAAAAQAAAAMAAAAJI0ArMTVgQYxBd0/M
	T5Fh8GK0d/5pwoH/acKA/2jCgP9nwYD/Z8F//2bBf/9mwH7/ZcB+/2XAff9kv33/ZL98/2O/fP9j
	vnv/Yr57/2K+e/9hvXr/Yb16/2C9ef9gvHn/X7x4/1+8eP9eu3f/Xrt3/127dv9dunb/XLp1/1y6
	df9bunX/W7l0/1q5dP9auXP/Wbhz/1m4cv9YuHL/WLdx/1e3cf9Xt3D/VrZw/1a2cP9Vtm//VbVv
	/1S1bv9TtW7/U7Rt/1K0bf9StGz/UbNs/1Gza/9Qs2v/ULJq/0+yav9Psmr/TrFp/06xaf9NsWj/
	VLNu/zVfQP8dViz/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWC3/HVgt/x1YLf8dWS3/HVkt/x1ZLf8d
	Wi3/HVot/x1aLf8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/Hl0u/x5dL/8eXi//Hl4v/x5e
	L/8eXy//Hl8v/x5fL/8eYC//HmAw/x5gMP8eYTD/H2Ew/x9hMP8fYjD/H2Iw/xxXK/4TPB3yCiAQ
	0AIDAp0AAACJAAAAeQAAAGkAAABaAAAATAAAAD8AAAAzAAAAJwAAAB0AAAAWAAAADwAAAAoAAAAG
	AAAABAAAAAEAAAAAAAAAAP///wD///8A////AAAAAAAAAAABAAAABCpNMydsw4P/bMSD/2vEg/9r
	w4L/asOC/2rDgv9pwoH/acKB/2jCgP9owYD/Z8F//2fBf/9mwH7/ZsB+/2XAff9lv33/ZL98/2S/
	fP9jvnz/Y757/2K+e/9hvXr/Yb16/2C9ef9gvHn/X7x4/1+8eP9evHf/Xrt3/127d/9du3b/XLp2
	/1y6df9bunX/W7l0/1q5dP9auXP/Wbhz/1m4cv9YuHL/WLdx/1e3cf9Xt3H/VrZw/1a2cP9Vtm//
	VbVv/1S1bv9UtW7/U7Rt/1O0bf9StGz/UrNs/1GzbP9Rs2v/ULNr/1Cyav9Psmr/TrJp/06xaf9U
	tG7/NV8//x1VLP8dViz/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWCz/HVgt/x1YLf8dWS3/HVkt/x1Z
	Lf8dWi3/HVot/x1aLf8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/Hl0u/x5dL/8eXi//Hl4v
	/x5eL/8eXy//Hl8v/x5fL/8eYC//HmAw/x5gMP8eYTD/H2Ew/x9hMP8fYjD/H2Iw/x9iMP8fYzD/
	HV0u/xVCIfYMJxPZAwgDowAAAIgAAAB3AAAAZQAAAFUAAABGAAAAOAAAACoAAAAfAAAAFQAAAA0A
	AAAIAAAABAAAAAEAAAAA////AP///wD///8AAAAAAAAAAAEAAAAELE41KG3FhP9sxIT/bMSE/2vE
	g/9rw4P/asOC/2rDgv9pwoH/acKB/2jCgP9owYD/Z8F//2fBf/9mwH//ZsB+/2XAfv9lv33/ZL99
	/2S/fP9jv3z/Y757/2K+e/9ivnr/Yb16/2G9ef9gvXn/YLx4/1+8eP9fvHj/Xrt3/167d/9du3b/
	XLp2/1y6df9bunX/W7l0/1q5dP9auXP/Wbhz/1m4c/9YuHL/WLdy/1e3cf9Xt3H/VrZw/1a2cP9V
	tm//VbZv/1S1bv9UtW7/U7Vt/1O0bf9StG3/UrRs/1GzbP9Rs2v/ULNr/1Cyav9Psmr/T7Jp/1W0
	b/81Xz//HVUr/x1VLP8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgt/x1YLf8dWC3/HVkt
	/x1ZLf8dWS3/HVot/x1aLf8dWi7/Hlsu/x5bLv8eWy7/Hlwu/x5cLv8eXC7/Hl0u/x5dLv8eXS//
	Hl4v/x5eL/8eXi//Hl8v/x5fL/8eXy//HmAv/x5gMP8eYDD/HmEw/x9hMP8fYjD/H2Iw/x9iMP8f
	YjD/H2Mx/x9jMf8eYDD/F0kk+Q8uF+AEDweqAAAAhQAAAHIAAABfAAAATAAAADoAAAArAAAAHAAA
	ABAAAAAJAAAABAAAAAL///8A////AP///wAAAAAAAAAAAQAAAAQuUjgmbsWF/23Fhf9txIT/bMSE
	/2zEg/9rw4P/a8OC/2rDgv9qw4H/acKB/2nCgP9owoD/Z8GA/2fBf/9mwX//ZsB+/2XAfv9lwH3/
	ZL99/2S/fP9jv3z/Y757/2K+e/9ivnv/Yb16/2G9ev9gvXn/YLx5/1+8eP9fvHj/Xrt3/167d/9d
	u3b/Xbp2/1y6df9cunX/W7p1/1u5dP9auXT/Wrhz/1m4c/9ZuHL/WLhy/1i3cf9Xt3H/Vrdw/1a2
	cP9Vtm//VbZv/1S1b/9UtW7/U7Vu/1O0bf9StG3/UrRs/1GzbP9Rs2v/ULNr/1Cyav9Psmr/VrVv
	/zRfP/8cVCv/HVUr/x1VLP8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgs/x1YLf8dWC3/
	HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi3/Hlsu/x5bLv8eWy7/Hlwu/x5cLv8eXC7/Hl0u/x5dLv8e
	XS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8eXy//HmAv/x5gMP8eYDD/HmEw/x9hMP8fYTD/H2Iw/x9i
	MP8fYjD/H2Mx/x9jMf8fYzH/H2Qx/x9kMf8YTyf7ETQa5QcXDK4AAAB4AAAAYQAAAEoAAAAzAAAA
	HwAAABEAAAAHAAAAAwAAAAD///8A////AAAAAAAAAAABAAAAAy9UOSZuxob/bsWF/23Fhf9txYT/
	bMSE/2zEg/9rxIP/a8OC/2rDgv9qw4L/acKB/2nCgf9owoD/aMGA/2fBf/9nwX//ZsB+/2bAfv9l
	wH3/Zb99/2S/fP9kv3z/Y758/2O+e/9ivnv/Yb16/2G9ev9gvXn/YLx5/1+8eP9fvHj/Xrx3/167
	d/9du3f/Xbt2/1y6dv9cunX/W7p1/1u5dP9auXT/Wrlz/1m4c/9ZuHL/WLhy/1i3cf9Xt3H/V7dx
	/1a2cP9WtnD/VbZv/1W1b/9UtW7/VLVu/1O0bf9TtG3/UrRs/1KzbP9Rs2z/UbNr/1Cza/9WtXD/
	NF5A/xxUK/8cVCv/HVQr/x1VK/8dVSz/HVYs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1YLf8d
	WC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi3/HVsu/x5bLv8eWy7/Hlwu/x5cLv8eXC7/Hl0u/x5d
	Lv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8eXy//HmAv/x5gL/8eYDD/HmEw/x9hMP8fYTD/H2Iw
	/x9iMP8fYjD/H2Mw/x9jMf8fYzH/H2Qx/x9kMf8fZDH/H2Qx/xpWKv0TPB3kCyQRowADAEsAAAAv
	AAAAGQAAAAsAAAAEAAAAAf///wD///8AAAAAAAAAAAEAAAACMlk9JG/Ghv9uxob/bsWF/23Fhf9t
	xYT/bMSE/2zEg/9rxIP/a8OD/2rDgv9qw4L/acKB/2nCgf9owoD/aMGA/2fBf/9nwX//ZsB+/2bA
	fv9lwH7/Zb99/2S/ff9kv3z/Y798/2O+e/9ivnv/Yr56/2G9ev9hvXn/YL15/2C8eP9fvHj/X7x4
	/167d/9eu3f/Xbt2/1y6dv9cunX/W7p1/1u5dP9auXT/Wrlz/1m4c/9ZuHP/WLhy/1i3cv9Xt3H/
	V7dx/1a2cP9WtnD/VbZv/1W2b/9UtW7/VLVu/1O1bf9TtG3/UrRt/1K0bP9Rs2z/UbNr/1e2cf80
	XkD/HFMr/xxUK/8cVCv/HVQr/x1VK/8dVSz/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1Y
	Lf8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVou/x5bLv8eWy7/Hlsu/x5cLv8eXC7/Hlwu
	/x5dLv8eXS7/Hl0v/x5eL/8eXi//Hl4v/x5fL/8eXy//Hl8v/x5gL/8eYDD/HmAw/x5hMP8fYTD/
	H2Ew/x9iMP8fYjD/H2Iw/x9jMf8fYzH/H2Mx/x9kMf8fZDH/H2Qx/x9kMf8fZDH/HFwt/hVEIdsA
	AAAdAAAADQAAAAQAAAAB////AP///wD///8AAAAAAAAAAAE1XkAicMaH/2/Ghv9vxob/bsWG/27F
	hf9txYX/bcSE/2zEhP9sxIP/a8OD/2vDgv9qw4L/asOB/2nCgf9pwoD/aMKA/2fBgP9nwX//ZsF/
	/2bAfv9lwH7/ZcB9/2S/ff9kv3z/Y798/2O+e/9ivnv/Yr56/2G9ev9hvXr/YL15/2C8ef9fvHj/
	X7x4/167d/9eu3f/Xbt2/126dv9cunX/XLp1/1u5dP9buXT/Wrl0/1q4c/9ZuHP/Wbhy/1i4cv9Y
	t3H/V7dx/1a3cP9WtnD/VbZv/1W2b/9UtW//VLVu/1O1bv9TtG3/UrRt/1K0bP9Rs2z/WLZx/zRe
	QP8cUyv/HFMr/xxUK/8cVCv/HFQr/x1VK/8dVSz/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs
	/x1YLP8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVot/x5bLv8eWy7/Hlsu/x5cLv8eXC7/
	Hlwu/x5dLv8eXS7/Hl0v/x5eL/8eXi//Hl4v/x5fL/8eXy//Hl8v/x5gL/8eYDD/HmAw/x5hMP8f
	YTD/H2Ew/x9iMP8fYjD/H2Iw/x9jMP8fYzH/H2Mx/x9kMf8fZDH/H2Qx/x9kMf8fZDH/HV4u/gAA
	ABgAAAALAAAABAAAAAH///8A////AP///wAAAAAAAAAAATdhQiFwx4f/cMaH/2/Gh/9vxob/bsaG
	/27Fhf9txYX/bcWE/2zEhP9sxIP/a8SD/2vDgv9qw4L/asOC/2nCgf9pwoH/aMKA/2jBgP9nwX//
	Z8F//2bAfv9mwH7/ZcB9/2W/ff9kv3z/ZL98/2O+fP9jvnv/Yr57/2G9ev9hvXr/YL15/2C8ef9f
	vHj/X7x4/168d/9eu3f/Xbt3/127dv9cunb/XLp1/1u6df9buXT/Wrl0/1q5c/9ZuHP/Wbhy/1i4
	cv9Yt3H/V7dx/1e3cP9WtnD/VrZw/1W2b/9VtW//VLVu/1S1bv9TtG3/U7Rt/1K0bP9YtnL/NF5A
	/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/x1UK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8dVyz/
	HVcs/x1XLP8dWC3/HVgt/x1YLf8dWS3/HVkt/x1ZLf8dWi3/HVot/x1aLv8eWy7/Hlsu/x5bLv8e
	XC7/Hlwu/x5cLv8eXS7/Hl0v/x5eL/8eXi//Hl4v/x5eL/8eXy//Hl8v/x5fL/8eYC//HmAw/x5h
	MP8eYTD/H2Ew/x9iMP8fYjD/H2Iw/x9iMP8fYzH/H2Mx/x9kMf8fZDH/H2Qx/x9kMf8dXi7+AAAA
	DgAAAAYAAAACAAAAAP///wD///8A////AP///wAAAAAAOWRFIHHHiP9xx4j/cMeH/2/Gh/9vxob/
	bsaG/27Fhf9txYX/bcWE/2zEhP9sxIP/a8SD/2vDg/9qw4L/asOC/2nCgf9pwoH/aMKA/2jBgP9n
	wX//Z8F//2bAfv9mwH7/ZcB+/2W/ff9kv33/ZL98/2O/fP9jvnv/Yr57/2K+ev9hvXr/Yb15/2C9
	ef9gvHj/X7x4/1+8eP9eu3f/Xrt3/127dv9cunb/XLp1/1u6df9buXT/Wrl0/1q5c/9ZuHP/Wbhz
	/1i4cv9Yt3L/V7dx/1e3cf9WtnD/VrZw/1W2b/9Vtm//VLVu/1S1bv9TtW3/U7Rt/1m3c/80XkD/
	HFIq/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/x1UK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8d
	Vyz/HVcs/x1XLP8dWC3/HVgt/x1YLf8dWS3/HVkt/x1ZLf8dWi3/HVot/x1aLf8eWy7/Hlsu/x5b
	Lv8eXC7/Hlwu/x5cLv8eXS7/Hl0u/x5dL/8eXi//Hl4v/x5eL/8eXy//Hl8v/x5fL/8eYC//HmAw
	/x5gMP8eYTD/H2Ew/x9hMP8fYjD/H2Iw/x9iMP8fYzH/H2Mx/x9jMf8fZDH/H2Qx/x1eLv4AAAAG
	AAAAAwAAAAH///8A////AP///wD///8A////AP///wA7Z0cfcsiJ/3HHiP9xx4j/cMeH/3DGh/9v
	xob/b8aG/27Fhf9uxYX/bcWF/23EhP9sxIT/bMSD/2vDg/9qw4L/asOC/2nCgf9pwoH/aMKA/2jC
	gP9nwX//Z8F//2bBf/9mwH7/ZcB+/2XAff9kv33/ZL98/2O/fP9jvnv/Yr57/2K+ev9hvXr/Yb16
	/2C9ef9gvHn/X7x4/1+8eP9eu3f/Xrt3/127dv9dunb/XLp1/1y6df9buXT/W7l0/1q5dP9auHP/
	Wbhz/1m4cv9YuHL/WLdx/1e3cf9Wt3D/VrZw/1W2b/9Vtm//VLVv/1S1bv9TtW7/Wrdz/zRdQP8c
	Uir/HFIq/xxSK/8cUiv/HFMr/xxTK/8cUyv/HFQr/xxUK/8dVSv/HVUr/x1VLP8dViz/HVYs/x1W
	LP8dVyz/HVcs/x1XLP8dWCz/HVgt/x1YLf8dWS3/HVkt/x1ZLf8dWi3/HVot/x1aLf8dWy7/Hlsu
	/x5bLv8eXC7/Hlwu/x5cLv8eXS7/Hl0u/x5dL/8eXi//Hl4v/x5eL/8eXy//Hl8v/x5fL/8eYC//
	HmAw/x5gMP8eYTD/H2Ew/x9hMP8fYjD/H2Iw/x9iMP8fYzD/H2Mx/x9jMf8fZDH/HV4u/gAAAAIA
	AAABAAAAAP///wD///8A////AP///wD///8A////ADtnRx9yyIn/csiJ/3HHiP9xx4j/cMeH/3DG
	h/9vxof/b8aG/27Ghv9uxYX/bcWF/23FhP9sxIT/bMSD/2vEg/9rw4L/asOC/2rDgv9pwoH/acKB
	/2jCgP9owYD/Z8F//2fBf/9mwH7/ZsB+/2XAff9kv33/ZL98/2O/fP9jvnv/Yr57/2K+e/9hvXr/
	Yb16/2C9ef9gvHn/X7x4/1+8eP9eu3f/Xrt3/127dv9du3b/XLp2/1y6df9bunX/W7l0/1q5dP9a
	uXP/Wbhz/1m4cv9YuHL/WLdx/1e3cf9Xt3D/VrZw/1a2cP9Vtm//VbVv/1S1bv9buHT/NF1A/xxR
	Kv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8cUyv/HFQr/xxUK/8dVCv/HVUr/x1VLP8dVSz/HVYs
	/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgt/x1YLf8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi7/
	Hlsu/x5bLv8eWy7/Hlwu/x5cLv8eXC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8e
	Xy//HmAv/x5gMP8eYDD/HmEw/x9hMP8fYTD/H2Iw/x9iMP8fYjD/H2Mx/x9jMf8dXS7+AAAAAQAA
	AAD///8A////AP///wD///8A////AP///wD///8APGhHH3PIiv9zyIn/csiJ/3LIif9xx4j/cceI
	/3DHh/9vxof/b8aG/27Ghv9uxYX/bcWF/23FhP9sxIT/bMSD/2vEg/9rw4P/asOC/2rDgv9pwoH/
	acKB/2jCgP9owYD/Z8F//2fBf/9mwH7/ZsB+/2XAfv9lv33/ZL99/2S/fP9jv3z/Y757/2K+e/9i
	vnr/Yb16/2G9ef9gvXn/YLx4/1+8eP9fvHj/Xrt3/127d/9du3b/XLp2/1y6df9bunX/W7l0/1q5
	dP9auXP/Wbhz/1m4cv9YuHL/WLdy/1e3cf9Xt3H/VrZw/1a2cP9Vtm//VbVv/1u4dP80XED/HFEq
	/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8cUyv/HFQr/xxUK/8cVCv/HVUr/x1VLP8dVSz/
	HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgs/x1YLf8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8d
	Wi3/Hlsu/x5bLv8eWy7/Hlwu/x5cLv8eXC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5f
	L/8eXy//HmAv/x5gMP8eYDD/HmEw/x9hMP8fYTD/H2Iw/x9iMP8fYjD/H2Mx/x1dLv4AAAAA////
	AP///wD///8A////AP///wD///8A////AP///wA8aEgfdMmK/3PJiv9zyIr/csiJ/3LIif9xx4j/
	cceI/3DHh/9wxof/b8aG/2/Ghv9uxYX/bsWF/23Fhf9txIT/bMSE/2zEg/9rw4P/asOC/2rDgv9p
	woH/acKB/2jCgP9owoD/Z8F//2fBf/9mwX//ZsB+/2XAfv9lwH3/ZL99/2S/fP9jv3z/Y757/2K+
	e/9ivnr/Yb16/2G9ev9gvXn/YLx5/1+8eP9fvHj/Xrt3/167d/9du3b/Xbp2/1y6df9cunX/W7l0
	/1u5dP9auXT/Wrhz/1m4c/9ZuHL/WLhy/1i3cf9Xt3H/Vrdw/1a2cP9Vtm//XLl1/zRcQP8cUCr/
	HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HVQr/x1VK/8d
	VSz/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1YLf8dWC3/HVgt/x1ZLf8dWS3/HVot/x1a
	Lf8dWi3/HVou/x5bLv8eWy7/Hlsu/x5cLv8eXC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl4v
	/x5fL/8eXy//HmAv/x5gL/8eYDD/HmEw/x9hMP8fYTD/H2Iw/x9iMP8fYjD/HV0t/v///wD///8A
	////AP///wD///8A////AP///wD///8A////ADxoSB90yYv/dMmL/3PJiv9zyIr/csiJ/3LIif9x
	x4j/cceI/3DHh/9wxof/b8aH/2/Ghv9uxYb/bsWF/23Fhf9txIT/bMSE/2zEg/9rxIP/a8OC/2rD
	gv9qw4H/acKB/2nCgf9owoD/aMGA/2fBf/9nwX//ZsB+/2bAfv9lwH3/ZL99/2S/fP9jv3z/Y757
	/2K+e/9ivnv/Yb16/2G9ev9gvXn/YLx5/1+8eP9fvHj/Xrt3/167d/9du3b/Xbt2/1y6dv9cunX/
	W7p1/1u5dP9auXT/Wrlz/1m4c/9ZuHL/WLhy/1i3cf9Xt3H/V7dw/1a2cP9duXb/NFs//xxQKv8c
	UCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HVQr/x1V
	K/8dVSz/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1YLf8dWC3/HVgt/x1ZLf8dWS3/HVkt
	/x1aLf8dWi3/HVot/x5bLv8eWy7/Hlsu/x5cLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8eXi//
	Hl4v/x5fL/8eXy//Hl8v/x5gL/8eYDD/HmAw/x5hMP8fYTD/H2Ew/x9iMP8dXC3+////AP///wD/
	//8A////AP///wD///8A////AP///wD///8APWhIH3XKjP91yYv/dMmL/3TJiv9zyIr/c8iJ/3LI
	if9yyIn/cceI/3HHiP9wx4f/b8aH/2/Ghv9uxob/bsWF/23Fhf9txYT/bMSE/2zEg/9rxIP/a8OD
	/2rDgv9qw4L/acKB/2nCgf9owoD/aMGA/2fBf/9nwX//ZsB+/2bAfv9lwH3/Zb99/2S/ff9kv3z/
	Y758/2O+e/9ivnv/Yr56/2G9ev9hvXn/YL15/2C8eP9fvHj/Xrx4/167d/9du3f/Xbt2/1y6dv9c
	unX/W7p1/1u5dP9auXT/Wrlz/1m4c/9ZuHL/WLhy/1i3cv9Xt3H/V7dx/125dv80Wz//HE8p/xxP
	Kv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HFQr
	/x1VK/8dVSv/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1YLP8dWC3/HVgt/x1ZLf8dWS3/
	HVkt/x1aLf8dWi3/HVot/x5bLv8eWy7/Hlsu/x5cLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8e
	Xi//Hl4v/x5fL/8eXy//Hl8v/x5gL/8eYDD/HmAw/x5hMP8fYTD/H2Ew/x1cLf7///8A////AP//
	/wD///8A////AP///wD///8A////AP///wA9aUkfdsqM/3XKjP91yov/dMmL/3TJiv9zyYr/c8iK
	/3LIif9yyIn/cceI/3HHiP9wx4f/cMaH/2/Ghv9vxob/bsWF/27Fhf9txYX/bcSE/2zEhP9sxIP/
	a8OD/2rDgv9qw4L/acKB/2nCgf9owoD/aMKA/2fBf/9nwX//ZsF//2bAfv9lwH7/ZcB9/2S/ff9k
	v3z/Y798/2O+e/9ivnv/Yr56/2G9ev9hvXr/YL15/2C8ef9fvHj/X7x4/167d/9eu3f/Xbt2/126
	dv9cunX/XLp1/1u5dP9buXT/Wrl0/1m4c/9ZuHP/WLhy/1i3cv9Xt3H/Xrp3/zRbP/8cTyn/HE8p
	/xxPKf8cUCr/HFAq/xxQKv8cUSr/HFEq/xxRKv8cUir/HFIq/xxSK/8cUyv/HFMr/xxTK/8cVCv/
	HFQr/x1UK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWC3/HVgt/x1YLf8d
	WS3/HVkt/x1ZLf8dWi3/HVot/x1aLv8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/Hl0u/x5d
	L/8eXi//Hl4v/x5eL/8eXy//Hl8v/x5fL/8eYC//HmAw/x5gMP8eYTD/HVst/v///wD///8A////
	AP///wD///8A////AP///wD///8A////AD1pSR92y43/dsqM/3XKjP91yoz/dMmL/3TJi/9zyYr/
	c8iK/3LIif9yyIn/cceI/3HHiP9wx4f/cMaH/2/Gh/9vxob/bsWG/27Fhf9txYX/bcSE/2zEhP9s
	xIP/a8SD/2vDgv9qw4L/asOB/2nCgf9pwoH/aMKA/2jBgP9nwX//Z8F//2bAfv9mwH7/ZcB9/2S/
	ff9kv3z/Y798/2O+e/9ivnv/Yr57/2G9ev9hvXr/YL15/2C8ef9fvHj/X7x4/167d/9eu3f/Xbt2
	/127dv9cunb/XLp1/1u6df9buXT/Wrl0/1q5c/9ZuHP/Wbhy/1i4cv9funf/M1s//xxOKf8cTyn/
	HE8p/xxPKf8cUCr/HFAq/xxQKv8cUSr/HFEq/xxRKv8cUir/HFIq/xxSK/8cUyv/HFMr/xxTK/8c
	VCv/HFQr/xxUK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWCz/HVgt/x1Y
	Lf8dWS3/HVkt/x1ZLf8dWi3/HVot/x1aLf8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/Hl0u
	/x5dL/8eXi//Hl4v/x5eL/8eXy//Hl8v/x5fL/8eYC//HmAw/x5gMP8cWy3+////AP///wD///8A
	////AP///wD///8A////AP///wD///8APmlJH3fLjv93y43/dsqN/3bKjP91yoz/dcmL/3TJi/90
	yYr/c8iK/3LIif9yyIn/cceI/3HHiP9wx4j/cMeH/2/Gh/9vxob/bsaG/27Fhf9txYX/bcWE/2zE
	hP9sxIP/a8SD/2vDg/9qw4L/asOC/2nCgf9pwoH/aMKA/2jBgP9nwX//Z8F//2bAfv9mwH7/ZcB9
	/2W/ff9kv33/ZL98/2O+fP9jvnv/Yr57/2K+ev9hvXr/Yb15/2C9ef9gvHj/X7x4/168eP9eu3f/
	Xbt3/127dv9cunb/XLp1/1u6df9buXT/Wrl0/1q5c/9ZuHP/Wbhy/1+7eP8zWj//G04p/xxOKf8c
	Tin/HE8p/xxPKf8cTyr/HFAq/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSK/8cUiv/HFMr/xxT
	K/8cUyv/HFQr/xxUK/8dVCv/HVUr/x1VLP8dViz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgt
	/x1YLf8dWS3/HVkt/x1ZLf8dWi3/HVot/x1aLf8dWi7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/
	Hl0u/x5dL/8eXi//Hl4v/x5eL/8eXy//Hl8v/x5fL/8eYC//HmAv/xxaLf7///8A////AP///wD/
	//8A////AP///wD///8A////AP///wA+aUofeMuO/3fLjv93y43/dsuN/3bKjP91yoz/dcqL/3TJ
	i/90yYr/c8mK/3PIiv9yyIn/csiJ/3HHiP9xx4j/cMeH/3DGh/9vxob/b8aG/27Fhf9uxYX/bcWF
	/23EhP9sxIT/bMSD/2vDg/9qw4L/asOC/2nCgf9pwoH/aMKA/2jBgP9nwX//Z8F//2bAf/9mwH7/
	ZcB+/2XAff9kv33/ZL98/2O/fP9jvnv/Yr57/2K+ev9hvXr/Yb15/2C9ef9gvHn/X7x4/1+8eP9e
	u3f/Xrt3/127dv9dunb/XLp1/1y6df9buXT/W7l0/1q5dP9ZuHP/YLt4/zNaP/8bTSn/G04p/xtO
	Kf8cTin/HE8p/xxPKf8cTyn/HFAq/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr
	/xxTK/8cUyv/HFQr/xxUK/8dVCv/HVUr/x1VLP8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/
	HVgt/x1YLf8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi3/Hlsu/x5bLv8eWy7/Hlwu/x5cLv8e
	XC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8eXy//HFos/v///wD///8A////AP//
	/wD///8A////AP///wD///8A////AD5pSh95zI//eMyO/3fLjv93y43/dsuN/3bKjP91yoz/dcqM
	/3TJi/90yYv/c8mK/3PIiv9yyIn/csiJ/3HHiP9xx4j/cMeH/3DGh/9vxof/b8aG/27Fhv9uxYX/
	bcWF/23EhP9sxIT/bMSD/2vEg/9rw4L/asOC/2rDgf9pwoH/acKB/2jCgP9owYD/Z8F//2fBf/9m
	wH7/ZsB+/2XAff9kv33/ZL98/2O/fP9jvnv/Yr57/2K+e/9hvXr/Yb16/2C9ef9gvHn/X7x4/1+8
	eP9eu3f/Xrt3/127dv9dunb/XLp1/1y6df9bunX/W7l0/1q5dP9gvHj/M1o+/xtNKf8bTSn/G04p
	/xtOKf8cTin/HE8p/xxPKf8cTyn/HFAq/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/
	HFMr/xxTK/8cUyv/HFQr/xxUK/8cVCv/HVUr/x1VLP8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8d
	Vyz/HVgs/x1YLf8dWC3/HVkt/x1ZLf8dWS3/HVot/x1aLf8dWi3/Hlsu/x5bLv8eWy7/Hlwu/x5c
	Lv8eXC7/Hl0u/x5dLv8eXS//Hl4v/x5eL/8eXi//Hl8v/x5fL/8cWSz+////AP///wD///8A////
	AP///wD///8A////AP///wD///8AP2pKH3nMj/95zI//eMyO/3jLjv93y47/d8uN/3bKjf92yoz/
	dcqM/3XJi/90yYv/dMmK/3PIiv9yyIn/csiJ/3HHiP9xx4j/cMeI/3DHh/9vxof/b8aG/27Ghv9u
	xYX/bcWF/23FhP9sxIT/bMSD/2vEg/9rw4P/bMSE/3DFh/9yxoj/cb+G/2mufP9oqHr/ZrJ7/2fB
	f/9mwH7/ZsB+/2XAff9lv33/ZL99/2S/fP9jvnz/Y757/2K+e/9ivnr/Yb16/2G9ef9gvXn/YLx4
	/1+8eP9evHj/Xrt3/127d/9du3b/XLp2/1y6df9bunX/W7l0/2C8ef80WT7/G0wo/xtNKf8bTSn/
	G00p/xtOKf8cTin/HE4p/xxPKf8cTyn/HE8q/xxQKv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8c
	Uir/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HVQr/x1VK/8dVSz/HVUs/x1WLP8dViz/HVYs/x1X
	LP8dVyz/HVcs/x1YLf8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVou/x5bLv8eWy7/Hlsu
	/x5cLv8eXC7/Hlwu/x5dLv8eXS//Hl0v/x5eL/8eXi//Hl4v/xxZLP7///8A////AP///wD///8A
	////AP///wD///8A////AP///wA/akofes2Q/3nMkP95zI//eMyP/3jLjv93y47/d8uN/3bKjf92
	yoz/dcqM/3XJi/90yYv/dMmK/3PJiv9zyIr/csiJ/3LIif9xx4j/cceI/3DHh/9wxof/b8aG/3DG
	h/9zx4n/dciL/3bGiv9vtIL/aqp8/2qpff9rrYD/arWF/27Gjv9w0ZT/asuN/2PDhv9jvoD/Z8F/
	/2fBf/9mwH//ZsB+/2XAfv9lwH3/ZL99/2S/fP9jv3z/Y757/2K+e/9ivnr/Yb16/2G9ef9gvXn/
	YLx5/1+8eP9fvHj/Xrt3/167d/9du3b/Xbp2/1y6df9cunX/Ybx5/zRZPv8bTCj/G0wo/xtNKP8b
	TSn/G00p/xtOKf8bTin/HE4p/xxPKf8cTyn/HE8p/xxQKv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxS
	Kv8cUir/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HVQr/x1VK/8dVSz/HVUs/x1WLP8dViz/HVYs
	/x1XLP8dVyz/HVcs/x1YLf8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVot/x5bLv8eWy7/
	Hlsu/x5cLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8eXi//HFgs/v///wD///8A////AP///wD/
	//8A////AP///wD///8A////AD9qSx97zZH/es2Q/3rNkP95zI//ecyP/3jMjv93y47/d8uN/3bL
	jf92yoz/dcqM/3XKjP90yYv/dMmL/3PJiv90yIr/dcmM/3nLj/96y5D/dbyI/22uf/9sqX7/bKyB
	/2uzg/9uwIr/cNCU/2vMj/9lxYj/Xr6B/1m2e/9WsHf/Uqpy/0+jbf9MnWn/SZdk/1epcP9owoD/
	Z8GA/2fBf/9mwX//ZsB+/2XAfv9lwH3/ZL99/2S/fP9jv3z/Y757/2K+e/9ivnv/Yb16/2G9ev9g
	vXn/YLx5/1+8eP9fvHj/Xrt3/167d/9du3b/Xbp2/1y6df9ivXr/NFk+/xtLKP8bTCj/G0wo/xtM
	KP8bTSn/G00p/xtNKf8bTin/HE4p/xxOKf8cTyn/HE8p/xxPKv8cUCr/HFAq/xxQKv8cUSr/HFEq
	/xxSKv8cUir/HFIr/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/x1VK/8dVSv/HVUs/x1WLP8dViz/
	HVYs/x1XLP8dVyz/HVcs/x1YLP8dWC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVot/x1bLv8e
	Wy7/Hlsu/x5cLv8eXC7/Hlwu/x5dLv8eXS7/Hl0v/x5eL/8cWCz+////AP///wD///8A////AP//
	/wD///8A////AP///wD///8AQGpLH3vOkf97zZH/es2Q/3rNkP95zI//ecyP/3jMjv94y47/d8uO
	/3nMjv97zJH/f82T/3vFj/9zs4T/b6yA/2+rgf9ssIP/bLuJ/3DMkf9tzpH/Z8eK/2C/gv9auHz/
	VrJ4/1Orc/9QpW//TZ9q/0mYZv9GkmH/Q4xd/0CFWP88f1T/OXlP/zZyS/8zbEb/TJRi/2nCgf9o
	woD/aMGA/2fBf/9nwX//ZsB+/2bAfv9lwH3/Zb99/2S/ff9kv3z/Y758/2O+e/9ivnv/Yb16/2G9
	ev9gvXn/YLx5/1+8eP9fvHj/Xrx3/167d/9du3f/Xbt2/2K9e/80WT7/G0so/xtLKP8bTCj/G0wo
	/xtMKP8bTSn/G00p/xtNKf8bTin/HE4p/xxOKf8cTyn/HE8p/xxPKf8cUCr/HFAq/xxQKv8cUSr/
	HFEq/xxRKv8cUir/HFIq/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/x1UK/8dVSv/HVUs/x1VLP8d
	Viz/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWC3/HVgt/x1YLf8dWS3/HVkt/x1ZLf8dWi3/HVot/x1a
	Lv8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/Hl0u/xxYLP7///8A////AP///wD///8A////
	AP///wD///8A////AP///wBAaksffM6S/3vOkf97zZH/es2Q/3rNkP95zI//ecyP/3jMj/94y47/
	ZKR1/1CCYP9Xl23/YrWB/2fHiv9iwoX/W7l+/1ezef9UrXT/Uadw/02ga/9Kmmf/R5Ri/0SNXv9A
	h1n/PYFV/zp6UP83dEz/M25H/zBnQ/8tYT7/Kls6/yZUNf8jTjH/IEgs/x1BKP9Cf1P/acKB/2nC
	gf9owoD/aMGA/2fBf/9nwX//ZsB//2bAfv9lwH7/ZcB9/2S/ff9kv3z/Y798/2O+e/9ivnv/Yr56
	/2G9ev9hvXn/YL15/2C8ef9fvHj/X7x4/167d/9eu3f/Y757/zRZPv8bSyj/G0so/xtLKP8bTCj/
	G0wo/xtMKP8bTSj/G00p/xtNKf8bTin/G04p/xxOKf8cTyn/HE8p/xxPKf8cUCr/HFAq/xxQKv8c
	USr/HFEq/xxRKv8cUir/HFIq/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/xxUK/8dVSv/HVUs/x1V
	LP8dViz/HVYs/x1WLP8dVyz/HVcs/x1XLP8dWCz/HVgt/x1YLf8dWS3/HVkt/x1ZLf8dWi3/HVot
	/x1aLf8eWy7/Hlsu/x5bLv8eXC7/Hlwu/x5cLv8eXS7/HFgr/v///wD///8A////AP///wD///8A
	////AP///wD///8A////AEFrTB99zpL/fM6S/3zOkv97zZH/e82R/3rNkP96zZD/ecyP/3jMj/9P
	il7/GUcm/xpGJv8ZRSX/GkQl/x9KK/8kUTL/KFk4/y1gP/8ya0X/NnRL/zRvSP8xaUT/LmM//ypc
	O/8nVjb/JFAy/yFJLf8dQyn/Gj0k/xc2IP8UMBv/ECoX/w0jEv8NIxL/DSMS/zxzSv9qw4L/asOB
	/2nCgf9pwoD/aMKA/2fBgP9nwX//ZsF//2bAfv9lwH7/ZcB9/2S/ff9kv3z/Y798/2O+e/9ivnv/
	Yr57/2G9ev9hvXr/YL15/2C8ef9fvHj/X7x4/167d/9kvnz/NFk9/xtKKP8bSij/G0so/xtLKP8b
	Syj/G0wo/xtMKP8bTCj/G00p/xtNKf8bTSn/G04p/xxOKf8cTin/HE8p/xxPKf8cTyr/HFAq/xxQ
	Kv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8cUyv/HFQr/xxUK/8dVCv/HVUr
	/x1VLP8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgt/x1YLf8dWC3/HVkt/x1ZLf8dWS3/
	HVot/x1aLf8dWi7/Hlsu/x5bLv8eWy7/Hlwu/x5cLv8cWCv+////AP///wD///8A////AP///wD/
	//8A////AP///wD///8AQWtMH33Pk/99z5P/fM6S/3zOkv97zpH/e82R/3rNkP96zZD/ecyP/1CK
	X/8ZRib/GkYl/xlEJf8ZRCT/GEEj/xdAIv8WPSD/FToe/xM3Hf8UNBz/EzMc/xQxHP8TLhr/EiwY
	/w8nFv8OJBL/DSMS/w0jEv8NIxL/DSMS/w0jEv8NIxL/DSMS/w0jEv8NIxL/PHRL/2vDgv9qw4L/
	asOC/2nCgf9pwoH/aMKA/2jBgP9nwX//Z8F//2bAfv9mwH7/ZcB9/2W/ff9kv3z/ZL98/2O+fP9j
	vnv/Yr57/2G9ev9hvXr/YL15/2C8ef9fvHj/X7x4/2S/fP80WD3/G0on/xtKKP8bSij/G0so/xtL
	KP8bSyj/G0wo/xtMKP8bTCj/G00o/xtNKf8bTSn/G04p/xtOKf8cTin/HE8p/xxPKf8cTyn/HFAq
	/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8cUyv/HFQr/xxUK/8dVCv/
	HVUr/x1VLP8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgt/x1YLf8dWC3/HVkt/x1ZLf8d
	WS3/HVot/x1aLf8dWi3/Hlsu/x5bLv8eWy7/Hlwu/xxXK/7///8A////AP///wD///8A////AP//
	/wD///8A////AP///wBBa0wffs+U/33Pk/99z5P/fM6S/3zOkv97zpH/e82R/3rNkP96zZD/UIpf
	/xlGJv8aRSX/GUQk/xlDJP8YQSP/Fz8i/xY9IP8VOh7/EzYc/xMxGv8QLRf/DicU/w0kE/8NIxL/
	DSMS/w0jEv8NJBL/DiUT/w0kEv8MIhL/DCAR/w0iEf8NIxL/DSMS/w0jEv89dEv/a8SD/2vDg/9q
	w4L/asOC/2nCgf9pwoH/aMKA/2jBgP9nwX//Z8F//2bAf/9mwH7/ZcB+/2XAff9kv33/ZL98/2O/
	fP9jvnv/Yr57/2K+ev9hvXr/Yb15/2C9ef9gvHj/Zb99/zRYPf8bSSf/G0kn/xtKJ/8bSij/G0oo
	/xtLKP8bSyj/G0so/xtMKP8bTCj/G0wo/xtNKf8bTSn/JFUx/yRVMf8fUCz/HE4p/xxPKf8cTyn/
	HE8q/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8cUyv/HFQr/xxUK/8c
	VCv/HVUr/x1VK/8dVSz/HVYs/x1WLP8dViz/HVcs/x1XLP8dVyz/HVgs/x1YLf8dWC3/HVkt/x1Z
	Lf8dWS3/HVot/x1aLf8dWi3/Hlsu/x5bLv8eWy7/HFcr/v///wD///8A////AP///wD///8A////
	AP///wD///8A////AEJrTR9/0JT/fs+U/37Pk/99z5P/fc6S/3zOkv98zpH/e82R/3rNkf9QimD/
	GUUm/xpFJf8ZQyT/GUMj/xhBI/8XPyL/Fjsf/xQ2HP8RMRn/ES0X/w8pFf8OJRP/DSQT/w0jEv8N
	IxL/DSMS/w0jEv8NIxL/DSMS/w0jEv8NIxL/DSMS/w0jEv8NJRP/DSQT/z1zS/9sxIT/bMSD/2vD
	g/9rw4L/asOC/2rDgf9pwoH/acKA/2jCgP9nwYD/Z8F//2bBf/9mwH7/ZcB+/2XAff9kv33/ZL98
	/2O/fP9jvnv/Yr57/2K+e/9hvXr/Yb16/2C9ef9mv37/NFc9/xtJJ/8bSSf/G0kn/xtKJ/8bSij/
	G0oo/xtLKP8bSyj/G0so/xtMKP8bTCj/G0wo/xtNKf8mTDD/L043/zRTPf80VDz/MFU5/y1bOP8n
	VzP/IFIt/xxQKv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/HFIr/xxTK/8cUyv/HFMr/xxU
	K/8cVCv/HVQr/x1VK/8dVSz/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1YLf8dWC3/HVgt
	/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVou/x5bLv8cViv+////AP///wD///8A////AP///wD///8A
	////AP///wD///8AQmtNH3/Qlf9/0JT/ftCU/37Pk/99z5P/fc+T/3zOkv98zpL/e86R/1GKYP8Z
	RSb/GkQl/xlDJP8YQiP/Fz8h/xU6H/8TNRz/Ei8Y/w4qFv8QKRX/DygV/w4lE/8NJBP/DSMS/w0j
	Ev8NIxL/DSMS/w0jEv8NIxL/DSMS/w0jEv8NIxL/DiQS/yAtEP80OA7/UHU//23FhP9sxIT/bMSD
	/2vEg/9rw4L/asOC/2rDgv9pwoH/acKB/2jCgP9owYD/Z8F//2fBf/9mwH7/ZsB+/2XAff9lv33/
	ZL98/2S/fP9jvnz/Y757/2K+e/9hvXr/Yb16/2bAfv80Vz3/G0gn/xtJJ/8bSSf/G0kn/xtKJ/8b
	Sij/G0oo/xtLKP8bSyj/G0so/xtMKP8bTCj/G0wo/xU7IP8UNB3/FTYe/xs8JP8iQyr/KEgx/y9M
	Nv8zUjv/NVU+/zBXOv8uWzr/KFo2/yJWMP8dUiv/HFEq/xxSKv8cUir/HFIr/xxTK/8cUyv/HFMr
	/xxUK/8cVCv/HFQr/x1VK/8dVSz/HVUs/x1WLP8dViz/HVYs/x1XLP8dVyz/HVcs/x1YLP8dWC3/
	HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/HVot/xxWK/7///8A////AP///wD///8A////AP///wD/
	//8A////AP///wBCbE0fgNGV/3/Qlf9/0JX/ftCU/37PlP99z5P/fc+T/3zOkv98zpL/UYtg/xlE
	Jv8aQyX/F0Aj/xY8IP8VNx3/EjEa/xArFv8PKhb/DikV/xApFf8PKBX/DiUT/w0kE/8NIxL/DSMS
	/xsrEf8vNw7/RUIM/1pPCv9uWgf/hGUF/5dwA/+qfAD/rXwA/6x8AP90dyb/bcWF/23FhP9sxIT/
	bMSD/2vEg/9rw4P/asOC/2rDgv9pwoH/acKB/2jCgP9owYD/Z8F//2fBf/9mwH7/ZsB+/2XAfv9l
	v33/ZL99/2S/fP9jv3z/Y757/2K+e/9ivnr/Z8B//zRXPf8bSCf/G0gn/xtIJ/8bSSf/G0kn/xtJ
	J/8bSif/G0oo/xtKKP8bSyj/G0so/xtLKP8bTCj/FDYd/xEsGf8SLhn/Ei8a/xMxGv8UMxz/FDQd
	/xU1Hf8ZOiL/IEEp/yZHMP8sTDX/MVA6/zZVP/8xVjv/Llo6/ypcN/8kWDL/HlMt/xxSK/8cUyv/
	HFMr/xxTK/8cVCv/HFQr/x1UK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8dVyz/HVcs/x1XLP8d
	WC3/HVgt/x1ZLf8dWS3/HVkt/x1aLf8dWi3/G1Uq/v///wD///8A////AP///wD///8A////AP//
	/wD///8A////AENsTR+B0Zb/gNGW/4DQlf9/0JX/f9CU/37PlP9+z5P/fc+T/33Okv9Si2H/GUEj
	/xY8IP8UNx3/EjAZ/w8qFv8PKhb/DyoW/xcuFf8sORH/Q0QP/1dQDP9sWgj/gmUG/5dyA/+sfQH/
	s4EA/7KAAP+xgAD/sX8A/7B/AP+wfgD/r34A/659AP+ufQD/rX0A/3V5Jv9uxYb/bsWF/23Fhf9t
	xIT/bMSE/2zEg/9rw4P/a8OC/2rDgv9qw4H/acKB/2nCgP9owoD/Z8GA/2fBf/9mwX//ZsB+/2XA
	fv9lwH3/ZL99/2S/fP9jv3z/Y757/2K+e/9owX//NFc+/xpHJ/8aSCf/G0gn/xtIJ/8bSSf/G0kn
	/xtJJ/8bSif/G0oo/xtKKP8bSyj/G0so/xtLKP8QLxn/DiMT/w4lE/8PJxb/ECkW/xAqF/8RLBj/
	ES0Z/xIuGv8TMRr/EzIb/xQzHP8VNB3/Fzgg/x0/J/8lRS3/LEsz/zFPOP81VT3/NFY9/zBaPP8t
	YDv/J1s1/yBWL/8cVCv/HFQr/x1UK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8dVyz/HVcs/x1X
	LP8dWC3/HVgt/x1YLf8dWS3/HVkt/x1ZLf8bVSr+////AP///wD///8A////AP///wD///8A////
	AP///wD///8AQ2xOH4HRl/+B0Zb/gNGW/4DQlf9/0JX/f9CU/37PlP9+z5P/fc+T/1WNYP8sQRj/
	QUcR/1RPDP9rWwr/gWcH/5ZzBf+sfgL/uYUA/7iFAP+4hAD/t4QA/7aDAP+2gwD/tYIA/7WCAP+0
	ggD/s4EA/7KBAP+ygAD/sYAA/7F/AP+wfwD/r34A/69+AP+ufQD/dXkn/2/Ghv9uxob/bsWF/23F
	hf9txYT/bMSE/2zEg/9rxIP/a8OC/2rDgv9qw4L/acKB/2nCgf9owoD/aMGA/2fBf/9nwX//ZsB+
	/2bAfv9lwH3/Zb99/2S/fP9kv3z/Y758/2nBgP80Vz7/Gkcm/xpHJ/8aRyf/G0gn/xtIJ/8bSCf/
	G0kn/xtJJ/8bSif/G0on/xtKKP8bSij/G0so/w4oFf8KGQ7/ChsP/wsdD/8LHxH/DCES/w4iE/8O
	JRP/DyYV/w8oFf8PKRf/ESsX/xEtGf8SLxn/EzAb/xMxG/8TMxz/FDQd/xY3H/8bPCX/I0Qr/ylJ
	Mv8vTjj/NFM9/zVYP/8wWjv/LWA7/xxUK/8dVSv/HVUs/x1VLP8dViz/HVYs/x1WLP8dVyz/HVcs
	/x1XLP8dWCz/HVgt/x1YLf8dWS3/HVkt/xtUKv7///8A////AP///wD///8A////AP///wD///8A
	////AP///wBEbE4fgtKX/4LSl/+B0Zb/gNGW/4DRlf9/0JX/f9CV/37QlP9+z5T/hJI/6b+JAP++
	iQD/vYgA/72IAP+8iAD/u4cA/7uHAP+6hgD/uYYA/7mFAP+4hQD/t4QA/7eEAP+2gwD/toMA/7WC
	AP+0ggD/tIEA/7OBAP+ygAD/soAA/7GAAP+wfwD/sH8A/69+AP92eSf/b8aH/2/Ghv9uxob/bsWF
	/23Fhf9txYT/bMSE/2zEg/9rxIP/a8OD/2rDgv9qw4L/acKB/2nCgf9owoD/aMGA/2fBf/9nwX//
	ZsB+/2bAfv9lwH7/Zb99/2S/ff9kv3z/acKB/zRXPv8aRib/Gkcm/xpHJv8aRyf/Gkgn/xtIJ/8b
	SCf/G0kn/xtJJ/8bSSf/G0on/xtKKP8bSij/DSUU/wcTCv8HEwr/BxMK/wgVC/8IFwv/CRgN/woa
	Dv8LHA//Cx4R/wwgEf8OIhL/DSQU/w4lFf8PJxX/ECgW/xErF/8RKxj/ESwY/xAsGf8SLRn/ES4Z
	/xIvGv8TMhv/Gzoh/yVHLf81Vz//HFQr/xxUK/8dVCv/HVUr/x1VLP8dVSz/HVYs/x1WLP8dViz/
	HVcs/x1XLP8dVyz/HVgt/x1YLf8dWC3/G1Qq/v///wD///8A////AP///wD///8A////AP///wD/
	//8A////AERtTh+D0pj/gtKX/4LSl/+B0Zb/gdGW/4DRlv+A0JX/f9CV/3/QlP+FkkDpwIoA/7+K
	AP++iQD/vokA/72IAP+8iAD/vIcA/7uHAP+6hgD/uoYA/7mFAP+4hQD/uIUA/7eEAP+3hAD/toMA
	/7WDAP+1ggD/tIIA/7OBAP+zgQD/soAA/7GAAP+xfwD/sH8A/3Z5J/9wx4f/cMaH/2/Ghv9vxob/
	bsWF/27Fhf9txYX/bcSE/2zEhP9sxIP/a8OD/2rDgv9qw4L/acKB/2nCgf9owoD/aMKA/2fBf/9n
	wX//ZsF//2bAfv9lwH7/ZcB9/2S/ff9qwoH/NFc+/xpGJv8aRib/Gkcm/xpHJv8aRyf/Gkgn/xtI
	J/8bSCf/G0kn/xtJJ/8bSSf/G0on/xtKKP8NJBT/BxMK/wcTCv8HEwr/BxMK/wcTCv8HEwr/CBYL
	/woZDf8LHQ//DCAR/w0jE/8OJRT/DicV/w4oFv8QKRb/ECsX/xIuGf8SMhv/FDUe/xU3H/8WOSD/
	Fzsh/xg9Iv8YPyP/HUMn/zVXP/8cUyv/HFQr/xxUK/8dVCv/HVUr/x1VLP8dVSz/HVYs/x1WLP8d
	Viz/HVcs/x1XLP8dVyz/HVgt/x1YLf8bUyr+////AP///wD///8A////AP///wD///8A////AP//
	/wD///8ARG1PH4PTmP+D0pj/gtKY/4LSl/+B0Zf/gdGW/4DRlv+A0JX/f9CV/4eSQOnBiwD/wIoA
	/7+KAP+/igD/vokA/72JAP+9iAD/vIgA/7uHAP+7hwD/uoYA/7qGAP+5hQD/uIUA/7iEAP+3hAD/
	toMA/7aDAP+1ggD/tIIA/7SCAP+zgQD/soEA/7KAAP+xgAD/eHsn/nHHiP9wx4f/cMaH/2/Gh/9v
	xob/bsaG/27Fhf9txYX/bcWE/2zEhP9sxIP/a8SD/2vDgv9qw4L/asOC/2nCgf9pwoH/aMKA/2jB
	gP9nwX//Z8F//2bAfv9mwH7/ZcB9/2rCgv80Vj7/GkUm/xpGJv8aRib/GkYm/xpHJv8aRyb/Gkcn
	/xtIJ/8bSCf/G0gn/xtJJ/8bSSf/G0kn/xAsGP8MIBL/DCIS/wwiEv8MIBH/Cx4O/woYDP8JFgz/
	CBcN/woZDf8JGg7/ChsP/woeD/8NIBH/DSIS/w4lFP8OJxX/ECoX/xEtGP8SMRv/EzMc/xU3Hv8W
	OiD/GD0i/xg/I/8dQyf/NVc//xxTK/8cUyv/HFMr/xxUK/8cVCv/HVUr/x1VK/8dVSz/HVYs/x1W
	LP8dViz/HVYs/x1XLP8dVyz/HVgs/xtTKv7///8A////AP///wD///8A////AP///wD///8A////
	AP///wBFbU8fhNOZ/4PTmf+D0pj/gtKY/4LSl/+B0Zf/gdGW/4DRlv+A0ZX/h5NA6cKMAP/BiwD/
	wIsA/8CKAP+/igD/vokA/76JAP+9iAD/vIgA/7yHAP+7hwD/u4cA/7qGAP+5hgD/uYUA/7iFAP+3
	hAD/t4QA/7aDAP+1gwD/tYIA/7SCAP+zgQD/s4EA/7KAAP+GgijfcsiJ/3HHiP9xx4j/cMeH/2/G
	h/9vxob/bsaG/27Fhf9txYX/bcWE/2zEhP9sxIP/a8SD/2vDg/9qw4L/asOC/2nCgf9pwoH/aMKA
	/2jBgP9nwX//Z8F//2bAfv9mwH7/a8KD/zRWPv8aRSb/GkUm/xpGJv8aRib/GkYm/xpHJv8aRyb/
	Gkcn/xpIJ/8bSCf/G0gn/xtJJ/8bSSf/DSUU/wgVC/8IFQv/CBUL/wgVC/8IFQv/CBUL/wkWDP8I
	Fw3/ChkN/wkaDf8KGw7/ChwO/wweEP8MHxD/DSES/w0kE/8PJhX/DykV/xEsGP8SLxn/EzIb/xQ1
	Hf8WOSD/GDwi/xxDJv81Vz7/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HVQr/x1VK/8dVSz/HVUs
	/x1WLP8dViz/HVYs/x1XLP8dVyz/G1Ip/v///wD///8A////AP///wD///8A////AP///wD///8A
	////AEVtTx+F1Jr/hNOZ/4TTmf+D05j/g9KY/4LSl/+C0pf/gdGW/4HRlv+Hk0Dpw4wA/8KMAP/B
	jAD/wYsA/8CLAP/AigD/v4oA/76JAP++iQD/vYgA/7yIAP+8hwD/u4cA/7qGAP+6hgD/uYUA/7iF
	AP+4hAD/t4QA/7aDAP+2gwD/tYMA/7WCAP+0ggD/s4EA/4aDKN9yyIn/csiJ/3HHiP9xx4j/cMeH
	/3DGh/9vxob/b8aG/27Fhf9uxYX/bcWF/23EhP9sxIT/bMSD/2vDg/9qw4L/asOC/2nCgf9pwoH/
	aMKA/2jCgP9nwX//Z8F//2bBf/9swoP/NFU9/xpEJv8aRSb/GkUm/xpGJv8aRib/GkYm/xpGJv8a
	Ryb/Gkcn/xpHJ/8bSCf/G0gn/xtJJ/87Nwn/QzUE/zUuBv8nJgf/GR4J/wsWC/8IFQv/CRYM/wgX
	Df8KGQ3/CRoN/wobDv8KHA7/Cx0P/wseD/8MHxD/DCAQ/w0jEv8OJBP/DygW/xAqFv8RLRj/Ei8Z
	/xQzHP8VNh7/Gjwi/zVXPv8cUir/HFIr/xxTK/8cUyv/HFMr/xxUK/8cVCv/HFQr/x1VK/8dVSz/
	HVUs/x1WLP8dViz/HVYs/x1XLP8bUin+////AP///wD///8A////AP///wD///8A////AP///wD/
	//8ARW1QH4XUmv+F1Jr/hNOZ/4TTmf+D05j/g9KY/4LSmP+C0pf/gdGX/4iTQOnEjQD/w40A/8KM
	AP/CjAD/wYsA/8GLAP/AigD/v4oA/7+JAP++iQD/vYgA/72IAP+8iAD/u4cA/7uHAP+6hgD/uYYA
	/7mFAP+4hQD/uIQA/7eEAP+2gwD/toMA/7WCAP+0ggD/hoMo33PIiv9yyIn/csiJ/3HHiP9xx4j/
	cMeH/3DGh/9vxof/b8aG/27Fhv9uxYX/bcWF/23EhP9sxIT/bMSD/2vEg/9rw4L/asOC/2rDgf9p
	woH/acKB/2jCgP9owYD/Z8F//23DhP80VT3/GkQl/xpEJf8aRSb/GkUm/xpFJv8aRib/GkYm/xpG
	Jv8aRyb/Gkcm/xpHJ/8aSCf/G0gn/0c7Bv9iRgD/YkcA/2JHAP9jRwD/YkYA/1dBAf9KOQP/OzIG
	/y0rCP8eJQr/ER4N/wocDv8LHQ//Cx4P/wwfEP8LHxD/DCAR/wwhEf8NIxP/DSUU/w8nFP8QKRX/
	ES0Y/xIvGv8XNR//NVc+/xxRKv8cUir/HFIq/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/x1UK/8d
	VSv/HVUs/x1VLP8dViz/HVYs/xtRKf7///8A////AP///wD///8A////AP///wD///8A////AP//
	/wBGblAfhtSb/4bUmv+F1Jr/hdOZ/4TTmf+D05n/g9KY/4LSmP+C0pf/iJNB6cWOAP/EjQD/w40A
	/8ONAP/CjAD/wowA/8GLAP/AiwD/wIoA/7+KAP++iQD/vokA/72IAP+8iAD/vIcA/7uHAP+6hgD/
	uoYA/7mGAP+5hQD/uIUA/7eEAP+3hAD/toMA/7WDAP+IhCnfdMmK/3PIiv9zyIn/csiJ/3LIif9x
	x4j/cceI/3DHh/9vxof/b8aG/27Ghv9uxYX/bcWF/23FhP9sxIT/bMSD/2vEg/9rw4P/asOC/2rD
	gv9pwoH/acKB/2jCgP9owYD/bcOE/zRUPf8aRCX/GkQl/xpEJf8aRSb/GkUm/xpFJv8aRib/GkYm
	/xpGJv8aRyb/Gkcm/xpHJ/8aSCf/RzsG/2FGAP9iRgD/YkcA/2JHAP9jRwD/Y0cA/2NIAP9kSAD/
	ZEgA/2RIAP9lSQD/XkUB/1A/BP9BOAb/NDIJ/yUrC/8XJQ//DCER/wwiEv8MIRL/DSIR/w0kE/8P
	JxX/DyoX/xQuGv81Vz7/HFEq/xxRKv8cUir/HFIq/xxSK/8cUyv/HFMr/xxTK/8cVCv/HFQr/x1U
	K/8dVSv/HVUs/x1VLP8dViz/G1Ep/v///wD///8A////AP///wD///8A////AP///wD///8A////
	AEZuUR+H1Zv/htSb/4bUm/+F1Jr/hdSa/4TTmf+E05n/g9OY/4PSmP+KlUHpxo8A/8WOAP/FjgD/
	xI0A/8ONAP/DjAD/wowA/8GLAP/BiwD/wIsA/7+KAP+/igD/vokA/76JAP+9iAD/vIgA/7yHAP+7
	hwD/uoYA/7qGAP+5hQD/uIUA/7iEAP+3hAD/toMA/4iFKd90yYv/dMmK/3PJiv9zyIr/csiJ/3LI
	if9xx4j/cceI/3DHh/9wxof/b8aG/2/Ghv9uxYX/bsWF/23Fhf9txIT/bMSE/2zEg/9rw4P/asOC
	/2rDgv9pwoH/acKB/2jCgP9uxIX/NFQ9/xpDJf8aQyX/GkQl/xpEJf8aRCb/GkUm/xpFJv8aRSb/
	GkYm/xpGJv8aRib/Gkcm/xpHJv9GOwb/YUYA/2FGAP9hRgD/YkcA/2JHAP9jRwD/Y0cA/2NIAP9k
	SAD/ZEgA/2RIAP9lSQD/ZUkA/2VJAP9mSQD/ZkoA/2ZKAP9jSAH/VkID/0c8Bv86Ngn/KzAL/x0q
	D/8QJBL/ESkW/zVXPv8cUSr/HFEq/xxRKv8cUir/HFIq/xxSK/8cUiv/HFMr/xxTK/8cVCv/HFQr
	/xxUK/8dVSv/HVUr/x1VLP8bUSn+////AP///wD///8A////AP///wD///8A////AP///wD///8A
	Rm5RH4fVnP+H1Zz/htWb/4bUm/+F1Jr/hdSa/4TTmf+E05n/g9OY/4qVQenHkAD/xo8A/8aPAP/F
	jgD/xI4A/8SNAP/DjQD/wowA/8KMAP/BiwD/wIsA/8CKAP+/igD/v4kA/76JAP+9iAD/vYgA/7yI
	AP+7hwD/u4cA/7qGAP+5hgD/uYUA/7iFAP+3hAD/iIUp33XKjP90yYv/dMmL/3PJiv9zyIr/csiJ
	/3LIif9xx4j/cceI/3DHh/9wxof/b8aH/2/Ghv9uxYb/bsWF/23Fhf9txIT/bMSE/2zEg/9rxIP/
	a8OC/2rDgv9qw4H/acKB/2/Ehv80VD3/GkMl/xpDJf8aQyX/GkQl/xpEJf8aRCX/GkUm/xpFJv8a
	RSb/GkYm/xpGJv8aRib/Gkcm/0Y7Bv9gRQD/YUYA/2FGAP9hRgD/YkYA/2JHAP9iRwD/Y0cA/2NH
	AP9jSAD/ZEgA/2RIAP9kSAD/ZUkA/2VJAP9mSQD/ZkkA/2ZKAP9nSgD/Z0oA/2dLAP9oSwD/aEsA
	/2dKAP9dRwL/MUMZ/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8cUyv/
	HFQr/xxUK/8dVCv/HVUr/xtQKf7///8A////AP///wD///8A////AP///wD///8A////AP///wBH
	blEfiNad/4jVnP+H1Zz/h9Wb/4bUm/+G1Jr/hdSa/4XTmf+E05n/i5dB6ciQAP/HkAD/x48A/8aP
	AP/FjgD/xY4A/8SNAP/DjQD/w40A/8KMAP/CjAD/wYsA/8CLAP/AigD/v4oA/76JAP++iQD/vYgA
	/7yIAP+8hwD/u4cA/7qGAP+6hgD/uYUA/7iFAP+JhirfdsqM/3XKjP91yYv/dMmL/3TJiv9zyIr/
	csiJ/3LIif9xx4j/cceI/3DHiP9wx4f/b8aH/2/Ghv9uxob/bsWF/23Fhf9txYT/bMSE/2zEg/9r
	xIP/a8OD/2rDgv9qw4L/b8SG/zRUPf8aQiX/GkIl/xpDJf8aQyX/GkMl/xpEJf8aRCX/GkUm/xpF
	Jv8aRSb/GkYm/xpGJv8aRib/RjsG/2BFAP9gRQD/YUYA/2FGAP9hRgD/YkYA/2JHAP9iRwD/Y0cA
	/2NHAP9jSAD/ZEgA/2RIAP9kSAD/ZUkA/2VJAP9lSQD/ZkkA/2ZKAP9mSgD/Z0oA/2dKAP9nSwD/
	aEsA/2hLAP83QhL/HFAq/xxQKv8cUCr/HFEq/xxRKv8cUSr/HFIq/xxSKv8cUiv/HFMr/xxTK/8c
	Uyv/HFQr/xxUK/8cVCv/G1Ao/v///wD///8A////AP///wD///8A////AP///wD///8A////AEdu
	Uh+J1p3/iNad/4jVnP+H1Zz/h9Wb/4bUm/+G1Jv/hdSa/4XUmv+Ml0HpyZEA/8iRAP/IkAD/x5AA
	/8aPAP/GjwD/xY4A/8SOAP/EjQD/w40A/8OMAP/CjAD/wYsA/8GLAP/AigD/v4oA/7+KAP++iQD/
	vYkA/72IAP+8iAD/u4cA/7uHAP+6hgD/uoYA/4qHKt92y43/dsqM/3XKjP91yov/dMmL/3TJiv9z
	yYr/c8iK/3LIif9yyIn/cceI/3HHiP9wx4f/cMaH/2/Ghv9vxob/bsWF/27Fhf9txYX/bcSE/2zE
	hP9sxIP/a8OD/2rDgv9wxYf/M1M8/xpCJf8aQiX/GkIl/xpDJf8aQyX/GkMl/xpEJf8aRCX/GkQm
	/xpFJv8aRSb/GkUm/xpGJv9GOwb/X0UA/2BFAP9gRQD/YEYA/2FGAP9hRgD/YUYA/2JHAP9iRwD/
	Y0cA/2NHAP9jSAD/ZEgA/2RIAP9kSAD/ZUkA/2VJAP9lSQD/ZkkA/2ZKAP9mSgD/Z0oA/2dKAP9n
	SwD/aEsA/zpBEOYcTyn/HE8q/xxQKv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/HFIr/xxT
	K/8cUyv/HFMr/xxUK/8aTyj+////AP///wD///8A////AP///wD///8A////AP///wD///8AR29S
	H4nXnv+J1p3/iNad/4jWnf+H1Zz/h9Wc/4bVm/+G1Jv/hdSa/4yXQunKkgD/yZEA/8mRAP/IkAD/
	yJAA/8ePAP/GjwD/xY4A/8WOAP/EjgD/xI0A/8ONAP/CjAD/wowA/8GLAP/AiwD/wIoA/7+KAP++
	iQD/vokA/72IAP+8iAD/vIcA/7uHAP+7hwD/i4cq3nfLjf92y43/dsqM/3XKjP91yoz/dMmL/3TJ
	i/9zyYr/c8iK/3LIif9yyIn/cceI/3HHiP9wx4f/cMaH/2/Gh/9vxob/bsWG/27Fhf9txYX/bcSE
	/2zEhP9sxIP/a8SD/3HFh/80Uzz/GUEk/xpCJP8aQiX/GkIl/xpDJf8aQyX/GkMl/xpEJf8aRCX/
	GkQl/xpFJv8aRSb/GkUm/0c7B/9fRAD/X0UA/2BFAP9gRQD/YEUA/2FGAP9hRgD/YUYA/2JGAP9i
	RwD/YkcA/2NHAP9jRwD/Y0gA/2RIAP9kSAD/ZEgA/2VJAP9lSQD/ZkkA/2ZKAP9mSgD/Z0oA/2dK
	AP9nSwD/OkAQ5hxPKf8cTyn/HE8p/xxQKv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/HFIr
	/xxTK/8cUyv/HFMr/xpPKP7///8A////AP///wD///8A////AP///wD///8A////AP///wBIb1If
	itef/4rXnv+J1p7/idad/4jWnf+I1Zz/h9Wc/4fVm/+G1Jv/jpdC6cuTAP/KkgD/ypIA/8mRAP/J
	kQD/yJAA/8eQAP/HjwD/xo8A/8WOAP/FjgD/xI0A/8ONAP/DjAD/wowA/8GMAP/BiwD/wIsA/8CK
	AP+/igD/vokA/76JAP+9iAD/vIgA/7yHAP+LhyreeMuO/3fLjv93y43/dsqN/3bKjP91yoz/dcmL
	/3TJi/90yYr/c8iK/3LIif9yyIn/cceI/3HHiP9wx4j/cMeH/2/Gh/9vxob/bsaG/27Fhf9txYX/
	bcWE/2zEhP9sxIP/ccaI/zRSPP8ZQST/GUEk/xlBJP8aQiX/GkIl/xpCJf8aQyX/GkMl/xpDJf8a
	RCX/GkQl/xpEJv8aRSb/RzwH+V9EAP9fRAD/X0UA/2BFAP9gRQD/YEUA/2FGAP9hRgD/YUYA/2JG
	AP9iRwD/YkcA/2NHAP9jRwD/Y0gA/2RIAP9kSAD/ZEgA/2VJAP9lSQD/ZUkA/2ZJAP9mSgD/ZkoA
	/2dKAP85PxDmHE4p/xxOKf8cTyn/HE8p/xxQKv8cUCr/HFAq/xxRKv8cUSr/HFEq/xxSKv8cUir/
	HFIr/xxTK/8cUyv/Gk4o/v///wD///8A////AP///wD///8A////AP///wD///8A////AEhvUx+L
	15//itef/4rXnv+J1p7/idad/4jWnf+I1Zz/h9Wc/4fVm/+Qo0z0zJMA/8uTAP/LkgD/ypIA/8qR
	AP/JkQD/yJEA/8iQAP/HkAD/xo8A/8aPAP/FjgD/xI4A/8SNAP/DjQD/wowA/8KMAP/BiwD/wYsA
	/8CKAP+/igD/v4kA/76JAP+9iAD/vYgA/42IKt54zI//eMuO/3fLjv93y43/dsuN/3bKjP91yoz/
	dcmL/3TJi/90yYr/c8mK/3PIiv9yyIn/csiJ/3HHiP9xx4j/cMeH/3DGh/9vxob/b8aG/27Fhf9u
	xYX/bsWF/2/Fhv93yI3/O1hD/x5EKP8aQiX/GUEk/xlBJP8aQiX/GkIl/xpCJf8aQyX/GkMl/xpD
	Jf8aRCX/GkQl/xpEJf9OPgXeXkQA/15EAP9fRAD/X0UA/19FAP9gRQD/YEUA/2BGAP9hRgD/YUYA
	/2FGAP9iRwD/YkcA/2NHAP9jRwD/Y0gA/2RIAP9kSAD/ZEgA/2VJAP9lSQD/ZUkA/2ZJAP9mSgD/
	ZkoA/zk/EOYbTin/HE4p/xxOKf8cTyn/HE8p/xxPKv8cUCr/HFAq/xxQKv8cUSr/HFEq/xxRKv8c
	Uir/HFIq/xxSK/8aTij+////AP///wD///8A////AP///wD///8A////AP///wD///8ASG9TH4vY
	oP+L15//itef/4rXnv+J157/idad/4jWnf+I1p3/h9Wc/57CY//NlAD/zZQA/8yTAP/LkwD/y5IA
	/8qSAP/JkQD/yZEA/8iQAP/HkAD/x48A/8aPAP/FjgD/xY4A/8SNAP/DjQD/w40A/8KMAP/CjAD/
	wYsA/8CLAP/AigD/v4oA/76JAP++iQD/jYkr3nnMj/95zI//eMyO/3fLjv93y43/dsuN/3bKjP91
	yoz/dcqM/3TJi/91yYz/dsqN/3jKjv95y4//esuQ/3vLkP92wYr/cbeD/22vf/9sqn7/a6p9/2yr
	gP9ur4L/brSG/3G9i/9ipnv/T4Rh/0hyVv8/Ykr/NFY+/y9QOP8sUTX/KE4z/yVLL/8gSCv/HUUo
	/xpDJf8aRCX/GkQl/04+BNpeQwD/XkQA/15EAP9fRAD/X0QA/19FAP9gRQD/YEUA/2BFAP9hRgD/
	YUYA/2FGAP9iRgD/YkcA/2JHAP9jRwD/Y0cA/2NIAP9kSAD/ZEgA/2RIAP9lSQD/ZUkA/2ZJAP9m
	SgD/OT8Q5htNKf8bTin/G04p/xxOKf8cTyn/HE8p/xxPKf8cUCr/HFAq/xxQKv8cUSr/HFEq/xxR
	Kv8cUir/HFIq/xpNKP7///8A////AP///wD///8A////AP///wD///8A////AP///wBJcFMfjNig
	/4zYoP+L2J//i9ef/4rXnv+K157/idae/4nWnf+I1p3/nsJj/86VAP/OlAD/zZQA/8yTAP/MkwD/
	y5MA/8qSAP/KkgD/yZEA/8iRAP/IkAD/x5AA/8aPAP/GjwD/xY4A/8WOAP/EjQD/w40A/8OMAP/C
	jAD/wYsA/8GLAP/AiwD/v4oA/7+KAP+PjC/ff8+U/3/OlP+Bz5b/gs+V/3zDj/92uIj/c7GE/2+t
	gf9vrIH/cK2C/3CwhP9vtYf/cb6L/3TJk/952Zv/f+mn/3/uqf997qf/e+6m/3rupf947aT/d+2j
	/3Xtov917aL/de2i/3Xtov917aL/du2i/3jtpP967qb/fe6n/37sp/9wzZP/Yal7/1WPaf9Melz/
	Q2pP/zhcQ/8xUjr/UUEH2V1DAP9dQwD/XkQA/15EAP9fRAD/X0QA/19FAP9gRQD/YEUA/2BFAP9h
	RgD/YUYA/2FGAP9iRgD/YkcA/2JHAP9jRwD/Y0cA/2NIAP9kSAD/ZEgA/2RIAP9lSQD/ZUkA/2VJ
	AP85PxDmG00p/xtNKf8bTSn/G04p/xxOKf8cTin/HE8p/xxPKf8cTyr/HFAq/xxQKv8cUCr/HFEq
	/xxRKv8cUSr/Gk0o/v///wD///8A////AP///wD///8A////AP///wD///8A////AElwUx+N2aH/
	jNih/4zYoP+L2KD/i9ef/4rXn/+K157/idae/4nWnf+ew2P/z5YA/8+VAP/OlQD/zZQA/82UAP/M
	kwD/y5MA/8uSAP/KkgD/yZEA/8mRAP/IkAD/yJAA/8eQAP/GjwD/xo8A/8WOAP/EjgD/xI0A/8ON
	AP/CjAD/wowA/8GLAP/AiwD/wIoA/5B5INxkfVL/Yope/2Ofbv9quoP/cdGU/3nmof977qb/ee6l
	/3jtpP927aP/c+mf/23dlv9o05D/ZMyK/2HHh/9hxob/YceH/2PLiv9n0o7/bNyW/3Hnnv917aL/
	de2i/3Xtov917aL/ceWc/2rUkP9lxIT/Ybd3/1+pa/9gnl7/YpRS/2aKRf9shDn/c30s/314IP+J
	dhj/mHUP/6F3Df9dRAHaXUMA/11DAP9dQwD/XkMA/15EAP9eRAD/X0QA/19FAP9fRQD/YEUA/2BF
	AP9gRgD/YUYA/2FGAP9iRgD/YkcA/2JHAP9jRwD/Y0cA/2NIAP9kSAD/ZEgA/2RIAP9lSQD/ZUkA
	/zc/EOobTCj/G00p/xtNKf8bTSn/G04p/xtOKf8cTin/HE8p/xxPKf8cTyn/HFAq/xxQKv8cUCr/
	HFEq/xxRKv8aTCj+////AP///wD///8A////AP///wD///8A////AP///wD///8ASXBUH47Zov+N
	2aH/jdih/4zYoP+L2KD/i9ef/4rXn/+K157/idee/6DEY//QlgD/0JYA/8+VAP/OlQD/zpQA/82U
	AP/MlAD/zJMA/8uTAP/LkgD/ypIA/8mRAP/JkQD/yJAA/8eQAP/HjwD/xo8A/8WOAP/FjgD/xI0A
	/8ONAP/DjQD/wowA/8KMAP/BiwD/hmIA4FxCAP9ZQQD/Vj4A/1Q8AP9QOgD/TTcA/0o/Cv9HTRr/
	Rlsq/0VnOP9DcEP/QHRI/zx2S/84c0v/OHBI/zpySP8/dUj/RXdG/0x4Q/9Vdz3/X3c2/2p0K/9y
	cB//fGsT/4VlBv+LZAD/i2UA/41lAP+NZQD/jmYA/45nAP+QaAD/kGgA/5FoAP+RaAD/kmkA/5Nq
	AP+TagD/lGoA/1tCANpcQgD/XUMA/11DAP9dQwD/XkMA/15EAP9eRAD/X0QA/19EAP9fRQD/YEUA
	/2BFAP9gRQD/YUYA/2FGAP9hRgD/YkYA/2JHAP9iRwD/Y0cA/2NHAP9jSAD/ZEgA/2RIAP9kSAD/
	OEYV/xtMKP8bTCj/G00o/xtNKf8bTSn/G04p/xtOKf8cTin/HE8p/xxPKf8cTyn/HFAq/xxQKv8c
	UCr/HFEq/xpMKP7///8A////AP///wD///8A////AP///wD///8A////AP///wBQdVkgktqm/5Tb
	p/+U26f/ldyo/5TcqP+U36r/lOGr/5PirP+T5K3/pc1x/9GXAP/RlwD/0JYA/8+WAP/PlQD/zpUA
	/82UAP/NlAD/zJMA/8yTAP/LkgD/ypIA/8qSAP/JkQD/yJEA/8iQAP/HkAD/xo8A/8aPAP/FjgD/
	xI4A/8SNAP/DjQD/w4wA/8KMAP+GYgDgW0IA/1lAAP9VPgD/UzsA/086AP9NNwD/STQA/0YyAP9D
	MQD/QC4A/zwsAP85KQD/MSQA/ysfAP85KQD/QC4A/0s2AP9VPgD/YEUA/2pMAP90VAD/elcA/3pZ
	AP98WQD/fFkA/31aAP9+WwD/f1wA/4BcAP+BXAD/gV0A/4FdAP+DXgD/gl4A/4RfAP+FYAD/hmAA
	/4VhAP+HYQD/W0IA3FxCAP9cQgD/XEMA/11DAP9dQwD/XUMA/15EAP9eRAD/X0QA/19EAP9fRQD/
	YEUA/2BFAP9gRQD/YUYA/2FGAP9hRgD/YkYA/2JHAP9iRwD/Y0cA/2NHAP9jSAD/ZEgA/2RIAP8/
	SB3/KFY1/yVUMf8hUS7/HU0q/xtNKf8bTSn/G00p/xtOKf8cTin/HE4p/xxPKf8cTyn/HE8q/xxQ
	Kv8cUCr/Gkso/v///wD///8A////AP///wD///8A////AP///wD///8A////AFNyWwp5tY22cbSI
	xWqyg9FltILdZruG6mnGi/Ru05T6dOOd/nfto/+YzWb/0pgA/9KXAP/RlwD/0ZcA/9CWAP/PlgD/
	z5UA/86VAP/NlAD/zZQA/8yTAP/LkwD/y5IA/8qSAP/JkQD/yZEA/8iQAP/IkAD/x48A/8aPAP/F
	jgD/xY4A/8SOAP/EjQD/w40A/4dhAOBbQgD/WUAA/1U9AP9SOwD/TzkA/0w3AP9JNAD/RjIA/0Ix
	AP9ALgD/OCkA/zEjAP8pHgD/JBoA/y8iAP82JwD/Py0A/0gzAP9QOgD/WUAA/2JGAP9sTQD/bE4A
	/21PAP9uUAD/b08A/3BRAP9xUQD/clIA/3NTAP9zUwD/dFQA/3VUAP92VQD/dlYA/3dWAP94VgD/
	eVYA/3lXAP9aQADdW0IA/1xCAP9cQgD/XEIA/11DAP9dQwD/XUMA/15EAP9eRAD/XkQA/19EAP9f
	RQD/X0UA/2BFAP9gRQD/YEYA/2FGAP9hRgD/YkYA/2JHAP9iRwD/Y0cA/2NHAP9jSAD/ZEgA/zo4
	Ff8mOir/LEUy/zFQOf84WUD/OV1C/zZdQP8yXT7/L1s7/ytaOP8nVzT/JFQx/yBSLP8dUCr/HE8p
	/xxQKv8aSyj+////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8AQXFREKySFoPTmQD/05gA/9KYAP/SlwD/0ZcA/9CWAP/Q
	lgD/z5UA/86VAP/OlAD/zZQA/8yTAP/MkwD/y5MA/8qSAP/KkgD/yZEA/8mRAP/IkAD/x5AA/8eP
	AP/GjwD/xY4A/8WOAP/EjQD/iGIA4FpBAP9ZQAD/VD0A/1I7AP9POQD/TDYA/0g0AP9GMgD/Py8A
	/zYnAP8uIQD/JxwA/yEYAP8dFQD/KB0A/y4hAP80JQD/OysA/0IwAP9JNQD/UTsA/1lAAP9dQwD/
	X0QA/2BFAP9hRgD/YUYA/2NHAP9kSAD/ZUgA/2VJAP9mSQD/Z0oA/2hLAP9oSwD/ak0A/2tNAP9s
	TQD/bE4A/1lAAN5bQQD/W0IA/1xCAP9cQgD/XEIA/11DAP9dQwD/XUMA/15DAP9eRAD/XkQA/19E
	AP9fRAD/X0UA/2BFAP9gRQD/YEUA/2FGAP9hRgD/YUYA/2JGAP9iRwD/YkcA/2NHAP9jRwD/LCgG
	/wcUCv8JGQ3/Cx8R/w4jFP8UKxr/GTQg/x89J/8lRS7/K040/zJXPP81XED/OWBE/ztgRf82Wj//
	M1g8/y1VOPv///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A1ZoAYNWZAP/UmQD/05kA/9OYAP/SmAD/0ZcA/9GX
	AP/QlgD/z5YA/8+VAP/OlQD/zZQA/82UAP/MkwD/y5MA/8uSAP/KkgD/ypEA/8mRAP/IkQD/yJAA
	/8eQAP/GjwD/xo8A/8WOAP+HYQDgWkEA/1g/AP9UPQD/UjsA/084AP9LNgD/RjIA/zwrAP8zJQD/
	Kh8A/yMaAP8eFgD/HRUA/x0VAP8jGQD/JxsA/ywfAP8wIwD/NigA/zwrAP9CMAD/STUA/084AP9R
	OgD/UjsA/1M8AP9UPQD/VT0A/1Y9AP9XPgD/Vz8A/1lAAP9aQQD/W0EA/1tCAP9cQgD/XUMA/15E
	AP9eRAD/Vz8A31pBAP9bQQD/W0IA/1tCAP9cQgD/XEIA/1xDAP9dQwD/XUMA/11DAP9eRAD/XkQA
	/19EAP9fRAD/X0UA/2BFAP9gRQD/YEUA/2FGAP9hRgD/YUYA/2JGAP9iRwD/YkcA/2NHAP8tKgf/
	CRgN/goZDv0KGw/7DB0R9w0gEe8NIhLjDSMT1Q8jE8MOJRSvDiQUlg4lFHwOIhVfFisaRi0+Mi2C
	jYIW////Df///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wDXmgBg1poA/9WaAP/UmQD/1JkA/9OYAP/SmAD/0pcA
	/9GXAP/QlgD/0JYA/8+WAP/OlQD/zpUA/82UAP/NlAD/zJMA/8uTAP/LkgD/ypIA/8mRAP/JkQD/
	yJAA/8eQAP/HjwD/xo8A/4dhAOBZQAD/WD8A/1Q8AP9SOwD/TTcA/0IvAP83KAD/LyEA/yYdAP8f
	FwD/HRUA/x0VAP8dFQD/HRUA/x8XAP8iGAD/JBoA/ygdAP8sIAD/MCMA/zUlAP86KQD/Pi0A/0Iw
	AP9DMAD/RDEA/0UyAP9GMwD/RzMA/0g0AP9KNQD/SjUA/0w3AP9NOAD/TjcA/044AP9QOQD/UToA
	/1I7AP9WPgDhWkEA/1pBAP9bQQD/W0IA/1tCAP9cQgD/XEIA/1xCAP9dQwD/XUMA/11DAP9eRAD/
	XkQA/15EAP9fRAD/X0UA/19FAP9gRQD/YEUA/2BGAP9hRgD/YUYA/2JGAP9iRwD/YkcA/2JHAGj/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////ANeaAGDXmwD/1poA/9WaAP/VmgD/1JkA/9OZAP/TmAD/
	0pgA/9GXAP/RlwD/0JYA/8+WAP/PlQD/zpUA/86UAP/NlAD/zJMA/8yTAP/LkwD/ypIA/8qSAP/J
	kQD/yJEA/8iQAP/HkAD/iGIA4FlAAP9XPgD/VDwA/0kzAP89LAD/MiQA/ykdAP8hFwD/HRUA/x0V
	AP8dFQD/HRUA/x0VAP8dFQD/HRUA/x4WAP8gFwD/IhgA/yQaAP8mGwD/KR4A/ywfAP8vIgD/MiUA
	/zQmAP83JgD/NycA/zcoAP85KQD/OioA/zsqAP88KwD/PSwA/z8tAP9ALgD/QC4A/0EvAP9DMAD/
	RDEA/1U9AOJZQAD/WkEA/1pBAP9bQQD/W0EA/1tCAP9cQgD/XEIA/1xCAP9dQwD/XUMA/11DAP9e
	QwD/XkQA/15EAP9fRAD/X0QA/19FAP9gRQD/YEUA/2BFAP9hRgD/YUYA/2FGAP9iRgD/YkcAaP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A150AYNicAP/XmwD/1psA/9aaAP/VmgD/1JkA/9SZAP/T
	mAD/05gA/9KYAP/RlwD/0ZcA/9CWAP/PlgD/z5UA/86VAP/NlAD/zZQA/8yTAP/LkwD/y5IA/8qS
	AP/JkQD/yZEA/8iQAP+JYwDgWEAA/085AP9CLwD/NycA/y0fAP8kGQD/HRUA/x0VAP8dFQD/HRUA
	/x0VAP8dFQD/HRUA/x0VAP8dFQD/HRUA/x0VAP8dFQD/HhYA/x8WAP8gGAD/Kh4A/zQlAP8/LQD/
	TzsF/0Q0C/8wIgD/LCAA/yseAP8sIAD/LSEA/y0gAP8uIQD/MCMA/zEkAP8yJQD/MyUA/zUmAP82
	JwD/VDwA41lAAP9ZQAD/WkEA/1pBAP9aQQD/W0EA/1tCAP9bQgD/XEIA/1xCAP9cQwD/XUMA/11D
	AP9dQwD/XkQA/15EAP9fRAD/X0QA/19FAP9gRQD/YEUA/2BFAP9hRgD/YUYA/2FGAP9iRwBo////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wDanQBg2Z0A/9icAP/XnAD/15sA/9abAP/VmgD/1ZoA/9SZ
	AP/UmQD/05gA/9KYAP/SlwD/0ZcA/9CWAP/QlgD/z5UA/86VAP/OlAD/zZQA/8yUAP/MkwD/y5MA
	/8uSAP/KkgD/yZEA/4hiAOFHNAD/PCsA/zAjAP8lGwD/JRsA/zAjAP85KQD/QjAA/003AP9XPwD/
	YEUA/2lMAP90VAD/fVoA/4ZgAP+PZwD/mW4A/6F1AP+qewD/s4EA/7qGAP+6hgD/uoYA/7mFAf/C
	khT/gWso/1U+Af9UPAD/Uz0A/1A6AP9MNwD/SDQA/0QxAP9ALgD/PSwA/zkpAP82JwD/MyQA/zAi
	AP9UPADlWUAA/1lAAP9ZQAD/WkAA/1pBAP9aQQD/W0EA/1tCAP9bQgD/XEIA/1xCAP9cQgD/XUMA
	/11DAP9dQwD/XkQA/15EAP9eRAD/X0QA/19FAP9fRQD/YEUA/2BFAP9gRgD/YUYA/2JHAGj///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////ANqdAGDanQD/2Z0A/9icAP/YnAD/15sA/9abAP/WmgD/1ZoA
	/9WZAP/UmQD/05kA/9OYAP/SmAD/0ZcA/9GXAP/QlgD/z5YA/8+VAP/OlQD/zZQA/82UAP/MkwD/
	zJMA/8uSAP/KkgD/wo0A67F/APa1gwD+vYgA/8WOAP/GjwD/xo8A/8WOAP/EjgD/xI0A/8ONAP/D
	jAD/wowA/8GLAP/BiwD/wIoA/7+KAP+/igD/vokA/72JAP+9iAD/vIgA/7uHAP+7hwD/uoYB/8SU
	Ff+Dbir/VD4B/1Q8AP9UPAD/VD0A/1U9AP9VPQD/VT0A/1Y+AP9WPgD/Vj4A/1c+AP9XPwD/Vz8A
	/1g/AP9YPwD/WEAA/1lAAP9ZQAD/WUAA/1pBAP9aQQD/W0EA/1tBAP9bQgD/XEIA/1xCAP9cQgD/
	XUMA/11DAP9dQwD/XkMA/15EAP9eRAD/X0QA/19EAP9fRQD/YEUA/2BFAP9gRQD/YkcAaP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A//8AAdukAA7dogAe258AetueAP/angD/2Z0A/9mdAP/YnAD/2JwA/9ebAP/WmwD/
	1poA/9WaAP/UmQD/1JkA/9OYAP/SmAD/0pcA/9GXAP/RlwD/0JYA/8+WAP/PlQD/zpUA/82UAP/N
	lAD/zJMA/8uTAP/LkgD/ypIA/8mRAP/JkQD/yJAA/8iQAP/HjwD/xo8A/8WOAP/FjgD/xI4A/8SN
	AP/DjQD/wowA/8KMAP/BiwD/wIsA/8CKAP+/igD/vokA/76JAP+9iAD/vIgA/7yHAP+7hwH/xZUW
	/4VuK/9VPQH/UzwA/1Q8AP9UPAD/VD0A/1U9AP9VPQD/VT0A/1Y+AP9WPgD/Vj4A/1c+AP9XPwD/
	Vz8A/1g/AP9YPwD/WEAA/1lAAP9ZQAD/WUAA/1pBAP9aQQD/WkEA/1tBAP9bQgD/W0IA/1xCAP9c
	QgD/XEMA/11DAP9dQwD/XkMA/15EAP9eRAD/X0QA/19EAP9fRQD/YEUA/2BFAP9gRQBo////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AOOqAAnipACg4qQAsOCjAMDgowDP
	4KIA39+hAO/eoQD93qAA/92gAP/cnwD/3J8A/9ueAP/bngD/2p0A/9mdAP/ZnAD/2JwA/9ecAP/X
	mwD/1psA/9WaAP/VmgD/1JkA/9OZAP/TmAD/0pgA/9KXAP/RlwD/0JYA/9CWAP/PlQD/zpUA/86U
	AP/NlAD/zJMA/8yTAP/LkwD/ypIA/8qSAP/JkQD/yZEA/8iQAP/HkAD/x48A/8aPAP/FjgD/xY4A
	/8SNAP/DjQD/w4wA/8KMAP/BjAD/wYsA/8CLAP/AigD/v4oA/76JAP++iQD/vYgA/7yIAf/Hlhf/
	j3Yx6lQ8Af9TOwD/UzwA/1M8AP9UPAD/VDwA/1Q9AP9VPQD/VT0A/1Y9AP9WPgD/Vj4A/1c+AP9X
	PgD/Vz8A/1g/AP9YPwD/WD8A/1lAAP9ZQAD/WUAA/1pAAP9aQQD/WkEA/1tBAP9bQgD/W0IA/1xC
	AP9cQgD/XEIA/11DAP9dQwD/XUMA/15EAP9eRAD/XkQA/19EAP9fRQD/X0UA/2BFAO1gRQDQX0YA
	u2FHAKZhRwCQYUYAe2JGAGZjRgBQY0UAO2VKACZpSwAR////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A358AEOOkAP/jpAD/4qMA/+GjAP/h
	ogD/4KIA/9+hAP/foQD/3qAA/96gAP/doAD/3J8A/9yfAP/bngD/2p4A/9qdAP/ZnQD/2JwA/9ic
	AP/XmwD/1psA/9aaAP/VmgD/1ZkA/9SZAP/TmQD/05gA/9KYAP/RlwD/0ZcA/9CWAP/PlgD/z5UA
	/86VAP/NlAD/zZQA/8yTAP/LkwD/y5IA/8qSAP/KkQD/yZEA/8iRAP/IkAD/x5AA/8aPAP/GjwD/
	xY4A/8SOAP/EjQD/w40A/8KMAP/CjAD/wYsA/8GLAP/AigD/v4oA/7+JAP++iQD/vYgB/8eXF/+R
	eDLqVDwB/1I7AP9TOwD/UzwA/1M8AP9UPAD/VDwA/1Q9AP9VPQD/VT0A/1U9AP9WPgD/Vj4A/1Y+
	AP9XPgD/Vz8A/1c/AP9YPwD/WD8A/1hAAP9ZQAD/WUAA/1lAAP9aQQD/WkEA/1tBAP9bQQD/W0IA
	/1xCAP9cQgD/XEIA/11DAP9dQwD/XUMA/15DAP9eRAD/XkQA/19EAP9fRAD/X0UA/2BFAP9gRQD/
	YEUA/2FGAP9hRgD/YUYA/2JGAP9iRwD/YkcA/2NHAP9jRwD6Y0gA5mRIANFkSAC7ZUoApmVJAIj/
	//8A////AP///wD///8A////AP///wD///8A////AP///wDfnwAQ5KUA/+SlAP/jpAD/4qQA/+Kj
	AP/howD/4KIA/+CiAP/foQD/36EA/96gAP/doAD/3Z8A/9yfAP/bngD/254A/9qeAP/ZnQD/2Z0A
	/9icAP/XnAD/15sA/9abAP/WmgD/1ZoA/9SZAP/UmQD/05gA/9KYAP/SlwD/0ZcA/9CWAP/QlgD/
	z5YA/86VAP/OlQD/zZQA/82UAP/MkwD/y5MA/8uSAP/KkgD/yZEA/8mRAP/IkAD/x5AA/8ePAP/G
	jwD/xY4A/8WOAP/EjQD/w40A/8ONAP/CjAD/wowA/8GLAP/AiwD/wIoA/7+KAP++iQH/yZgY/5J5
	M+lTOwL/UjsA/1I7AP9SOwD/UzwA/1M8AP9UPAD/VDwA/1Q9AP9VPQD/VT0A/1U9AP9WPgD/Vj4A
	/1Y+AP9XPgD/Vz8A/1c/AP9YPwD/WD8A/1hAAP9ZQAD/WUAA/1lAAP9aQQD/WkEA/1pBAP9bQQD/
	W0IA/1tCAP9cQgD/XEIA/1xDAP9dQwD/XUMA/15DAP9eRAD/XkQA/19EAP9fRAD/X0UA/2BFAP9g
	RQD/YEUA/2FGAP9hRgD/YUYA/2JGAP9iRwD/YkcA/2NHAP9jRwD/Y0gA/2RIAP9kSAD/ZEgA8P//
	/wD///8A////AP///wD///8A////AP///wD///8A////AN+fABDlpgD/5aUA/+SlAP/jpAD/46QA
	/+KjAP/iowD/4aMA/+CiAP/gogD/36EA/96hAP/eoAD/3aAA/9yfAP/cnwD/254A/9ueAP/anQD/
	2Z0A/9icAP/YnAD/15sA/9ebAP/WmgD/1ZoA/9WaAP/UmQD/05kA/9OYAP/SmAD/0ZcA/9GXAP/Q
	lgD/z5YA/8+VAP/OlQD/zpQA/82UAP/MkwD/zJMA/8uTAP/KkgD/ypIA/8mRAP/IkQD/yJAA/8eQ
	AP/GjwD/xo8A/8WOAP/FjgD/xI0A/8ONAP/DjAD/wowA/8GLAP/BiwD/wIsA/7+KAf/Kmhn/lHs1
	6VM8Av9ROgD/UjsA/1I7AP9SOwD/UzsA/1M8AP9TPAD/VDwA/1Q8AP9UPQD/VT0A/1U9AP9WPQD/
	Vj4A/1Y+AP9XPgD/Vz4A/1c/AP9YPwD/WD8A/1g/AP9ZQAD/WUAA/1lAAP9aQAD/WkEA/1pBAP9b
	QQD/W0IA/1tCAP9cQgD/XEIA/1xDAP9dQwD/XUMA/11DAP9eRAD/XkQA/15EAP9fRAD/X0UA/19F
	AP9gRQD/YEUA/2BGAP9hRgD/YUYA/2JGAP9iRwD/YkcA/2NHAP9jRwD/Y0gA/2RIAP9kSADw////
	AP///wD///8A////AP///wD///8A////AP///wD///8A358AEOanAP/mpgD/5aYA/+WlAP/kpQD/
	46QA/+OkAP/iowD/4aMA/+GiAP/gogD/36EA/9+hAP/eoAD/3aAA/92fAP/cnwD/3J8A/9ueAP/a
	ngD/2p0A/9mdAP/YnAD/2JwA/9ebAP/WmwD/1poA/9WaAP/UmQD/1JkA/9OYAP/TmAD/0pgA/9GX
	AP/RlwD/0JYA/8+WAP/PlQD/zpUA/82UAP/NlAD/zJMA/8uTAP/LkgD/ypIA/8mRAP/JkQD/yJAA
	/8iQAP/HkAD/xo8A/8aPAP/FjgD/xI4A/8SNAP/DjQD/wowA/8KMAP/BiwD/wIsB/8ubGv+VfTbo
	UzwC/1E6AP9ROgD/UjsA/1I7AP9SOwD/UzsA/1M8AP9TPAD/VDwA/1Q8AP9UPQD/VT0A/1U9AP9V
	PQD/Vj4A/1Y+AP9WPgD/Vz4A/1c/AP9XPwD/WD8A/1g/AP9YQAD/WUAA/1lAAP9ZQAD/WkEA/1pB
	AP9bQQD/W0EA/1tCAP9cQgD/XEIA/1xCAP9dQwD/XUMA/11DAP9eQwD/XkQA/15EAP9fRAD/X0QA
	/19FAP9gRQD/YEUA/2BFAP9hRgD/YUYA/2FGAP9iRgD/YkcA/2JHAP9jRwD/Y0cA/2NIAPD///8A
	////AP///wD///8A////AP///wD///8A////AP///wDvrwAQ56cA/+enAP/mpgD/5qYA/+WlAP/k
	pQD/5KQA/+OkAP/ipAD/4qMA/+GjAP/gogD/4KIA/9+hAP/eoQD/3qAA/92gAP/dnwD/3J8A/9ue
	AP/bngD/2p0A/9mdAP/ZnQD/2JwA/9ecAP/XmwD/1psA/9WaAP/VmgD/1JkA/9SZAP/TmAD/0pgA
	/9KXAP/RlwD/0JYA/9CWAP/PlQD/zpUA/86UAP/NlAD/zJQA/8yTAP/LkwD/y5IA/8qSAP/JkQD/
	yZEA/8iQAP/HkAD/x48A/8aPAP/FjgD/xY4A/8SNAP/DjQD/w40A/8KMAP/CjAH/zZwb/5d+N+hS
	OwL/UDoA/1E6AP9ROgD/UToA/1I7AP9SOwD/UjsA/1M8AP9TPAD/VDwA/1Q8AP9UPQD/VT0A/1U9
	AP9VPQD/Vj4A/1Y+AP9WPgD/Vz4A/1c/AP9XPwD/WD8A/1g/AP9YQAD/WUAA/1lAAP9ZQAD/WkEA
	/1pBAP9aQQD/W0EA/1tCAP9bQgD/XEIA/1xCAP9cQwD/XUMA/11DAP9eQwD/XkQA/15EAP9fRAD/
	X0QA/19FAP9gRQD/YEUA/2BFAP9hRgD/YUYA/2FGAP9iRgD/YkcA/2JHAP9jRwD/Y0cA8P///wD/
	//8A////AP///wD///8A////AP///wD///8A////AO+vABDpqAD/6KgA/+enAP/npwD/5qYA/+Wm
	AP/lpQD/5KUA/+OkAP/jpAD/4qMA/+GjAP/hogD/4KIA/+CiAP/foQD/3qEA/96gAP/doAD/3J8A
	/9yfAP/bngD/2p4A/9qdAP/ZnQD/2JwA/9icAP/XmwD/1psA/9aaAP/VmgD/1ZkA/9SZAP/TmQD/
	05gA/9KYAP/RlwD/0ZcA/9CWAP/PlgD/z5UA/86VAP/NlAD/zZQA/8yTAP/MkwD/y5IA/8qSAP/K
	kgD/yZEA/8iRAP/IkAD/x5AA/8aPAP/GjwD/xY4A/8SOAP/EjQD/w40A/8OMAf/NnRv/l4A46FI7
	Av9QOQD/UDoA/1E6AP9ROgD/UToA/1I7AP9SOwD/UjsA/1M7AP9TPAD/UzwA/1Q8AP9UPAD/VD0A
	/1U9AP9VPQD/Vj0A/1Y+AP9WPgD/Vz4A/1c+AP9XPwD/WD8A/1g/AP9YPwD/WUAA/1lAAP9ZQAD/
	WkEA/1pBAP9aQQD/W0EA/1tCAP9bQgD/XEIA/1xCAP9cQwD/XUMA/11DAP9dQwD/XkQA/15EAP9e
	RAD/X0QA/19FAP9gRQD/YEUA/2BFAP9hRgD/YUYA/2FGAP9iRgD/YkcA/2JHAP9jRwDw////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A768AEOqpAP/pqAD/6KgA/+inAP/npwD/5qYA
	/+amAP/lpgD/5KUA/+SlAP/jpAD/4qQA/+KjAP/howD/4aIA/+CiAP/foQD/36EA/96gAP/doAD/
	3Z8A/9yfAP/bngD/254A/9qeAP/ZnQD/2Z0A/9icAP/YnAD/15sA/9abAP/WmgD/1ZoA/9SZAP/U
	mQD/05gA/9KYAP/SlwD/0ZcA/9GXAP/QlgD/z5YA/8+VAP/OlQD/zZQA/82UAP/MkwD/y5MA/8uS
	AP/KkgD/yZEA/8mRAP/IkAD/yJAA/8ePAP/GjwD/xY4A/8WOAP/EjgD/xI0B/8+fHP+agjnnUTsC
	/1A5AP9QOQD/UDoA/1E6AP9ROgD/UToA/1I7AP9SOwD/UjsA/1M7AP9TPAD/UzwA/1Q8AP9UPAD/
	VD0A/1U9AP9VPQD/VT0A/1Y+AP9WPgD/Vj4A/1c+AP9XPwD/Vz8A/1g/AP9YPwD/WUAA/1lAAP9Z
	QAD/WUAA/1pBAP9aQQD/W0EA/1tBAP9bQgD/XEIA/1xCAP9cQgD/XUMA/11DAP9dQwD/XkMA/15E
	AP9eRAD/X0QA/19EAP9fRQD/YEUA/2BFAP9gRQD/YUYA/2FGAP9hRgD/YkYA/2JHAPD///8A////
	AP///wD///8A////AP///wD///8A////AP///wDvrwAQ66oA/+qpAP/pqQD/6agA/+ioAP/npwD/
	56cA/+amAP/mpgD/5aUA/+SlAP/jpAD/46QA/+KkAP/iowD/4aMA/+CiAP/gogD/36EA/96hAP/e
	oAD/3aAA/9yfAP/cnwD/254A/9ueAP/anQD/2Z0A/9mcAP/YnAD/15wA/9ebAP/WmwD/1ZoA/9Wa
	AP/UmQD/05kA/9OYAP/SmAD/0pcA/9GXAP/QlgD/0JYA/8+VAP/OlQD/zpQA/82UAP/MkwD/zJMA
	/8uTAP/KkgD/ypIA/8mRAP/JkQD/yJAA/8eQAP/HjwD/xo8A/8WOAP/FjgH/z58d/5uEOudROgL/
	TzkA/085AP9QOQD/UDkA/1A6AP9ROgD/UToA/1E6AP9SOwD/UjsA/1I7AP9TPAD/UzwA/1Q8AP9U
	PAD/VD0A/1U9AP9VPQD/VT0A/1Y+AP9WPgD/Vj4A/1c+AP9XPwD/Vz8A/1g/AP9YPwD/WEAA/1lA
	AP9ZQAD/WUAA/1pBAP9aQQD/WkEA/1tBAP9bQgD/W0IA/1xCAP9cQgD/XEMA/11DAP9dQwD/XkMA
	/15EAP9eRAD/X0QA/19EAP9fRQD/YEUA/2BFAP9gRQD/YUYA/2FGAP9hRgD/YkYA8P///wD///8A
	////AP///wD///8A////AP///wD///8A////AO+vABDsqgD/66oA/+qpAP/qqQD/6akA/+ioAP/o
	qAD/56cA/+enAP/mpgD/5aYA/+WlAP/kpQD/46QA/+OkAP/iowD/4aMA/+GiAP/gogD/36EA/9+h
	AP/eoAD/3qAA/92gAP/cnwD/3J8A/9ueAP/angD/2p0A/9mdAP/YnAD/2JwA/9ebAP/WmwD/1poA
	/9WaAP/VmQD/1JkA/9OZAP/TmAD/0pgA/9GXAP/RlwD/0JYA/8+WAP/PlQD/zpUA/82UAP/NlAD/
	zJMA/8uTAP/LkgD/ypIA/8qRAP/JkQD/yJEA/8iQAP/HkAD/xo8A/8aQAf/RoR7/nIU851A6Av9P
	OAD/TzkA/085AP9QOQD/UDkA/1A6AP9ROgD/UToA/1E6AP9SOwD/UjsA/1I7AP9TOwD/UzwA/1M8
	AP9UPAD/VDwA/1Q9AP9VPQD/VT0A/1Y9AP9WPgD/Vj4A/1c+AP9XPgD/Vz8A/1g/AP9YPwD/WD8A
	/1lAAP9ZQAD/WUAA/1pBAP9aQQD/WkEA/1tBAP9bQgD/W0IA/1xCAP9cQgD/XEMA/11DAP9dQwD/
	XUMA/15EAP9eRAD/XkQA/19EAP9fRQD/YEUA/2BFAP9gRQD/YUYA/2FGAP9hRgDw////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A768AEO2rAP/sqwD/66oA/+uqAP/qqQD/6akA/+mo
	AP/oqAD/6KcA/+enAP/mpgD/5qYA/+WlAP/kpQD/5KUA/+OkAP/ipAD/4qMA/+GjAP/gogD/4KIA
	/9+hAP/foQD/3qAA/92gAP/dnwD/3J8A/9ueAP/bngD/2p4A/9mdAP/ZnQD/2JwA/9ecAP/XmwD/
	1psA/9aaAP/VmgD/1JkA/9SZAP/TmAD/0pgA/9KXAP/RlwD/0JYA/9CWAP/PlgD/zpUA/86VAP/N
	lAD/zZQA/8yTAP/LkwD/y5IA/8qSAP/JkQD/yZEA/8iQAP/HkAD/x5AB/9KhHv+ehj3nUDoC/044
	AP9POAD/TzkA/085AP9QOQD/UDkA/1A6AP9ROgD/UToA/1E6AP9SOwD/UjsA/1I7AP9TOwD/UzwA
	/1M8AP9UPAD/VDwA/1Q9AP9VPQD/VT0A/1U9AP9WPgD/Vj4A/1Y+AP9XPgD/Vz8A/1c/AP9YPwD/
	WD8A/1lAAP9ZQAD/WUAA/1pAAP9aQQD/WkEA/1tBAP9bQQD/W0IA/1xCAP9cQgD/XEIA/11DAP9d
	QwD/XUMA/15DAP9eRAD/XkQA/19EAP9fRAD/X0UA/2BFAP9gRQD/YEYA/2FGAPD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wDvrwAQ7qwA/+2rAP/sqwD/7KoA/+uqAP/rqgD/6qkA
	/+mpAP/pqAD/6KgA/+enAP/npwD/5qYA/+WmAP/lpQD/5KUA/+OkAP/jpAD/4qMA/+KjAP/howD/
	4KIA/+CiAP/foQD/3qEA/96gAP/doAD/3J8A/9yfAP/bngD/254A/9qdAP/ZnQD/2JwA/9icAP/X
	mwD/15sA/9aaAP/VmgD/1ZoA/9SZAP/TmQD/05gA/9KYAP/RlwD/0ZcA/9CWAP/PlgD/z5UA/86V
	AP/OlAD/zZQA/8yTAP/MkwD/y5MA/8qSAP/KkgD/yZEA/8iRAP/IkQH/06Mf/5+IPudPOQL/TjgA
	/044AP9OOAD/TzgA/085AP9POQD/UDkA/1A5AP9QOgD/UToA/1E6AP9SOwD/UjsA/1I7AP9TOwD/
	UzwA/1M8AP9UPAD/VDwA/1Q9AP9VPQD/VT0A/1U9AP9WPgD/Vj4A/1Y+AP9XPgD/Vz8A/1c/AP9Y
	PwD/WD8A/1hAAP9ZQAD/WUAA/1lAAP9aQQD/WkEA/1pBAP9bQQD/W0IA/1tCAP9cQgD/XEIA/1xD
	AP9dQwD/XUMA/15DAP9eRAD/XkQA/19EAP9fRAD/X0UA/2BFAP9gRQD/YEUA8P///wD///8A////
	AP///wD///8A////AP///wD///8A////AO+vABDvrQD/7qwA/+6sAP/tqwD/7KsA/+yqAP/rqgD/
	6qkA/+qpAP/pqAD/6KgA/+ioAP/npwD/5qcA/+amAP/lpgD/5aUA/+SlAP/jpAD/46QA/+KjAP/h
	owD/4aIA/+CiAP/foQD/36EA/96gAP/doAD/3Z8A/9yfAP/cnwD/254A/9qeAP/anQD/2Z0A/9ic
	AP/YnAD/15sA/9abAP/WmgD/1ZoA/9SZAP/UmQD/05gA/9OYAP/SmAD/0ZcA/9GXAP/QlgD/z5YA
	/8+VAP/OlQD/zZQA/82UAP/MkwD/y5MA/8uSAP/KkgD/yZEA/8mSAf/VoyD/oYlA5085Av9NNwD/
	TjgA/044AP9OOAD/TzgA/085AP9POQD/UDkA/1A5AP9QOgD/UToA/1E6AP9ROgD/UjsA/1I7AP9S
	OwD/UzsA/1M8AP9TPAD/VDwA/1Q8AP9UPQD/VT0A/1U9AP9WPQD/Vj4A/1Y+AP9XPgD/Vz4A/1c/
	AP9YPwD/WD8A/1g/AP9ZQAD/WUAA/1lAAP9aQQD/WkEA/1pBAP9bQQD/W0IA/1tCAP9cQgD/XEIA
	/1xDAP9dQwD/XUMA/11DAP9eRAD/XkQA/15EAP9fRAD/X0UA/2BFAP9gRQDw////AP///wD///8A
	////AP///wD///8A////AP///wD///8A768AEPCtAP/vrQD/760A/+6sAP/trAD/7asA/+yrAP/r
	qgD/66oA/+qpAP/pqQD/6agA/+ioAP/opwD/56cA/+amAP/mpgD/5aUA/+SlAP/kpAD/46QA/+Kk
	AP/iowD/4aMA/+CiAP/gogD/36EA/96hAP/eoAD/3aAA/92fAP/cnwD/254A/9ueAP/anQD/2Z0A
	/9mdAP/YnAD/15wA/9ebAP/WmwD/1ZoA/9WaAP/UmQD/1JkA/9OYAP/SmAD/0pcA/9GXAP/QlgD/
	0JYA/8+VAP/OlQD/zpQA/82UAP/MlAD/zJMA/8uTAP/LkgD/ypMB/9WlIf+jikHmTjkC/003AP9N
	NwD/TTgA/044AP9OOAD/TzgA/085AP9POQD/UDkA/1A5AP9QOgD/UToA/1E6AP9ROgD/UjsA/1I7
	AP9SOwD/UzsA/1M8AP9TPAD/VDwA/1Q8AP9UPQD/VT0A/1U9AP9VPQD/Vj4A/1Y+AP9WPgD/Vz4A
	/1c/AP9XPwD/WD8A/1g/AP9ZQAD/WUAA/1lAAP9aQAD/WkEA/1pBAP9bQQD/W0EA/1tCAP9cQgD/
	XEIA/1xCAP9dQwD/XUMA/11DAP9eQwD/XkQA/15EAP9fRAD/X0QA/19FAPD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wDvrwAQ8a4A//CuAP/wrQD/760A/+6sAP/urAD/7asA/+yr
	AP/sqgD/66oA/+qpAP/qqQD/6akA/+moAP/oqAD/56cA/+enAP/mpgD/5aYA/+WlAP/kpQD/46QA
	/+OkAP/iowD/4aMA/+GiAP/gogD/4KIA/9+hAP/eoQD/3qAA/92gAP/cnwD/3J8A/9ueAP/angD/
	2p0A/9mdAP/YnAD/2JwA/9ebAP/WmwD/1poA/9WaAP/VmQD/1JkA/9OZAP/TmAD/0pgA/9GXAP/R
	lwD/0JYA/8+WAP/PlQD/zpUA/82UAP/NlAD/zJMA/8yTAP/LkwH/16Yi/6SLQudPOAL/TDcA/003
	AP9NNwD/TTcA/044AP9OOAD/TjgA/085AP9POQD/TzkA/1A5AP9QOQD/UDoA/1E6AP9ROgD/UjsA
	/1I7AP9SOwD/UzsA/1M8AP9TPAD/VDwA/1Q8AP9UPQD/VT0A/1U9AP9VPQD/Vj4A/1Y+AP9WPgD/
	Vz4A/1c/AP9XPwD/WD8A/1g/AP9YQAD/WUAA/1lAAP9ZQAD/WkEA/1pBAP9aQQD/W0EA/1tCAP9c
	QgD/XEIA/1xCAP9cQwD/XUMA/11DAP9eQwD/XkQA/15EAP9fRAD/X0QA8P///wD///8A////AP//
	/wD///8A////AP///wD///8A////AO+vABDyrwD/8a8A//GuAP/wrgD/760A/++tAP/urAD/7awA
	/+2rAP/sqwD/66oA/+uqAP/qqQD/6qkA/+moAP/oqAD/6KcA/+enAP/mpgD/5qYA/+WmAP/kpQD/
	5KUA/+OkAP/ipAD/4qMA/+GjAP/hogD/4KIA/9+hAP/foQD/3qAA/92gAP/dnwD/3J8A/9ueAP/b
	ngD/2p4A/9mdAP/ZnQD/2JwA/9icAP/XmwD/1psA/9aaAP/VmgD/1JkA/9SZAP/TmAD/0pgA/9KX
	AP/RlwD/0ZcA/9CWAP/PlgD/z5UA/86VAP/NlAD/zZQA/8yUAf/YpyP/po1E5k84Av9MNgD/TDcA
	/003AP9NNwD/TTcA/044AP9OOAD/TjgA/084AP9POQD/TzkA/1A5AP9QOQD/UDoA/1E6AP9ROgD/
	UToA/1I7AP9SOwD/UjsA/1M7AP9TPAD/UzwA/1Q8AP9UPAD/VD0A/1U9AP9VPQD/Vj0A/1Y+AP9W
	PgD/Vz4A/1c+AP9XPwD/WD8A/1g/AP9YQAD/WUAA/1lAAP9ZQAD/WkEA/1pBAP9aQQD/W0EA/1tC
	AP9bQgD/XEIA/1xCAP9cQwD/XUMA/11DAP9dQwD/XkQA/15EAP9eRADw////AP///wD///8A////
	AP///wD///8A////AP///wD///8A768AEPKvAP/yrwD/8q8A//GuAP/wrgD/8K0A/++tAP/vrAD/
	7qwA/+2rAP/tqwD/7KsA/+uqAP/rqgD/6qkA/+mpAP/pqAD/6KgA/+enAP/npwD/5qYA/+amAP/l
	pQD/5KUA/+OkAP/jpAD/4qQA/+KjAP/howD/4KIA/+CiAP/foQD/3qEA/96gAP/doAD/3J8A/9yf
	AP/bngD/254A/9qdAP/ZnQD/2ZwA/9icAP/XnAD/15sA/9abAP/VmgD/1ZoA/9SZAP/TmQD/05gA
	/9KYAP/SlwD/0ZcA/9CWAP/QlgD/z5UA/86VAP/OlAD/zZUB/9inI/+mjkTmTzkD/0s2AP9MNgD/
	TDcA/0w3AP9NNwD/TTcA/004AP9OOAD/TjgA/084AP9POQD/TzkA/1A5AP9QOQD/UDoA/1E6AP9R
	OgD/UToA/1I7AP9SOwD/UjsA/1M7AP9TPAD/UzwA/1Q8AP9UPAD/VD0A/1U9AP9VPQD/VT0A/1Y+
	AP9WPgD/Vj4A/1c+AP9XPwD/Vz8A/1g/AP9YPwD/WUAA/1lAAP9ZQAD/WkAA/1pBAP9aQQD/W0EA
	/1tBAP9bQgD/XEIA/1xCAP9cQgD/XUMA/11DAP9dQwD/XkMA/15EAPD///8A////AP///wD///8A
	////AP///wD///8A////AP///wDvrwAQ8q8A//KvAP/yrwD/8q8A//GvAP/xrgD/8K4A//CtAP/v
	rQD/7qwA/+6sAP/tqwD/7KsA/+yqAP/rqgD/6qkA/+qpAP/pqQD/6KgA/+ioAP/npwD/56cA/+am
	AP/lpgD/5aUA/+SlAP/jpAD/46QA/+KjAP/howD/4aIA/+CiAP/foQD/36EA/96gAP/eoAD/3aAA
	/9yfAP/cnwD/254A/9qeAP/anQD/2Z0A/9icAP/YnAD/15sA/9abAP/WmgD/1ZoA/9WZAP/UmQD/
	05kA/9OYAP/SmAD/0ZcA/9GXAP/QlgD/z5YA/8+VAP/OlgH/2agk/6aNROZPOgT/SzYA/0s2AP9M
	NgD/TDYA/0w3AP9NNwD/TTcA/003AP9OOAD/TjgA/044AP9POQD/TzkA/085AP9QOQD/UDkA/1A6
	AP9ROgD/UToA/1I7AP9SOwD/UjsA/1M7AP9TPAD/UzwA/1Q8AP9UPAD/VD0A/1U9AP9VPQD/VT0A
	/1Y+AP9WPgD/Vj4A/1c+AP9XPwD/Vz8A/1g/AP9YPwD/WEAA/1lAAP9ZQAD/WUAA/1pBAP9aQQD/
	WkEA/1tBAP9bQgD/XEIA/1xCAP9cQgD/XUMA/11DAP9dQwD/XkMA8P///wD///8A////AP///wD/
	//8A////AP///wD///8A////AO+vABDyrwD/8q8A//KvAP/yrwD/8q8A//KvAP/xrgD/8a4A//Cu
	AP/vrQD/760A/+6sAP/trAD/7asA/+yrAP/rqgD/66oA/+qpAP/pqQD/6agA/+ioAP/opwD/56cA
	/+amAP/mpgD/5aUA/+SlAP/kpQD/46QA/+KkAP/iowD/4aMA/+CiAP/gogD/36EA/9+hAP/eoAD/
	3aAA/92fAP/cnwD/254A/9ueAP/angD/2Z0A/9mdAP/YnAD/15wA/9ebAP/WmwH/1poB/9WaAf/U
	mQH/1JkB/9OYAf/SmQH/0pgB/9GYAf/QlwH/0JcB/9CYAv/bqyb/po9E5VE9Bv9MNwH/TDgB/0w3
	Af9NNwH/TTcB/004Af9OOAH/TjgB/044Af9POQH/TzkB/085AP9QOQD/UDoA/1A6AP9ROgD/UToA
	/1E6AP9ROgD/UToA/1E6AP9SOwD/UjsA/1I7AP9TOwD/UzwA/1M8AP9UPAD/VDwA/1U9AP9VPQD/
	VT0A/1Y+AP9WPgD/Vj4A/1c+AP9XPgD/Vz8A/1g/AP9YPwD/WEAA/1lAAP9ZQAD/WUAA/1pBAP9a
	QQD/WkEA/1tBAP9bQgD/W0IA/1xCAP9cQgD/XEMA/11DAP9eQwDw////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A768AEPKvAP/yrwD/8q8A//KvAP/yrwD/8q8A//KvAP/yrwD/8a4A
	//CuAP/wrQD/760A/+6sAP/urAD/7asA/+yrAf/sqgH/66oB/+uqAf/qqgH/6aoB/+mpAv/oqQL/
	56cC/+eoAv/mpwL/5acC/+WmAv/kpgP/46QD/+OlA//ipAP/4qQD/+GkA//gowP/4aMD/+CiA//f
	ogP/36ID/96iA//doQP/3aED/9ygBP/coQb/3KEJ/9yjDf/cow//3KUS/9ymFf/dphf/3acZ/9yo
	G//dqB3/3akf/9yqIf/cqiL/3Ksj/9yqJP/cqyb/3Kwn/+G0N/+pkEble2Un/3ZgIf9zXR//cVsd
	/25YGv9sVhj/alQW/2lSFf9mURT/Z1AT/2VOEv9lTxH/Y00Q/2JMDv9iSg7/YEkN/19JDP9eRwv/
	XUYK/1xFCf9cRAj/W0QH/1lCBv9ZQgX/V0AE/1U/A/9VPQL/VD4B/1Q+Af9VPgH/VT4B/1U/Af9W
	PwH/Vj8B/1Y/Af9XQAH/Vz8B/1c/Af9YPwH/WEAB/1hAAf9ZQAH/WUAB/1pBAf9aQQD/WkEA/1tB
	AP9bQgD/W0IA/1xBAP9bQQD/W0IA/1xCAP9cQgD/XEIA/15DAPD///8A////AP///wD///8A////
	AP///wD///8A////AP///wDvrwAQ8q8A//KvAP/yrwD/8q8A//KvAf/yrwH/8q8B//KvAf/ysAH/
	8bAB//GvAv/wrwL/764C/++vBf/vsAv/77IS/++zGP/vth7/77ck/++5Kf/vuy7/77wy/+++N//v
	vjz/8MFA//DBRP/vw0j/8MRL//DGT//xxlL/8MdV//DJWP/xyVr/8cpd//HMYP/xzGH/8cxj//HN
	Zf/xzmb/8c1o//LPav/x0Gv/8tBr//HQav/xzWf/8M1k/+/MYf/vyl//7shd/+3JWv/sxlf/7MVV
	/+vEU//qw1D/6cJO/+nAS//ovkn/575H/+a9RP/lukL/5bpB/6eQReWWgDv+lH44/ZJ7N/yPeTX7
	j3cz+ox0MPmKci73iXIu9otxLvWJci30inIt8opyLfKJci3winIt74pyLe6KcSzti3Ms64pyLeqK
	cyzpinIs54pyLOaKcivlinIs44pyLOKKcivhinMr4IpyLN6KcivdiXEq24huKNqGbSfYhGsm1oRt
	JNSCaiPSgWki0IBmIM5+Zh/MfGIdy3tiHch6YBzGdmAaxXdeGcJ2XBfAc1kWvXJYFLxwVhK5blUR
	tm1TD7VsUg2yaU8Mr2dNCq5mTQmrY0sIqGJIBaZfRQOjXUMClv///wD///8A////AP///wD///8A
	////AP///wD///8A////AP+qAAbxrwVv8rUNcvS1FHP1uh909b4ndfW+MXf2xDh69sRCfPfIS3/3
	zlOB+M9dhPjRZIf51W2K+dRyi/nXc4n51nWI+NZ1hffWcoH20nCA9tJwffbQbHr20mt39c9qdPXO
	aHH0z2Zu9M1ma/TOZGjzzWJl8sthYfLMXl/vyl5d8cpbWfHFW1fvyFhU8ctaUPHIWU3xxlVL8MdV
	SO/HUkXux1JB7cFRP+zFTDzrx1A56sNPN+3EUDPsxFAw6sBKLejBSSrtwkcn7MRGJenERiHnvkQe
	5MBCG+vNPxjqvkQW5b1EE+/AQRDsxE8N6LpGC+C/YAj/zGYF/7+ABP//qgP//6oD//+qA///qgP/
	/6oD//+qA/+qVQP/qlUD/6pVA/+qVQP/qlUD/6pVA/+qVQP/qlUD/6pVA/+qVQP/qlUD/6pVA/+q
	VQP/qlUDqqpVA///gAL//4AC//+AAv//gAL//4AC//+AAv//gAL//4AC//+AAv//gAL//4AC//+A
	Av//gAL//4AC//+AAv+AgAL/gIAC////Af///wH///8B////Af///wH///8B//8AAf//AAH//wAB
	//8AAf//AAH/AAAB////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP//AAH///8B////Af///wH///8B//+AAv//
	gAL///8C////Av///wL/qqoD/6qqA/+qqgP///8C////Av///wL///8C////Av///wL///8C//+A
	Av//gAL//4AC//+AAv//gAL/gIAC////Af///wH///8B////Af///wH///8B////Af///wH///8B
	////Af///wH///8B//8AAf//AAH//wAB//8AAf//AAH/AAAB////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//////////////////
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////+AAAAAf//////////////4AAAAAA////////
	//////wAAAAAAD/////////////AAAAAAAAP///////////8AAAAAAAAA///////////4AAAAAAA
	AAH//////////gAAAAAAAAAAf////////+AAAAAAAAAAAB////////8AAAAAAAAAAAAP///////w
	AAAAAAAAAAAAA///////AAAAAAAAAAAAAAD/////+AAAAAAAAAAAAAAAf////4AAAAAAAAAAAAAA
	AB////gAAAAAAAAAAAAAAAAP///AAAAAAAAAAAAAAAAAA//8AAAAAAAAAAAAAAAAAAH/+AAAAAAA
	AAAAAAAAAAAAf/AAAAAAAAAAAAAAAAAAAD/gAAAAAAAAAAAAAAAAAAAfwAAAAAAAAAAAAAAAAAAA
	D8AAAAAAAAAAAAAAAAAAAAfAAAAAAAAAAAAAAAAAAAADwAAAAAAAAAAAAAAAAAAAA8AAAAAAAAAA
	AAAAAAAAAAHAAAAAAAAAAAAAAAAAAAAB4AAAAAAAAAAAAAAAAAAAAeAAAAAAAAAAAAAAAAAAAAPw
	AAAAAAAAAAAAAAAAAAAD8AAAAAAAAAAAAAAAAAAAB/AAAAAAAAAAAAAAAAAAAA/wAAAAAAAAAAAA
	AAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAA
	AAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAA
	AAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAA
	AAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAA
	AB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAA
	AAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf
	8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAA
	AAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AA
	AAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAA
	AAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAA
	AAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAA
	AAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB//+AAAAAAAAAAAAAAAAAAf//wAAAAA
	AAAAAAAAAAAAH//8AAAAAAAAAAAAAAAf/////AAAAAAAAAAAAAAAH/////wAAAAAAAAAAAAAAB//
	///8AAAAAAAAAAAAAAAf/////AAAAAAAAAAAAAAAH////+AAAAAAAAAAAAAAAB////AAAAAAAAAA
	AAAAAAAAB//wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/w
	AAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAA
	AAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAA
	AAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAA
	AAAAH/AAAAAAAAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAA
	AAAAAAAAAAAAAB/wAAAAAAAAAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAH/AAAAAAAAAAAAAAAAAA
	B///AAAAAAAP////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////KAAAAEAAAACAAAAAAQAgAAAA
	AAAAQAAA1w0AANcNAAAAAAAAAAAAAP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8AAAAAAQAAAAEAAAABAAAAAQAAAAEAAAAB
	AAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAf///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wAAAAABAAAAAQAAAAIAAAAD
	AAAABQAAAAYAAAAGAAAABwAAAAcAAAAHAAAABwAAAAcAAAAHAAAABwAAAAYAAAAGAAAABQAAAAQA
	AAADAAAAAwAAAAEAAAAB////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	AAAAAQAAAAIAAAADAAAABQAAAAgAAAAMAAAAEQAAABYAAAAZAAAAGwAAAB0AAAAbAAAAGwAAABkA
	AAAYAAAAFwAAABYAAAAVAAAAEwAAABEAAAAOAAAADAAAAAkAAAAHAAAABAAAAAL///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8AAAAAAQAAAAEAAAACAAAABAAAAAgAAAAMAAAAEQAAABgAAAAiAAAAMQAAAEEA
	AABRAAAAXQAAAGIAAABdAAAAUQAAAEUAAAA+AAAAOQAAADUAAAAxAAAALQAAACoAAAAlAAAAIQAA
	ABwAAAAWAAAAEAAAAAsAAAAHAAAAAwAAAAH///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8AAAAAAQAAAAEAAAACAAAABAAAAAcAAAALAAAAEQAAABgA
	AAAjAAAANAAAAEYAAABZCBMKexo+JLooXTbjNnxI90egX/4mVTL+Ezod9QshENICBQKVAAAAfQAA
	AG0AAABeAAAAUwAAAEsAAABEAAAAPAAAADYAAAAuAAAAJwAAAB8AAAAXAAAAEAAAAAoAAAAGAAAA
	AgAAAAH///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAEAAAACAAAABAAAAAcA
	AAAKAAAAEAAAABkAAAAnAAAAOAAAAEsDBQNiFzQeoyVUMtcyckPyP5NW/UuvZv9MsGf/TLBn/0yw
	Z/9Qsmr/J1s2/x5bLv8eWy7/HVgs/xQ/IPkMJxPhAwkFqQAAAIYAAAB1AAAAZAAAAFYAAABMAAAA
	QgAAADoAAAAxAAAAKAAAAB8AAAAXAAAADwAAAAkAAAAEAAAAAv///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AAAAAAEA
	AAACAAAABAAAAAcAAAALAAAAEgAAAB0AAAAtAAAAPwAAAFETKBmGJE4vxTFrQOo/ilP7Tqtn/1Cz
	a/9Psmr/TrFp/02xaP9MsGf/TLBn/0ywZ/9MsGf/ULJq/ydbNv8dWi3/HVot/x5bLv8eXC7/Hlwu
	/x5cLf8WRiP8DiwW6AYQCLUAAACJAAAAdQAAAGIAAABRAAAARQAAADwAAAAyAAAAKAAAAB4AAAAV
	AAAADQAAAAcAAAADAAAAAf///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AAAAAAIAAAACAAAABAAAAAgAAAAMAAAAFgAAACMAAAAzAAAAQwwWD2kjRSuxMGQ+3z+C
	UfZPpWb+V7dw/1a2cP9VtW//VLVu/1O0bf9Rs2z/ULNr/0+yav9Osmn/TbFo/0ywZ/9MsGf/TLBn
	/1Cyav8nWjb/HVkt/x1ZLf8dWi3/Hlsu/x5bLv8eXC7/Hl0u/x5dL/8eXi//GE0m/RAyGe4IGAzA
	AAAAhwAAAHMAAABeAAAATQAAAD4AAAAzAAAAKAAAABwAAAATAAAACwAAAAYAAAACAAAAAf///wD/
	//8A////AP///wD///8A////AP///wD///8AAAAAAwAAAAcAAAAPAAAAGgAAACoAAAA4AwYDTx48
	J5guXTvRPntP8E+cZP1cunX/XLp1/1u5dP9auXT/Wbhz/1i4cv9Xt3H/VrZw/1W2b/9UtW7/U7Rt
	/1K0bP9Rs2v/ULJq/0+yaf9OsWn/TbBo/0ywZ/9Qsmr/J1k1/x1YLf8dWC3/HVkt/x1aLf8dWi7/
	Hlsu/x5cLv8eXS7/Hl0v/x5eL/8eXi//Hl8v/xpUKf4SORzyCh4PzAACAokAAABvAAAAWwAAAEYA
	AAA1AAAAKAAAABsAAAAQAAAACQAAAAQAAAAB////AP///wD///8A////AP///wD///8AAAAACAAA
	ABkAAAAzGjIgdi5XOb0+dEznT5Rh+mC4d/9jvnv/Yr56/2G9ef9gvHj/Xrx4/127d/9cunb/W7p1
	/1q5dP9ZuHP/WLhy/1e3cf9WtnD/VbZv/1S1bv9TtW3/UrRt/1GzbP9Qs2v/T7Jq/06xaf9NsWj/
	ULJq/ydZNf8dVyz/HVgs/x1YLf8dWS3/HVot/x1aLf8eWy7/Hlwu/x5cLv8eXS7/Hl4v/x5eL/8e
	Xy//HmAv/x5gMP8dWiz/FUAf9wwlEtUCBwSRAAAAbAAAAFUAAAA9AAAAKQAAABoAAAAPAAAABwAA
	AAMAAAAB////AP///wD///8AAAAAAzprSINQkmHsYLJ3/mnCgf9owoD/Z8F//2bAfv9lwH3/ZL98
	/2O+e/9ivnv/Yb16/2C8ef9fvHj/Xrt3/127dv9cunX/W7l0/1q5c/9ZuHL/WLdx/1e3cP9WtnD/
	VbVv/1S1bv9TtG3/UbNs/1Cza/9Psmr/TrJp/1Cza/8nWDX/HVYs/x1XLP8dVyz/HVgt/x1ZLf8d
	WS3/HVot/x5bLv8eWy7/Hlwu/x5dLv8eXS//Hl4v/x5fL/8eXy//HmAw/x5hMP8fYTD/Hl8u/xZH
	I/oOLBbeBQ0HmQAAAGcAAABLAAAAMQAAABoAAAAMAAAABP///wD///8A////AAAAAAJKhFnLbcSE
	/2zEg/9qw4L/acKB/2jCgP9nwX//ZsF//2XAfv9kv33/Y798/2K+e/9hvXr/YL15/1+8eP9eu3f/
	Xbt2/1y6df9buXT/Wrl0/1m4c/9Yt3L/V7dx/1a2cP9Vtm//VLVu/1O0bf9StGz/UbNr/1Cyav9S
	tGz/J1c0/x1VLP8dViz/HVYs/x1XLP8dWC3/HVgt/x1ZLf8dWi3/HVot/x5bLv8eXC7/Hlwu/x5d
	Lv8eXi//Hl4v/x5fL/8eYC//HmAw/x9hMP8fYjD/H2Iw/x9iMf8YTSX8EDIZ5AYWC6AAAABWAAAA
	MwAAABUAAAAE////AP///wAAAAACS4dayW7Fhf9txYT/bMSD/2vDg/9qw4L/acKB/2jBgP9nwX//
	ZsB+/2W/ff9kv3z/Y757/2K+ev9hvXn/YLx4/168eP9du3f/XLp2/1u6df9auXT/Wbhz/1i4cv9X
	t3H/VrZw/1W2b/9UtW7/U7Vt/1K0bf9Rs2z/U7Ru/ydWNP8cVCv/HVUr/x1VLP8dViz/HVcs/x1X
	LP8dWC3/HVkt/x1ZLf8dWi3/Hlsu/x5bLv8eXC7/Hl0u/x5dL/8eXi//Hl8v/x5fL/8eYDD/HmEw
	/x9iMP8fYjD/H2Mx/x9kMf8fZDH/GlQp/BM9HtoLIxNfAAAACf///wD///8A////AE2HXMhvxof/
	bsWG/23Fhf9sxIT/a8SD/2rDgv9pwoH/aMKA/2fBf/9mwH7/ZcB9/2S/fP9jvnv/Yr57/2G9ev9g
	vHn/X7x4/167d/9dunb/XLp1/1u5dP9auXP/Wbhy/1i3cf9Xt3D/VrZw/1W1b/9TtW7/UrRt/1S0
	b/8nVTT/HFMr/xxUK/8dVSv/HVUs/x1WLP8dViz/HVcs/x1YLf8dWS3/HVkt/x1aLf8dWy7/Hlsu
	/x5cLv8eXS7/Hl0v/x5eL/8eXy//Hl8v/x5gMP8eYTD/H2Ew/x9iMP8fYzD/H2Mx/x9kMf8fZDH/
	FD8fvgAAAAT///8A////AP///wBOiV3HcceI/3DGh/9vxob/bsWF/2zEhP9rxIP/asOC/2nCgf9o
	woD/Z8F//2bAf/9lwH7/ZL99/2O/fP9ivnv/Yb16/2C9ef9fvHj/Xrt3/127dv9cunX/W7l0/1q5
	dP9ZuHP/WLdy/1e3cf9WtnD/VbZv/1S1bv9WtXD/J1Uz/xxSK/8cUyv/HFQr/xxUK/8dVSz/HVYs
	/x1WLP8dVyz/HVgs/x1YLf8dWS3/HVot/x1aLf8eWy7/Hlwu/x5cLv8eXS7/Hl4v/x5eL/8eXy//
	HmAv/x5gMP8fYTD/H2Iw/x9iMP8fYzH/H2Qx/xVBILn///8A////AP///wD///8ATolfx3LIif9x
	x4j/cMeH/2/Ghv9uxYX/bcWE/2zEg/9rw4P/asOC/2nCgf9owYD/Z8F//2bAfv9lv33/ZL98/2O+
	e/9hvXr/YL15/1+8eP9evHf/Xbt3/1y6dv9bunX/Wrl0/1m4c/9YuHL/V7dx/1a2cP9Vtm//V7Zx
	/ydUM/8cUSr/HFIq/xxTK/8cUyv/HFQr/x1VK/8dVSz/HVYs/x1XLP8dVyz/HVgt/x1ZLf8dWS3/
	HVot/x5bLv8eWy7/Hlwu/x5dLv8eXS//Hl4v/x5fL/8eXy//HmAw/x5hMP8fYTD/H2Iw/x9jMf8V
	QSC4////AP///wD///8A////AE+JX8dzyYr/csiJ/3HHiP9wx4f/b8aG/27Fhv9txYX/bMSE/2vD
	g/9qw4L/acKB/2jCgP9nwX//ZsB+/2XAff9kv3z/Y757/2K+e/9hvXr/YLx5/1+8eP9eu3f/Xbp2
	/1y6df9buXT/Wrlz/1m4cv9Yt3H/V7dw/1m3c/8nUzP/HFAq/xxRKv8cUir/HFIr/xxTK/8cVCv/
	HVQr/x1VLP8dViz/HVYs/x1XLP8dWC3/HVgt/x1ZLf8dWi3/HVou/x5bLv8eXC7/Hlwu/x5dLv8e
	Xi//Hl4v/x5fL/8eYC//HmAw/x9hMP8fYjD/FUAguP///wD///8A////AP///wBRimDHdcmL/3TJ
	iv9zyIr/csiJ/3HHiP9wxof/b8aG/27Fhf9sxIT/a8SD/2rDgv9pwoH/aMKA/2fBf/9mwH//ZcB+
	/2S/ff9jv3z/Yr57/2G9ev9gvXn/X7x4/167d/9du3b/XLp1/1u5dP9auXP/Wbhz/1i3cv9auHT/
	J1Iy/xxPKv8cUCr/HFEq/xxRKv8cUir/HFMr/xxTK/8cVCv/HVUr/x1VLP8dViz/HVcs/x1XLP8d
	WC3/HVkt/x1aLf8dWi3/Hlsu/x5cLv8eXC7/Hl0u/x5eL/8eXi//Hl8v/x5gL/8eYDD/H2Ew/xVA
	ILj///8A////AP///wD///8AUYpgx3bKjf91yoz/dMmL/3PIiv9yyIn/cceI/3DGh/9vxob/bsWF
	/23FhP9sxIP/a8OC/2rDgv9pwoH/aMGA/2fBf/9mwH7/Zb99/2S/fP9jvnv/Yb16/2C9ef9fvHj/
	Xrx3/127d/9cunb/W7p1/1q5dP9ZuHP/W7l1/yZSMv8cTin/HE8p/xxQKv8cUSr/HFEq/xxSKv8c
	Uyv/HFMr/xxUK/8dVSv/HVUs/x1WLP8dVyz/HVcs/x1YLf8dWS3/HVkt/x1aLf8eWy7/Hlsu/x5c
	Lv8eXS7/Hl0v/x5eL/8eXy//Hl8v/x5gMP8TQCC4////AP///wD///8A////AFKLYcd3y47/dsuN
	/3XKjP90yYv/c8mK/3LIif9xx4j/cMeH/2/Ghv9uxYb/bcWF/2zEhP9rw4P/asOC/2nCgf9owoD/
	Z8F//2bAfv9lwH3/ZL98/2O+e/9ivnr/Yb16/2C8ef9fvHj/Xrt3/126dv9cunX/W7l0/125dv8m
	UTL/G04p/xxOKf8cTyn/HFAq/xxQKv8cUSr/HFIq/xxSK/8cUyv/HFQr/x1UK/8dVSz/HVYs/x1W
	LP8dVyz/HVgt/x1YLf8dWS3/HVot/x1aLf8eWy7/Hlwu/x5cLv8eXS7/Hl4v/x5eL/8eXy//Ez8f
	uP///wD///8A////AP///wBTi2LHecyP/3jLjv93y43/dsqM/3XJi/90yYr/c8iJ/3LIif9xx4j/
	b8aH/2/Ghv9wxof/br+E/2atev9go3T/XqJy/16mdv9juXv/ZsB+/2XAfv9kv33/Y798/2K+e/9h
	vXr/YL15/1+8eP9eu3f/Xbt2/1y6df9eunf/JlAx/xtNKf8bTSn/G04p/xxPKf8cTyn/HFAq/xxR
	Kv8cUSr/HFIq/xxTK/8cUyv/HFQr/x1VK/8dVSz/HVYs/x1XLP8dVyz/HVgt/x1ZLf8dWS3/HVot
	/x5bLv8eWy7/Hlwu/x5dLv8eXS//Hl4v/xM/H7j///8A////AP///wD///8AVI1ix3rNkP95zI//
	eMyO/3fLjf94y47/ecqO/2+3g/9oqXv/Y6R3/2Kld/9hq3v/YbV//164gf9Uq3T/TJ5q/0aRYf8/
	hVj/XbB1/2jBgP9nwX//ZsB+/2S/ff9jv3z/Yr57/2G9ev9gvXn/X7x4/167d/9du3b/X7t5/yZP
	Mf8bTCj/G0wo/xtNKf8bTin/HE4p/xxPKf8cUCr/HFAq/xxRKv8cUir/HFIr/xxTK/8cVCv/HVQr
	/x1VLP8dViz/HVYs/x1XLP8dWC3/HVgt/x1ZLf8dWi3/HVou/x5bLv8eXC7/Hlwu/x5dL/8TPR+4
	////AP///wD///8A////AFSNZMd7zpH/es2Q/3nMkP94zI//RHZR/zVpRv83cUz/O3pR/z6DWP9B
	h1r/OntR/zRuSP8tYj//J1U2/yBJLf8aPCT/Ey8b/1OcZv9pwoH/aMKA/2fBf/9mwH7/ZcB9/2S/
	fP9jvnv/Yr56/2G9ev9gvHn/X7x4/2G8ev8mTjH/G0so/xtLKP8bTCj/G00p/xtNKf8cTin/HE8p
	/xxPKv8cUCr/HFEq/xxSKv8cUiv/HFMr/xxUK/8cVCv/HVUr/x1WLP8dViz/HVcs/x1YLP8dWC3/
	HVkt/x1aLf8dWi3/Hlsu/x5cLv8eXC7/Ez0fuP///wD///8A////AP///wBWjWXHfc+T/3zOkv97
	zZH/es2Q/zJhQP8aRST/GEIk/xY+If8UOB7/ETEa/w8pFv8NJBL/DSMS/wwhEf8MIBH/DSMS/w0j
	Ev9UnWf/asOC/2nCgf9owoD/Z8F//2bAfv9lwH3/ZL99/2O+fP9ivnv/Yb16/2C9ef9ivXv/Jk0w
	/xtKJ/8bSyj/G0so/xtMKP8bTSj/G00p/x9RLf8dUCr/HE8p/xxQKv8cUSr/HFEq/xxSKv8cUyv/
	HFMr/xxUK/8dVSv/HVUs/x1WLP8dVyz/HVcs/x1YLf8dWS3/HVkt/x1aLf8eWy7/Hlsu/xM8H7j/
	//8A////AP///wD///8AV45lx37PlP99z5P/fM6S/3vNkf8yYUD/GkQk/xhBI/8VOh//EjAa/w4o
	Ff8OJRP/DSMS/w0jEv8NIxL/DSMS/w0jEv8bLBD/WZxk/2zEg/9rw4L/asOB/2nCgf9owYD/Z8F/
	/2bAfv9kv33/Y798/2K+e/9hvXr/Y758/yZMMP8bSSf/G0on/xtKKP8bSyj/G0wo/xtMKP8gQin/
	JkQu/yZGL/8nSTH/JlAy/yRVMf8eUiz/HFIq/xxSK/8cUyv/HFQr/x1UK/8dVSz/HVYs/x1WLP8d
	Vyz/HVgt/x1YLf8dWS3/HVot/x1aLf8TPB+4////AP///wD///8A////AFiOZseA0JX/f9CU/33P
	k/98zpL/M2FA/xg+If8SNBv/DyoW/xovFf8vOhH/Q0MN/1hNCv9sWQj/gmQF/5RvA/+oeQH/rXwA
	/2uVTv9txYX/bMSE/2vDg/9qw4L/acKB/2jBgP9nwX//ZsB+/2XAff9kv3z/Y757/2W/ff8lSzD/
	G0gn/xtJJ/8bSSf/G0oo/xtLKP8bSyj/ES0Z/xAqF/8RLhn/EzEa/xg2If8ePij/JEQt/ydHMP8o
	SzH/J08y/yVXMv8gVi7/HFQr/x1VK/8dVSz/HVYs/x1XLP8dVyz/HVgt/x1ZLf8dWS3/EzoduP//
	/wD///8A////AP///wBYj2jHgdGW/4DQlf9/0JT/fs+T/25xJe2IbAf6nXYE/rCBAf+5hQD/uIUA
	/7eEAP+1gwD/tIIA/7OBAP+xgAD/sH8A/69+AP9tlU//bsaG/23Fhf9sxIT/a8SD/2rDgv9pwoH/
	aMKA/2fBf/9mwH7/ZcB9/2S/ff9mv3//JUov/xpHJv8bSCf/G0gn/xtJJ/8bSif/G0oo/wocDv8J
	Fwv/ChoP/wsfEf8OIhP/DiUV/w8pF/8RLBn/Ei8Z/xUxHP8bNSL/Ij4o/yZGL/8mVTL/HVQr/x1V
	LP8dViz/HVYs/x1XLP8dWC3/HVkt/xM6Hbj///8A////AP///wD///8AWZBox4LSl/+B0Zf/gNGW
	/3/Qlf+qiBHav4oA/76JAP+9iAD/u4cA/7qGAP+5hQD/t4QA/7aDAP+1ggD/s4EA/7KAAP+xfwD/
	bpdQ/3DGh/9vxob/bsWF/23EhP9sxIP/a8OC/2rDgf9pwoD/Z8GA/2bBf/9lwH7/Z8CA/yVKL/8a
	Rib/Gkcm/xpHJ/8bSCf/G0kn/xtKJ/8MIhL/Cx0P/wwgEf8NIRL/DSMS/w4jE/8OIxP/DyYW/xAq
	F/8SMBv/FTge/xc8If8bQSX/JlAz/xxUK/8cVCv/HVUs/x1WLP8dViz/HVcs/x1YLP8TOR24////
	AP///wD///8A////AFuQaceE05n/g9KY/4LSl/+A0Zb/rYkR2sGLAP/AigD/v4kA/72JAP+8iAD/
	u4cA/7mGAP+4hQD/t4QA/7aDAP+0ggD/s4EA/3OYUfNxx4j/cMeH/2/Ghv9uxYX/bcWE/2zEhP9r
	w4P/asOC/2nCgf9owYD/Z8F//2nBgf8mSi//GkUm/xpGJv8aRyb/Gkcn/xtIJ/8bSSf/JyoK/xwg
	Cf8OGQr/CBYL/woYDf8KGw7/CxwP/wwgEP8NIhL/DygW/xEvGP8UNB3/GT0i/yZQMv8cUyv/HFMr
	/xxUK/8dVSv/HVUs/x1WLP8dVyz/EzkduP///wD///8A////AP///wBbkGrHhdSa/4TTmf+D0pj/
	gtKX/66LEdrDjQD/wowA/8GLAP+/igD/vokA/72IAP+8hwD/uoYA/7mFAP+4hAD/toMA/7WDAP90
	mVLzcsiJ/3HHiP9wx4j/b8aH/27Ghv9txYX/bMSE/2vEg/9qw4L/acKB/2jCgP9qwoL/Jkov/xpE
	Jf8aRSb/GkYm/xpGJv8aRyb/Gkgn/1Q/Av9iRwD/Y0cA/1tEAf9NPAP/QDYG/zIwCP8kKwz/FyQO
	/wwhEf8NJBL/DykW/xQwGv8mUDL/HFIq/xxSK/8cUyv/HFQr/x1UK/8dVSz/HVYs/xM4Hbj///8A
	////AP///wD///8AXJJqx4bVm/+F1Jr/hNOZ/4PTmP+vjBHaxY4A/8SNAP/DjQD/wowA/8CLAP+/
	igD/vokA/7yIAP+7hwD/uoYA/7mFAP+3hAD/dppT83TJi/9zyIr/csiJ/3HHiP9wxof/b8aG/27F
	hf9txIT/bMSD/2vDgv9qw4H/bMOC/yZJL/8aQyX/GkQl/xpFJv8aRSb/GkYm/xpHJv9TPgL/YUYA
	/2JGAP9iRwD/Y0cA/2RIAP9lSQD/ZUkA/2ZKAP9kSAH/VUMD/0g9Bv87OAr/KEop/xxRKv8cUSr/
	HFIq/xxTK/8cUyv/HFQr/x1VK/8TOB24////AP///wD///8A////AF2Sa8eI1Zz/h9Wb/4bUmv+F
	05r/so0R2siQAP/GjwD/xY4A/8SNAP/CjAD/wYsA/8CKAP+/iQD/vYgA/7yIAP+7hwD/uYYA/3aa
	U/N1yoz/dMmL/3PJiv9yyIn/cceI/3DHh/9vxob/bsWF/23FhP9sxIP/a8OD/23EhP8mSC//GkIl
	/xpDJf8aRCX/GkQm/xpFJv8aRib/Uj4C/2BFAP9hRgD/YkYA/2JHAP9jRwD/ZEgA/2RIAP9lSQD/
	ZkkA/2ZKAP9nSgD/aEsA/ylDGvscUCr/HFEq/xxRKv8cUir/HFMr/xxTK/8cVCv/EzgcuP///wD/
	//8A////AP///wBfk2vHidae/4jWnf+H1Zz/htSb/7OPEdrKkgD/yJEA/8eQAP/GjwD/xI4A/8ON
	AP/CjAD/wYsA/7+KAP++iQD/vYgA/7uHAP94nFTzd8uN/3XKjP90yYv/c8mK/3LIif9xx4j/cMeH
	/2/Gh/9uxob/bcWF/2zEhP9uxYX/JUcu/xpCJP8aQiX/GkMl/xpEJf8aRCX/GkUm/1I/A/9fRQD/
	YEUA/2FGAP9hRgD/YkcA/2NHAP9jSAD/ZEgA/2VJAP9lSQD/ZkoA/2dKAP8qQhr2HE8p/xxQKv8c
	UCr/HFEq/xxSKv8cUiv/HFMr/xI4HLj///8A////AP///wD///8AX5Ntx4rXn/+J1p7/iNad/4fV
	nP+tnSX6zJMA/8qSAP/JkQD/yJAA/8aPAP/FjgD/xI0A/8OMAP/BjAD/wIsA/7+KAP++iQD/eZxV
	83jMjv93y43/dsqM/3XKi/91yYv/dcmL/3bKjP91x4v/b7qD/2mxfP9mqXj/ZaV3/zldRP8oSzL/
	JEcs/yJILf8eRij/GkMl/xpEJf9WQALxXkQA/19EAP9gRQD/YEUA/2FGAP9iRgD/YkcA/2NIAP9k
	SAD/ZUkA/2VJAP9mSgD/KUEa9htOKf8cTyn/HE8p/xxQKv8cUSr/HFEq/xxSKv8SNhy4////AP//
	/wD///8A////AGCUbseM2KD/i9ef/4rXnv+J1p3/ta4y/86VAP/MlAD/y5MA/8qSAP/JkQD/x5AA
	/8aPAP/FjgD/w40A/8KMAP/BiwD/wIoA/3eISe5lm2//ZKF1/2Wsff9nsoH/ar2H/2/Kj/9z2Zj/
	eeqj/3jtpP937aP/de2i/3Xtov9x5Zz/a9OQ/2nEhv9jsHf/WYtX/1JtP/9NWCv/XEQB411DAP9e
	RAD/X0QA/2BFAP9gRQD/YUYA/2JGAP9iRwD/Y0cA/2RIAP9kSAD/ZUkA/yhBGfYbTSn/G04p/xxO
	Kf8cTyn/HFAq/xxQKv8cUSr/EjYcuP///wD///8A////AP///wBlmnLKkNqk/5HapP+O3KT/jt2k
	/7iyN//QlgD/z5UA/82UAP/MkwD/y5IA/8mRAP/IkAD/x48A/8aPAP/EjgD/w40A/8KMAP9qTQDz
	Vz8A/1E7AP9MOgT/RUUU/0FQI/87Vy3/Olwx/0NgL/9RYyn/Zmcf/3RnFP9/Ygf/hF8A/4ZhAP+I
	YgD/iWMA/4tjAP+MZAD/jmUA/1tCAORcQwD/XUMA/15EAP9fRAD/X0UA/2BFAP9hRgD/YUYA/2JH
	AP9jRwD/Y0gA/2RIAP8wTCP/H1As/xxOKv8bTSn/HE4p/xxPKf8cTyr/HFAq/xI1HLf///8A////
	AP///wD///8AZZ58Pl2fdX1TlWyPT5prqVGfbr+xnR/x0pgA/9GXAP/PlgD/zpUA/82UAP/MkwD/
	ypIA/8mRAP/IkAD/xo8A/8WOAP/EjQD/akwA81Y+AP9QOwD/SjYA/0UxAP83KAD/KR0A/z4rAP81
	JgD/RTIA/1Y+AP9lSQD/Z0oA/2lLAP9qTAD/bE4A/21PAP9vUAD/cFIA/3NSAP9aQADlXEIA/1xC
	AP9dQwD/XkMA/15EAP9fRAD/YEUA/2BGAP9hRgD/YkYA/2NHAP9jSAD/JiwU/x01JP8lRC7/KU4y
	/ytUN/8pUTT/KVEz/ydRMf8aOiK2////AP///wD///8A////AP///wD///8A////AP///wD///8A
	1ZoAsNSZAP/TmAD/0pcA/9CWAP/PlQD/zpQA/8yTAP/LkwD/ypIA/8mRAP/HkAD/xo8A/2hNAPNV
	PQD/TzoA/0QyAP8xIwD/IRgA/x0VAP81KAD/JhsA/y8hAP84KQD/QzAA/0o1AP9MNwD/TjkA/1A6
	AP9SOwD/VDwA/1Y+AP9YQAD/WUAA5ltBAP9bQgD/XEIA/11DAP9dQwD/XkQA/19EAP9gRQD/YEUA
	/2FGAP9iRgD/YkcA/yEqDd4MHRHGCx4Qsg0fEZUMIBFzDCEVUAsiES1HVkcS////A////wD///8A
	////AP///wD///8A////AP///wD///8A////ANacALDWmwD/1ZoA/9SZAP/SmAD/0ZcA/9CWAP/O
	lQD/zZQA/8yTAP/LkgD/yZEA/8iQAP9qTQDzUjoA/zkqAP8mHAD/HRUA/x0VAP8dFQD/MSQA/x4W
	AP8fFwD/IxgA/ysfAP87KgH/NicD/zElAP8zJQD/NiYA/zcoAP86KQD/OysA/1c/AOdaQQD/WkEA
	/1tCAP9cQgD/XUMA/11DAP9eRAD/X0QA/19FAP9gRQD/YUYA/2FGAP9kSQA4////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wDZ
	nACw2JwA/9ebAP/WmgD/1JkA/9OYAP/SmAD/0ZcA/8+WAP/OlQD/zZQA/8uTAP/KkgD/jWcA63JS
	AP5yUgD/fFkA/4VgAP+NZwD/l2wA/6R1AP+oeQD/r38A/7mFAP+7hwD/vo0K/2tUFf9TPAD/UDoA
	/0w3AP9MNwD/TTgA/U04APZYPwDxWUAA/1pAAP9aQQD/W0EA/1xCAP9cQgD/XUMA/15DAP9eRAD/
	X0QA/2BFAP9gRgD/YEQAOP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AOKiACzhoQBf36AAbt6hAH3coACL3Z8A3tqeAP/ZnQD/2JwA/9abAP/VmgD/1JkA/9OY
	AP/RlwD/0JYA/8+VAP/NlAD/zJMA/8uSAP/KkgD/yJEA/8eQAP/GjwD/xI4A/8ONAP/CjAD/wYsA
	/7+KAP++iQD/vYgA/8COC/9tVxb8UzwA/1Q8AP9VPQD/VT0A/1Y+AP9XPgD/Vz8A/1g/AP9ZQAD/
	WUAA/1pBAP9bQQD/W0IA/1xCAP9dQwD/XUMA/15EAP9fRAD/YEUA/2BFAIhhRgBUYUUAP2FJACpm
	TQAUgIAAAv///wD///8A////AP///wD///8A////AP///wDlpQCI46QA/+KjAP/gogD/36EA/96g
	AP/cnwD/254A/9qdAP/ZnAD/15sA/9abAP/VmgD/05kA/9KYAP/RlwD/0JYA/86VAP/NlAD/zJMA
	/8qSAP/JkQD/yJAA/8aPAP/FjgD/xI0A/8OMAP/BjAD/wIsA/7+KAP/EkQz/c1oZ8FI7AP9TPAD/
	VDwA/1Q9AP9VPQD/Vj4A/1Y+AP9XPwD/WD8A/1hAAP9ZQAD/WkEA/1pBAP9bQgD/XEIA/11DAP9d
	QwD/XkQA/19EAP9fRQD/YEUA/2FGAP9hRgD/YkcA/2NHAPxjSADqZEgA1GRIAFz///8A////AP//
	/wD///8A56cAiOWlAP/kpAD/4qQA/+GjAP/gogD/36EA/92gAP/cnwD/254A/9mdAP/YnAD/15sA
	/9WaAP/UmQD/05gA/9KXAP/QlgD/z5UA/86VAP/MlAD/y5MA/8qSAP/JkQD/x5AA/8aPAP/FjgD/
	w40A/8KMAP/BiwD/xpMN/3JaG/BROgD/UjsA/1M7AP9TPAD/VDwA/1U9AP9VPQD/Vj4A/1c+AP9Y
	PwD/WD8A/1lAAP9aQAD/WkEA/1tBAP9cQgD/XEIA/11DAP9eQwD/XkQA/19FAP9gRQD/YEYA/2FG
	AP9iRwD/Y0cA/2NIAP9kSAB4////AP///wD///8A////AOmpAIjnpwD/5qYA/+WlAP/jpAD/4qMA
	/+GiAP/foQD/3qAA/92fAP/bngD/2p4A/9mdAP/YnAD/1psA/9WaAP/UmQD/0pgA/9GXAP/QlgD/
	z5UA/82UAP/MkwD/y5IA/8mRAP/IkAD/x48A/8aPAP/EjgD/w40A/8iUDv9zXBzvUDoA/1E6AP9S
	OwD/UjsA/1M8AP9UPAD/VT0A/1U9AP9WPgD/Vz4A/1c/AP9YPwD/WUAA/1lAAP9aQQD/W0EA/1tC
	AP9cQgD/XUMA/11DAP9eRAD/X0QA/2BFAP9gRQD/YUYA/2JGAP9iRwD/ZEYAeP///wD///8A////
	AP///wDqqQCI6akA/+ioAP/npwD/5aYA/+SlAP/jpAD/4aMA/+CiAP/foQD/3qAA/9yfAP/bngD/
	2p0A/9icAP/XmwD/1poA/9WZAP/TmQD/0pgA/9GXAP/PlgD/zpUA/82UAP/MkwD/ypIA/8mRAP/I
	kAD/xo8A/8WOAP/Klg7/dF0d7k85AP9QOgD/UToA/1I7AP9SOwD/UzwA/1Q8AP9UPQD/VT0A/1Y+
	AP9WPgD/Vz8A/1g/AP9YQAD/WUAA/1pBAP9aQQD/W0IA/1xCAP9dQwD/XUMA/15EAP9fRAD/X0UA
	/2BFAP9hRgD/YUYA/2JGAHj///8A////AP///wD///8A7KsAiOuqAP/qqQD/6agA/+enAP/mpgD/
	5aUA/+OkAP/ipAD/4aMA/+CiAP/eoQD/3aAA/9yfAP/bngD/2Z0A/9icAP/XmwD/1ZoA/9SZAP/T
	mAD/0pcA/9CWAP/PlQD/zpQA/8yTAP/LkwD/ypIA/8mRAP/HkAD/y5gP/3ZfH+1POAD/TzkA/1A5
	AP9ROgD/UToA/1I7AP9TOwD/UzwA/1Q8AP9VPQD/VT0A/1Y+AP9XPgD/WD8A/1g/AP9ZQAD/WkAA
	/1pBAP9bQQD/XEIA/1xCAP9dQwD/XkMA/15EAP9fRQD/YEUA/2BGAP9iRgB4////AP///wD///8A
	////AO6tAIjtrAD/7KsA/+uqAP/pqQD/6KgA/+enAP/mpgD/5KUA/+OkAP/iowD/4KIA/9+hAP/e
	oAD/3Z8A/9ueAP/angD/2Z0A/9ecAP/WmwD/1ZoA/9SZAP/SmAD/0ZcA/9CWAP/OlQD/zZQA/8yT
	AP/LkgD/yZEA/86aEP92Xx/tTjgA/044AP9POQD/UDkA/1A6AP9ROgD/UjsA/1I7AP9TPAD/VDwA
	/1U9AP9VPQD/Vj4A/1c+AP9XPwD/WD8A/1lAAP9ZQAD/WkEA/1tBAP9bQgD/XEIA/11DAP9dQwD/
	XkQA/19EAP9gRQD/YEQAeP///wD///8A////AP///wDyrgCI760A/+6sAP/tqwD/7KoA/+qpAP/p
	qAD/6KcA/+anAP/lpgD/5KUA/+KkAP/howD/4KIA/9+hAP/doAD/3J8A/9ueAP/ZnQD/2JwA/9eb
	AP/WmgD/1JkA/9OYAP/SmAD/0ZcA/8+WAP/OlQD/zZQA/8uTAP/QnBH/d2Ag7E03AP9NOAD/TjgA
	/085AP9POQD/UDoA/1E6AP9SOwD/UjsA/1M8AP9UPAD/VD0A/1U9AP9WPgD/Vj4A/1c/AP9YPwD/
	WEAA/1lAAP9aQQD/W0EA/1tCAP9cQgD/XUMA/11DAP9eRAD/X0QA/2BEAHj///8A////AP///wD/
	//8A8q4AiPKvAP/wrgD/760A/+6sAP/sqwD/66oA/+qpAP/oqAD/56cA/+amAP/lpQD/46QA/+Kj
	AP/hogD/36EA/96hAP/doAD/3J8A/9qeAP/ZnQD/2JwA/9abAP/VmgD/1JkA/9OYAP/RlwD/0JYA
	/8+VAP/NlAD/0p4S/3liI+xMNgD/TDcA/003AP9OOAD/TzgA/085AP9QOQD/UToA/1E6AP9SOwD/
	UzsA/1M8AP9UPAD/VT0A/1U9AP9WPgD/Vz4A/1g/AP9YPwD/WUAA/1pAAP9aQQD/W0IA/1xCAP9c
	QgD/XUMA/15EAP9eRAB4////AP///wD///8A////APKuAIjyrwD/8q8A//GuAP/wrQD/7qwA/+2r
	AP/sqwD/66oA/+mpAP/oqAD/56cA/+WmAP/kpQD/46QA/+KjAP/gogD/36EA/96gAP/cnwD/254A
	/9qdAP/ZnAD/15sA/9abAP/VmgD/05kA/9KYAP/RlwD/0JYA/9SgE/96ZCTrSzYA/0w2AP9MNwD/
	TTcA/044AP9OOAD/TzkA/1A5AP9QOgD/UToA/1I7AP9SOwD/UzwA/1Q8AP9VPQD/VT0A/1Y+AP9X
	PgD/Vz8A/1g/AP9ZQAD/WUAA/1pBAP9bQQD/W0IA/1xCAP9dQwD/XkQAeP///wD///8A////AP//
	/wDyrgCI8q8A//KvAP/yrwD/8q8A//GuAP/vrQD/7q4E/+6vC//tsBH/7LEX/+yzHP/stCH/67Ul
	/+u1Kv/qty3/6rgw/+m4M//puDX/6bk3/+i5OP/nuTr/57k7/+a5O//muTv/5bg7/+a4O//ltzr/
	47Y5/+K1OP/itjr/mYI974RuLP6BaSj8fGUk+3liIfp4YSD4d2Af93VeHfZ0Xhz0c10b83JbGfFy
	WhnvcFgW7m9XFuxuVhXqbVQT6GtUEudrUhHlalAP42dPDuJnTg3gZkwK3mRMCdxjSgjaY0oG2GFH
	BdVfRgTUXkQB0VxCAGH///8A////AP///wD///8A9rAAHfKzETvzvCU+9ME3QfjJR0T5zVdJ+dFn
	TffTbk/21HJM9tFuSPXRbEX10mdA9M9jPvPPYjnz0F828cdbMvDHVy/vyFkr7spSKPLEVCXxxlMi
	78ZMHu2+ThrqwEwX57dKFfG5SBLtyUoO6NFGC9/AQAjMmTMF//+AAv///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP//
	/wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////
	AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A
	////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/
	//8A////AP///wD///8A////AP///wD///8A////AP///wD///8A////AP///wD/////////////
	////////////////////////////////////////////////////////AAf//////+AAAH//////
	AAAAP/////AAAAAP////AAAAAAP///gAAAAAAf//gAAAAAAAf/gAAAAAAAAf4AAAAAAAAA/AAAAA
	AAAAA4AAAAAAAAADgAAAAAAAAAGAAAAAAAAAAcAAAAAAAAABwAAAAAAAAAPAAAAAAAAAA8AAAAAA
	AAADwAAAAAAAAAPAAAAAAAAAA8AAAAAAAAADwAAAAAAAAAPAAAAAAAAAA8AAAAAAAAADwAAAAAAA
	AAPAAAAAAAAAA8AAAAAAAAADwAAAAAAAAAPAAAAAAAAAA8AAAAAAAAADwAAAAAAAAAPAAAAAAAAA
	A8AAAAAAAAADwAAAAAAAAAPAAAAAAAAAA8AAAAAAAAADwAAAAAAAAAPAAAAAAAAAA/4AAAAAAAAD
	/gAAAAAAA//+AAAAAAAD/8AAAAAAAAAfwAAAAAAAAAPAAAAAAAAAA8AAAAAAAAADwAAAAAAAAAPA
	AAAAAAAAA8AAAAAAAAADwAAAAAAAAAPAAAAAAAAAA8AAAAAAAAADwAAAAAAAAAPAAAAAf///////
	/////////////////////////////////////////////////////////////w==')
	#endregion

# Add assemblies
Add-Type -AssemblyName PresentationFramework, System.Drawing, System.Windows.Forms

# Order the columns the way you want to see them in the popup
#$Maincolumn = ' ','Type', 'Status'
#$columnorder = 'Service', 'Incident', 'Advisory', 'Degradation'



# Create XAML form in Visual Studio, ensuring the ListView looks chromeless
#$FormFile = Get-Content "C:\Users\Xport-PC\Dropbox\MCenter\o365ServiceHealthMonitoring\Modules\InSysTray_Form.txt"
#[xml]$xaml = $FormFile
[xml]$xaml = @"
	<Window
	xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
	xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
	Name="window" WindowStyle="None" Height="480" Width="576.951" ShowInTaskbar="False" Opacity="0.9" Topmost="True" ResizeMode="NoResize" AllowsTransparency="True">
		<Window.Resources>
			<Style TargetType="GridViewColumnHeader">
				<Setter Property="Background" Value="Transparent" />
				<Setter Property="Foreground" Value="White"/>
				<Setter Property="BorderBrush" Value="Transparent"/>
				<Setter Property="FontWeight" Value="Bold"/>
				<Setter Property="Template">
					<Setter.Value>
						<ControlTemplate TargetType="GridViewColumnHeader">
							<Border Background="#313130">
								<ContentPresenter></ContentPresenter>
							</Border>
						</ControlTemplate>
					</Setter.Value>
				</Setter>
			</Style>
		</Window.Resources>
		<Grid Name="grid" Background="#313130" RenderTransformOrigin="0.663,0.514">
			<Grid.ColumnDefinitions>
				<ColumnDefinition Width="217*"/>
				<ColumnDefinition Width="322*"/>
				<ColumnDefinition Width="118*"/>
			</Grid.ColumnDefinitions>
			<Grid.RowDefinitions>
				<RowDefinition Height="195*"/>
				<RowDefinition Height="266*"/>
			</Grid.RowDefinitions>
			<Label Name="label" Content="Current Office 365 Service Health" Foreground="#FFC0C3CF" FontSize="18" Margin="152,47,21.368,122" HorizontalContentAlignment="Center" HorizontalAlignment="Center" FontStyle="Italic" FontWeight="Bold" TextOptions.TextHintingMode="Fixed" Width="300" Grid.ColumnSpan="2"/>
			<Label Name="label1" Content="CENTRICA Tenant" Foreground= 'White' FontSize="18" Margin="115,19,85,150" HorizontalContentAlignment="Center" HorizontalAlignment="Center" FontWeight="Bold" TextOptions.TextHintingMode="Fixed" Width="300" Grid.ColumnSpan="3"/>
			<Label Name="DateToday" Content="Time" Foreground= '#FF3EF920' FontSize="18
				   " Margin="111,0,89,166" HorizontalContentAlignment="Center" HorizontalAlignment="Center" FontWeight="Bold" TextOptions.TextHintingMode="Fixed" Width="300" FontFamily="Lucida Fax" BorderBrush="White" Grid.ColumnSpan="3"/>
			<Label Name="MyMe" Content="Developed by: B. Noussi © 2018" Foreground= 'White' Margin="0,252,0,-2" HorizontalContentAlignment="Center" HorizontalAlignment="Center" TextOptions.TextHintingMode="Fixed" Width="593" FontStyle="Italic" Grid.Row="1" Grid.ColumnSpan="3">
				<Label.Background>
					<LinearGradientBrush EndPoint="0.5,1" StartPoint="0.5,0">
						<GradientStop Color="Black" Offset="1"/>
						<GradientStop Color="White"/>
					</LinearGradientBrush>
				</Label.Background>
			</Label>
			<DataGrid Name="datagridviewResults" SelectionMode="Single" BorderBrush="Gray" BorderThickness="5"   RowBackground="LightSkyBlue" AlternatingRowBackground="LightYellow"   Margin="0,115,0,54" Foreground="Black"
			Background="Transparent" RowHeight="20" IsHitTestVisible="False" HorizontalGridLinesBrush="#FF0A3FF5" VerticalGridLinesBrush="#FF0A3FF5" AlternationCount="1" Grid.RowSpan="2" Grid.ColumnSpan="3" IsReadOnly="False" >
				<DataGrid.Columns>
					<DataGridTemplateColumn Header=" " Width="20"  IsReadOnly="True">
						<DataGridTemplateColumn.CellTemplate>
							<DataTemplate>
								<Image Source="https://raw.githubusercontent.com/noussibona/Drum/master/HealthyBest.png" />
							</DataTemplate>
						</DataGridTemplateColumn.CellTemplate>
					</DataGridTemplateColumn>
				</DataGrid.Columns>
				<DataGrid.ItemContainerStyle>
					<Style>
						<Setter Property="Control.HorizontalContentAlignment" Value="Stretch"/>
						<Setter Property="Control.VerticalContentAlignment" Value="Stretch"/>
					</Style>
				</DataGrid.ItemContainerStyle>
			</DataGrid>
			<Label Name="NextUpdateTime" Content="Next update: " Foreground= 'White' FontSize="12" Margin="95.423,224,0,28" HorizontalContentAlignment="Center" HorizontalAlignment="Left" TextOptions.TextHintingMode="Fixed" Width="291" FontStyle="Italic" FontWeight="Bold" Grid.Row="1" Grid.Column="1" Grid.ColumnSpan="2" Height="25">
				<Label.Background>
					<RadialGradientBrush>
						<GradientStop Color="Black" Offset="1"/>
						<GradientStop Color="#FFE80B0B"/>
					</RadialGradientBrush>
				</Label.Background>
			</Label>
			<Label Name="LastUpdateTime" Content="Last update: " Foreground= 'White' FontSize="12" Margin="0,224,184.495,28" HorizontalContentAlignment="Center" HorizontalAlignment="Center" TextOptions.TextHintingMode="Fixed" Width="302" FontStyle="Italic" FontWeight="Bold" Grid.Row="1" Grid.ColumnSpan="2">
				<Label.Background>
					<RadialGradientBrush>
						<GradientStop Color="Black" Offset="1"/>
						<GradientStop Color="#FF6EF091" Offset="0.017"/>
					</RadialGradientBrush>
				</Label.Background>
			</Label>
			<DataGrid x:Name="datagridviewMain_Copy" SelectionMode="Single" BorderThickness="3"   RowBackground="LightSkyBlue" AlternatingRowBackground="Azure"   Margin="75.423,90,0,83" Foreground="Black"
				Background="{x:Null}" RowHeight="20" IsHitTestVisible="False" HorizontalGridLinesBrush="#FF0A3FF5" VerticalGridLinesBrush="#FF0A3FF5" AlternationCount="1" Grid.ColumnSpan="2" IsReadOnly="False" BorderBrush="#FFFBF7F7" AutoGenerateColumns="False" HorizontalAlignment="Left" Width="306" FontSize="16" FontWeight="Bold" FontStyle="Italic" Grid.Column="1" >
				<DataGrid.Columns>
					<DataGridTemplateColumn Header="               SERVICE STATUS" Width="220"  IsReadOnly="True" CanUserReorder="False" CanUserResize="False">
					</DataGridTemplateColumn>
				</DataGrid.Columns>
				<DataGrid.ItemContainerStyle>
					<Style>
						<Setter Property="Control.HorizontalContentAlignment" Value="Stretch"/>
						<Setter Property="Control.VerticalContentAlignment" Value="Stretch"/>
					</Style>
				</DataGrid.ItemContainerStyle>
			</DataGrid>
			<DataGrid x:Name="datagridviewMain" SelectionMode="Single" BorderThickness="3"   RowBackground="LightSkyBlue" AlternatingRowBackground="#FFA4F0A0"   Margin="141,90,0,83" Foreground="Black"
				Background="{x:Null}" RowHeight="20" IsHitTestVisible="False" HorizontalGridLinesBrush="#FF0A3FF5" VerticalGridLinesBrush="#FF0A3FF5" AlternationCount="1" Grid.ColumnSpan="2" IsReadOnly="False" BorderBrush="#FFFBF7F7" AutoGenerateColumns="False" HorizontalAlignment="Left" Width="122" FontSize="16" FontWeight="Bold" FontStyle="Italic" >
				<DataGrid.Columns>
					<DataGridTemplateColumn Header="  CATEGORY " Width="200"  IsReadOnly="True" CanUserReorder="False" CanUserResize="False">
					</DataGridTemplateColumn>
				</DataGrid.Columns>
				<DataGrid.ItemContainerStyle>
					<Style>
						<Setter Property="Control.HorizontalContentAlignment" Value="Stretch"/>
						<Setter Property="Control.VerticalContentAlignment" Value="Stretch"/>
					</Style>
				</DataGrid.ItemContainerStyle>
			</DataGrid>
		</Grid>
	</Window>
"@ 
# Turn XAML into PowerShell objects
$window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$xaml.SelectNodes("//*[@Name]") | ForEach-Object { Set-Variable -Name ($_.Name) -Value $window.FindName($_.Name) -Scope Script }
#Init
#Init
	# datagridviewResults
	#
# Populate ListView with PS Object data and set width
Retrieve_Event
$datagridviewResults.ItemsSource = $global:itemsource
$datagridviewResults.Width = $grid.width * .9
$datagridviewResults.MaxColumnWidth = 115

$this_Path = "C:\Users\Xport-PC\Dropbox\MCenter\o365ServiceHealthMonitoring\icons\HealthyBest.png"

    $get_image = (Get-Item $this_Path)
    $img = [System.Drawing.Image]::Fromfile($get_image );
   #$datagridviewResults  = $img   #Value.Image = $img


# Create GridView object to add to ListView
$startCell = $datagridviewResults.SelectedCells[0];
$RowIndex = $startCell.RowIndex
$ColumnIndex = $startCell.ColumnIndex + 1
$columnCount = $datagridviewResults.ColumnCount
$rowCount = $datagridviewResults.RowCount
for($RowIndex = 0;$RowIndex -lt $rowCount; $RowIndex++)
	{
		$Row = $datagridviewResults.Rows[$RowIndex]

				$datagridviewResults.CurrentCell = $cell
                $datagridviewResults.Rows[$myIndex].Cells[0].Value = "KJM"
				return
	}



<#
# Create GridView object to add to ListView
$gridview = New-Object System.Windows.Controls.GridView

# Dynamically add columns to GridView, then bind data to columns
foreach ($column in $columnorder) {
	$gridcolumn = New-Object System.Windows.Controls.GridViewColumn
	$gridcolumn.Header = $column
	$gridcolumn.Width = $grid.width*.9
	$gridbinding = New-Object System.Windows.Data.Binding $column
	$gridcolumn.DisplayMemberBinding = $gridbinding
	$gridview.AddChild($gridcolumn)
}

# Add GridView to ListView
$listview.View = $gridview
#>
# Create notifyicon, and right-click -> Exit menu
$notifyicon = New-Object System.Windows.Forms.NotifyIcon
$notifyicon.Text = "My o365 Service Health"
$notifyicon.Icon = $icon
$notifyicon.Visible = $true

$menuitem1 = New-Object System.Windows.Forms.MenuItem
$menuitem1.Text = "Exit"
$menuitem2 = New-Object System.Windows.Forms.MenuItem
$menuitem2.Text = "Always On"

$contextmenu = New-Object System.Windows.Forms.ContextMenu
$notifyicon.ContextMenu = $contextmenu
$notifyicon.contextMenu.MenuItems.AddRange($menuitem1)
$notifyicon.contextMenu.MenuItems.AddRange($menuitem2)
# Add a left click that makes the Window appear in the lower right
$DateToday.Content = Get-Date -Format "dddd, dd MMM yyyy HH':'mm':'ss"
$timer1 = New-Object System.Windows.Forms.Timer
$timer1.Interval = 1000 #1s
$timer1.add_Tick({
$DateToday.Content = Get-Date -Format "dddd, dd MMM yyyy HH':'mm':'ss"
})
$timer1.Start()
myCustom_Timer -myCode Retrieve_Event -duration 9000000
Show-BalloonTip -Title "My o365 Sevice Health Monitoring is accessible from SysTray." -MessageType Info -Message "My o365 Sevice Monitoring" -Duration 60000 

# part of the screen, above the notify icon.
$notifyicon.add_Click({
	if ($_.Button -eq [Windows.Forms.MouseButtons]::Left) {
			# reposition each time, in case the resolution or monitor changes
			$window.Left = $([System.Windows.SystemParameters]::WorkArea.Width-$window.Width)
			$window.Top = $([System.Windows.SystemParameters]::WorkArea.Height-$window.Height)
			$window.Activate()
			$window.Show()
	}
})



# Close the window if it's double clicked
$window.Add_MouseDoubleClick({
	$window.Hide()
	#Show-BalloonTip -Title "Moving My o365 Sevice Monitoring from SysTray." -MessageType Info -Message "My o365 Sevice Monitoring" -Duration 60000
})

# Close the window if it loses focus
$window.Add_Deactivated({
	$window.Hide()
	Show-BalloonTip -Title "My Office 365 Sevice Health Monitoring has been moved to SysTray." -MessageType Info -Message "My o365 Sevice Monitoring" -Duration 60000
})

# When Exit is clicked, close everything and kill the PowerShell process
$menuitem1.add_Click({
	$notifyicon.Visible = $false
	$window.Close()
	#Stop-Process $pid
 })



# Make PowerShell Disappear
$windowcode = '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);'
$asyncwindow = Add-Type -MemberDefinition $windowcode -name Win32ShowWindowAsync -namespace Win32Functions -PassThru
$null = $asyncwindow::ShowWindowAsync((Get-Process -PID $pid).MainWindowHandle, 0)


# Force garbage collection just to start slightly lower RAM usage.
[System.GC]::Collect()




# Create an application context for it to all run within.
# This helps with responsiveness, especially when clicking Exit.
$appContext = New-Object System.Windows.Forms.ApplicationContext
[void][System.Windows.Forms.Application]::Run($appContext)

